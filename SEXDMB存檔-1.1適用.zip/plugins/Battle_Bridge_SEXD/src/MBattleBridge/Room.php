<?php

namespace MBattleBridge;

use pocketmine\entity\Effect;
use pocketmine\entity\Snowball;
use pocketmine\entity\Attribute;
use pocketmine\entity\AttributeMap;

use pocketmine\Player;
use pocketmine\item\Item;
use pocketmine\block\Block;
use pocketmine\block\Air;
use pocketmine\block\Chest;
use pocketmine\tile\Tile;
use pocketmine\tile\Sign;
use pocketmine\tile\Chest as TileChest;
use pocketmine\scheduler\ServerScheduler;
use pocketmine\scheduler\PluginTask;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Config;
use pocketmine\math\Vector3;
use pocketmine\inventory\PlayerInventory;
use pocketmine\inventory\BigShapedRecipe;
use pocketmine\inventory\ShapedRecipe;
use pocketmine\inventory\ShapelessRecipe;
use pocketmine\command\ConsoleCommandSender;

use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\format\mcregion\Chunk;
use pocketmine\level\format\FullChunk;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\level\particle\Particle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\HeartParticle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\particle\RedstoneParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\WaterParticle;
use pocketmine\level\sound\ClickSound;
use pocketmine\level\sound\DoorSound;
use pocketmine\level\sound\LaunchSound;
use pocketmine\level\sound\PopSound;

use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\EnumTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;

use MBattleBridge\Language;
use MBattleBridge\MBattleBridge;
use MBattleBridge\chapters\Chapter;
use MBattleBridge\chapters\Dynamic;
use MBattleBridge\tasks\RBTask;
use MBattleBridge\tasks\PrepareTickTask;
use MBattleBridge\tasks\ReadyTickTask;
use MBattleBridge\tasks\GameTickTask;
use MBattleBridge\tasks\GenerateBridgeTask;
use MBattleBridge\tasks\PrepareBridgeTask;
use MBattleBridge\tasks\PrepareMineTask;
use MBattleBridge\tasks\ParticleTickTask;
use MBattleBridge\tasks\StartTask;
class Room{
	
	public $plugin;
	
	public $id;
	
	public $info;
	
	public $time;
	
	public $loaded;
		
	public $gamers;
	
	public $ready;
	
	public $gamestart;
	
	public $war;	
	
	public $generated;
	
	public $duel;
	
	public $chapter;
	
	public $particle;//顯示人數之類的
		
	public function __construct($plugin, $id){
		$this->plugin = $plugin;
		if($this->plugin->getRoomInfo($id) !== null){
			$this->id = $id;
			foreach(MBattleBridge::$room_info_format as $key => $val){
				if(!isset($this->plugin->roomsinfo[$id][$key])){
					$this->plugin->roomsinfo[$id][$key] = $val;
					if(!is_array($val)){
						$this->plugin->getServer()->getLogger()->info(MBattleBridge::FORMAT."房間{$this->getID()}的 [$key] 沒有設置,已暫時自動改為 [$val]");
					}
				}else{
					if(is_array($val)){
						foreach($val as $key2 => $val2){
							if(!isset($this->plugin->roomsinfo[$id][$key][$key2])){
								$this->plugin->roomsinfo[$id][$key][$key2] = $val2;
							}
						}
					}
				}
				if(getType($this->plugin->roomsinfo[$id][$key]) != getType($val)){
					if(is_numeric($this->plugin->roomsinfo[$id][$key]) and is_numeric($val)){
						
					}else{
						$this->plugin->roomsinfo[$id][$key] = $val;
						if(!is_array($val)){
							$this->plugin->getServer()->getLogger()->info(MBattleBridge::FORMAT."房間{$this->getID()}的 [$key] 數據類型不符,已暫時自動改為 [$val]");
						}
					}
				}else{
					if(is_array($val)){
						foreach($val as $key2 => $val2){
						if(getType($this->plugin->roomsinfo[$id][$key][$key2]) != getType($val2)){
							if(is_numeric($this->plugin->roomsinfo[$id][$key][$key2]) and is_numeric($val2)){
						
							}else{
								$this->plugin->roomsinfo[$id][$key][$key2] = $val2;
								if(!is_array($val2)){
									$this->plugin->getServer()->getLogger()->info(MBattleBridge::FORMAT."房間{$this->getID()}中的[$key]中的 [$key2] 數據類型不符,已暫時自動改為 [$val2]");
								}
							}
						}
						}
					}
				}
			}
			$this->info = $this->plugin->getRoomInfo($id);
			if(!isset($this->info["game-level"]) or !isset($this->info["wait"]) or !isset($this->info["center"]) or !isset($this->info["stop"])){
				$this->loaded = false;
				$this->delete();
				return false;
			}
			foreach(MBattleBridge::$allteams as $team){
				if(!isset($this->info[$team])){
					$this->delete();
					return false;
				}
			}
			if(!in_array(strtolower($this->info["chapter"]),MBattleBridge::$allchapters)){
				$this->info["chapter"] = MBattleBridge::$defaultchapter;
			}
			$this->gamers = [];
			$this->gamers["all"] = [];
			$this->gamers["red"] = [];
			$this->gamers["blue"] = [];
			$this->gamers["green"] = [];
			$this->gamers["yellow"] = [];
			$this->spectators = [];
			$this->spectators["all"] = [];
			$this->spectators["red"] = [];
			$this->spectators["blue"] = [];
			$this->spectators["green"] = [];
			$this->spectators["yellow"] = [];
			$this->chapter = Chapter::getChapter($this);
			$this->chapterblock = $this->chapter->getChapterBlock();
			$this->loaded = true;
			$this->time = 0;
			$this->ready = false;
			$this->gamestart  = false;
			$this->war = false;
			$this->generated = false;
			$this->duel = false;
			$this->prepareTick();
			if($this->plugin->config["螺旋粒子開關"] == true){
				$this->particleTick();
			}
			if($this->plugin->getServer()->isLevelLoaded($this->info["game-level"]) === false){
				$this->loaded = false;
			}else{
				$this->loadChunks();
				$pos = $this->getWaitPos();
				if($pos instanceof Position){
					$this->particle = new FloatingTextParticle(new Position($pos->x,$pos->y+2.5,$pos->z,$pos->level),"","  ".MBattleBridge::FORMAT);
					$this->updateParticle();
				}else{
					$this->particle = null;
				}
			}
		}else{
			$this->delete();
			$this->loaded = false;
			return false;
		}
	}
	
	public function __destruct(){
		
	}
	
	public function loadChunks(){
		$level = $this->getGameLevel();
		if($level instanceof Level){
			foreach(MBattleBridge::$allteams as $team){
				$level->loadChunk($this->info[$team]["x"] >> 4,$this->info[$team]["z"] >> 4);
			}
			$level->loadChunk($this->info["center"]["x"] >> 4,$this->info["center"]["z"] >> 4);			
		}
	}
	
	public function delete(){
		$this->plugin->deleteRoom($this->getID());
	}
	
	public function reload(){
		$this->plugin->reloadRoom($this->getID());
	}
	
	public function joinPlayer($player){
		if(!$player instanceof Player)return false;
		$name = strtolower($player->getName());
		if(!$this->plugin->mgb->isPlayerAuthenticated($player) and $this->plugin->mgb->isConnected()){
			$this->sendMessage($player, $this->plugin->mgb->getMessage($player, "not.login"));
			return false;
		}
		if ($this->gamestart !== false and !$this->plugin->isVIP($player)){
			$this->sendMessage($player, $this->plugin->getMessage($player, "join.room.started", [$this->id]));
			return false;
		}
		if ($this->plugin->findRoom($name) !== null) {
			$this->sendMessage($player, $this->plugin->getMessage($player, "join.room.joined"));
			return false;
		}
		if($this->isFull() and !$this->plugin->isVIP($player)){
			$this->sendMessage($player, $this->plugin->getMessage($player, "join.room.fulled", [$this->id]));
			return false;
		}
		if(!$this->isLoaded()){
			$this->sendMessage($player, $this->plugin->getMessage($player, "join.room.unloaded", [$this->id]));
			return false;
		}
		if(in_array(strtolower($player->getName()), $this->info["banners"])){
			$this->sendMessage($player, $this->plugin->getMessage($player, "join.room.banned"));
			return false;
		}
		$config = $this->plugin->getPlayerConfig($name);
		$config->set("Gamemode",$player->getGamemode());
		$config->set("Quit",1);
		$config->set("Allowflight",$player->MgetAllowFlight());
		$config->save();
		$this->gamers["all"][] = $name;
		$this->plugin->mgb->getMP($player)->setRoom($this->plugin->getGameName(), $this->getID());
		$this->plugin->mgb->updateNameTag($player);
		$this->wMessage("join.room", [$this->plugin->mgb->getMP($player)->getGamename(), $this->getPlayerNum(), $this->getMax()]);
		$this->sendMessage($player, $this->plugin->getMessage($player, "join.room.success", [$this->getID(), $this->getPlayerNum(), $this->getMax()]));
		$this->sendMessage($player, $this->plugin->getMessage($player,"help.quit"));
		$this->sendMessage($player, $this->plugin->getMessage($player, "chapter.".$this->getChapterName().".welcome"));
		$this->sendMessage($player, $this->plugin->getMessage($player, "team.team"));
		$this->spawn($player);
		$level = $player->getLevel();
		if ($level instanceof Level) {
			$level->startTime();
			$level->setTime($this->info["level-time"]);
			$level->stopTime();
			$sound = new DoorSound($player->getPosition());
			$level->addSound($sound);
		}
		$this->plugin->updateSigns();
		$this->updateParticle($player);
		$this->getChapter()->onJoinPlayer($player);
		if($this->getStep() !== "ready" and $this->getPlayerNum() >= $this->getMin()){
			if($this->isBalanced()){
				$this->ready();
			}else{
				$this->wTip("join.balanced", [$this->info["neglectable-balance"]]);
			}
		}
	}
	
	public function quitPlayer($player){
		if($player instanceof Player){
			if(!$player->isOnline()){
				return $this->quitPlayer($player->getName());
			}
		$name = strtolower($player->getName());
		$find = array_search($name, $this->gamers["all"]);
		if($find !== false){
			$this->getChapter()->onQuitPlayer($player);
			array_splice($this->gamers["all"], $find, 1);
			if(($find2 = array_search($name, $this->spectators["all"])) !== false){
				array_splice($this->spectators["all"], $find2, 1);
			}
			$this->quitTeam($player);
			if($this->isStarted()){
				$config = $this->plugin->getPlayerConfig($player);
				$config->set("Time", $config->get("Time") + $this->time);
				$config->save();
				$exp = $this->plugin->calculate($player,"get","exp");
				$this->plugin->mgb->updateXp($player, $exp);
				unset($config);
			}
			$this->plugin->calculate($player,"stop");
			$this->wMessage("quit.room", [$name, $this->getPlayerNum(), $this->getMax()]);
			if($player->isOnline()){
				$this->plugin->mgb->getMP($player)->setRoom($this->plugin->getGameName(), null);
				$player->teleport($this->getStopPos());
				$this->plugin->showPlayer($player);
				$this->sendMessage($player, $this->plugin->getMessage($player, "quit.room.one", [$this->getID()]));
		        $inventory = $player->getInventory();
		        $inventory->clearAll();
				$inventory->sendContents($player);
				$player->gamemode = 4;
				$player->setGamemode($this->plugin->getPlayerConfig($player)->get("Gamemode"));
				if($fly = $this->plugin->getPlayerConfig($player)->get("Allowflight") != false){
					$player->MsetAllowFlight((bool)$fly);
				}
		        $inventory = $player->getInventory();
		        $inventory->clearAll();
				$inventory->sendContents($player);
                $player->setSprinting(false);
                $player->setSneaking(false);
                $player->extinguish();
				$player->removeAllEffects();
                $player->setMaxHealth(20);
                $player->setMaxHealth($player->getMaxHealth());
				$player->setNametag($player->getName());
				/*
				$pk = new CraftingDataPacket();
				$pk->cleanRecipes = true;
				$player->dataPacket($pk);
				*/
                $player->setHealth($player->getMaxHealth());
				$config = $this->plugin->getPlayerConfig($player);
				$config->set("Quit",0);
				$config->save();
			}
		}
		}else{
			$find = array_search(strtolower($player), $this->gamers["all"]);
			if($find !== false){
			$this->getChapter()->onQuitPlayer($player);
			array_splice($this->gamers["all"], $find, 1);
			if(($find2 = array_search(strtolower($player), $this->spectators["all"])) !== false){
				array_splice($this->spectators["all"], $find2, 1);
			}
			$this->quitTeam($player);
			if($this->isStarted()){
				$config = $this->plugin->getPlayerConfig($player);
				$config->set("Time", $config->get("Time") + $this->time);
				$config->save();
				$exp = $this->plugin->calculate($player,"get","exp");
				$this->plugin->mgb->updateXp($player, $exp);
				unset($config);
			}
			$this->plugin->calculate($player,"stop");
			$this->wMessage("quit.room", [$player, $this->getPlayerNum(), $this->getMax()]);
			}
		}
		$this->ifwin();
		$this->plugin->updateSigns();
		$this->updateParticle();
	}
	
	public function joinTeam($player, $team = "random", $focus = false){
		$name = strtolower($player->getName());
		if($this->isIn($name)){
			    if($this->isStarted() and $focus !== true){
					$this->sendMessage($player, $this->plugin->getMessage($player, "join.team.started"));
					return false;
				}
                if($this->isInTeam($name)){
					if($this->getTeam($player) == $team){
						return false;
					}else{
						$this->quitTeam($player);
					}
		        }
				if($team == "random"){
					$players = ["red"=>$this->getPlayerNum("red"),"blue"=>$this->getPlayerNum("blue"),"yellow"=>$this->getPlayerNum("yellow"),"green"=>$this->getPlayerNum("green")];
					$min = min($players);
					$find = array_search($min, $players);
					if($find !== false){
                		if($this->isInTeam($name)){
							if($this->getTeam($player) == $find){
								return false;
							}
		        		}
						return $this->joinTeam($player, $find, $focus);
					}
				}else{
					switch($team){
						case "紅隊":
						case "紅":
						$team = "red";
						break;
						
						case "藍隊":
						case "藍":
						$team = "blue";
						break;
						
						case "黃隊":
						case "黃":
						$team = "yellow";
						break;
						
						case "綠隊":
						case "綠":
						$team = "green";
						break;
						
						default :
						$team = $team;
						break;
					}
					if(!in_array($team, ["red", "blue", "green", "yellow"])){
				       $this->sendMessage($player, $this->plugin->getMessage($player, "join.team.noexit", [$team]));
				        return false;
			        }				
					if($this->isFullTeam($team) and !$this->plugin->isVIP($player)){
				       $this->sendMessage($player, $this->plugin->getMessage($player, "join.team.full", [$team]));
				        return false;
			        }
					$this->gamers[$team][] = $name;
					$player->setNametag("§5§o§l".$this->plugin->mgb->getMP($player)->getGamename()."\n§r§7[".Language::$message[$team.".color"]."██████§7]");
					$this->sendMessage($player, $this->plugin->getMessage($player,"join.team", [$team]));
					$this->updateParticle();
					if($this->getStep() !== "ready" and $this->getPlayerNum() >= $this->getMin()){
						$this->ready();
					}
					return true;
				}
		}else{
			$this->sendMessage($player, $this->plugin->getMessage($player, "join.team.room", [$this->getID()]));
			return false;
		}
	}
	
	public function quitTeam($player){
		if($player instanceof Player){
			$name = strtolower($player->getName());
		}else{
			$name = strtolower($player);
		}
		foreach($this->gamers as $team => $val){
			if($team !== "all"){
				$find = array_search($name, $this->gamers[$team]);
				if($find !== false){
					if(($find2 = array_search($name, $this->spectators[$team])) !== false){
						array_splice($this->spectators[$team], $find2, 1);
					}
					if($player instanceof Player){
						$player->setNametag("§7[未選擇]§f".$name);
						$this->sendMessage($player, $this->plugin->getMessage($player,"quit.team", [$team]));
					}
					array_splice($this->gamers[$team], $find, 1);
					return $find;
				}
			}
		}
		$this->ifwin();
		$this->updateParticle();
		return false;
	}

//------------------------------------------------------------
    public function particleTick(){
		if(!$this->plugin->isEnabled()){
			return false;
		}
		$this->plugin->getServer()->getScheduler()->scheduleRepeatingTask(new ParticleTickTask($this->plugin, $this), 2);
	}

    public function prepareTick(){
		if(!$this->plugin->isEnabled()){
			return false;
		}
		$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new PrepareTickTask($this->plugin, $this), 20);
	}

	public function ready(){
		if($this->isReady()){
			return true;
		}
		$this->wMessage("game.ready");
		$this->ready = true;
		$this->readyTick($this->getReadyTime());
		$this->refillChests();
		if($this->plugin->config["自動生成遊戲地圖礦物(生成時服務器性能不好的可能會卡頓十多秒)"] == true){
			$this->generateMine();
		}
	}
	
	public function readyTick($time){
		$this->wMessage("game.readytick", [$time]);
		$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new ReadyTickTask($this->plugin, $this, $time), 20);
	}
	
	public function tick($type, $oldtime = 0){
		if(!$this->plugin->isEnabled()){
			return false;
		}
		if($type == "prepare"){
			if($this->isReady()){
				return false;
			}
			$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new PrepareTickTask($this->plugin, $this), 20);
			return true;
		}elseif($type == "ready"){
			if(!$this->isReady()){
				return false;
			}
			if($oldtime <= 0 and !$this->isStarted()){
				if($this->isBalanced()){
					$this->start();
				}else{
					if($oldtime <= -15){
						$this->ForceBalance();
						$newtime = $oldtime - 1;
						$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new ReadyTickTask($this->plugin, $this, $newtime), 20);
					}else{
						$newtime = $oldtime - 1;
						$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new ReadyTickTask($this->plugin, $this, $newtime), 20);
						$this->wPopup("join.balanced", [$this->info["neglectable-balance"], 15+$newtime]);
					}
				}
			}else{
				$newtime = $oldtime - 1;
				$this->TimeAttribute($newtime);
				$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new ReadyTickTask($this->plugin, $this, $newtime), 20);
			}
			return true;
		}elseif($type == "game"){
			if($oldtime >= $this->getLimitTime()){
				$this->wMessage("game.overtime", [$this->getLimitTime()]);
				$this->stop(true);
			}else{
				if(!$this->isStarted()){
					return false;
				}
				$newtime = $oldtime + 1;
				
				if(!$this->getChapter()->isCustomTip()){
					if(!$this->isWar()){
						$newtime2 = $this->getWarTime()-$newtime;
					}elseif(!$this->isGenerated()){
						$newtime2 = $this->getBridgeTime()-$newtime;
					}else{
						$newtime2 = $newtime;
					}
					$minite = floor($newtime2 / 60);
					if($minite < 10)$minite = "0".$minite;
					$second = $newtime2 - $minite*60;
					if($second < 10)$second = "0".$second;
					$str = "                                                                      §6<>--§e[戰橋]§6--<>\n".
					"                                                                      §r§2時間§a:§7§l".$minite.":".$second."\n".
					"                                                              §r§c紅隊§7:§o§3§l ".$this->getPlayerNum("red")." §f|  "."§r§b藍隊§7:§o§3§l ".$this->getPlayerNum("blue")."\n".
					"                                                              §r§e黃隊§7:§o§3§l ".$this->getPlayerNum("yellow")." §f|  "."§r§a綠隊§7:§o§3§l ".$this->getPlayerNum("green")."\n".
					"                                                              §8遊戲章節§7: §3§l".$this->plugin->getMessage(null, $this->chapter->getName())."\n".
					"                                                              §d當前階段§7: §3§l".$this->plugin->getMessage(null, $this->getStep())."\n";
					foreach($this->getPlayers() as $player){
						if($this->isSpectator($player)){
							$newmessage = "§f觀戰";
						}else{
							$newmessage = $this->plugin->getMessage(null, $this->getTeam($player))."§7隊";
						}
						$newstr = $str."                                                              §r§6<>--§e[".$newmessage."§e]§6--<>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
						$this->sendTip($player, $newstr);
					}
				}
				
				if($newtime == $this->getWarTime()){
					$this->startWar();
				}
				if($newtime == $this->getBridgeTime()){
					$this->generateBridge();
					$this->wMessage("game.generate");
				}
				if($this->getChapter() instanceof Dynamic){
					if($newtime == $this->chapter->getChangeTime()){
					     $this->chapter->onChange();
					}
				}
				$duel = $this->getDuelTime() - $newtime;
				if($duel > 0 and $duel <= 30){
					foreach($this->getPlayers() as $player){
						$this->sendPopup($player, $this->plugin->getMessage(null, "game.duel.prepare", [$duel]));
					}
				}elseif($duel == 0){
					$this->duel();
					foreach($this->getPlayers() as $player){
						$this->sendPopup($player, $this->plugin->getMessage(null, "game.duel.finish"));
					}
				}
				$chest = $this->getChestTime() - $newtime;
				if($chest > 0 and $chest <= 10){
					foreach($this->getPlayers() as $player){
						$this->sendPopup($player, $this->plugin->getMessage(null, "game.refill.prepare", [$chest]));
					}
				}elseif($chest == 0){
					$this->refillChests();
					foreach($this->getPlayers() as $player){
						$this->sendPopup($player, $this->plugin->getMessage(null, "game.refill.finish"));
					}
				}
				$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new GameTickTask($this->plugin, $this, $newtime), 20);
				$this->time = $newtime;
			}
		}else{
			$this->stop(true);
			return false;
		}
	}
	
	public function start($force = false){
		if($this->getChapter()->onStart($force) === "default"){
			if($this->gamestart !== true){
				$this->gamestart = true;
			}
			foreach($this->getPlayers() as $player){
				$this->spawn($player);
			}
			$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new GameTickTask($this->plugin, $this, 0), 20);
			$this->wMessage("game.start");
			$this->wTitle("game.start");
			$this->wMessage($this->chapter->getIntroduction());
			$this->ifwin();
			$this->plugin->updateSigns();
		}
	}
	
	public function stop($force = false){
		if($this->getChapter()->onStop($force) === "default"){
		$this->time = 0;
		$this->ready = false;
		$this->gamestart = false;
		$this->war = false;
		$this->generated = false;
		$this->duel = false;
		foreach($this->getPlayers() as $player){
			if ($player instanceof Player) {
				if($player->isOnline()){
					$this->quitPlayer($player);  
				}else{
					
				}
			}
		}
		$this->gamers = [];
		$this->gamers["all"] = [];
		$this->gamers["red"] = [];
		$this->gamers["blue"] = [];
		$this->gamers["green"] = [];
		$this->gamers["yellow"] = [];
		$this->spectators = [];
		$this->spectators["all"] = [];
		$this->spectators["red"] = [];
		$this->spectators["blue"] = [];
		$this->spectators["green"] = [];
		$this->spectators["yellow"] = [];
		$this->rollback($force);
		$this->plugin->updateSigns();
		$this->prepareTick();
		}
	}

	public function startWar(){
		$this->war = true;
		$this->wMessage("game.war");
		$this->wTitle("game.war");
	}
	
	public function duel(){
		$this->duel = true;
		$center = $this->plugin->getSafePos($this->getCenterPos());
		foreach(MBattleBridge::$allteams as $team){
			switch($team){
				case "red":
				$pos = new Position($center->x+4,$center->y,$center->z,$center->level);
				break;
				case "blue":
				$pos = new Position($center->x-4,$center->y,$center->z,$center->level);
				break;
				case "green":
				$pos = new Position($center->x,$center->y,$center->z+4,$center->level);
				break;
				case "yellow":
				$pos = new Position($center->x,$center->y,$center->z-4,$center->level);
				break;
			}
			foreach($this->getPlayers($team) as $player){
				$player->teleport($pos);
			}
		}
	}
	
	public function ifwin(){		
		$loseteams = array();
		if($this->isStarted() !== true){
			return false;
		}
		foreach(MBattleBridge::$allteams as $team){
			if(count($this->gamers[$team]) <= 0){
				$loseteams[] = $team;
			}
		}
		unset($team);
		if(count($loseteams) >= 3){
			foreach($loseteams as $team){
				$this->lose($team);
			}
			unset($team);
			foreach(MBattleBridge::$allteams as $team){
				if(!in_array($team,$loseteams)){
					$this->win($team);
				}
			}
			$this->stop();
		}
	}
	
   public function refillChests(){
        $contents = $this->plugin->getChestContents();
        foreach ($this->getGameLevel()->getTiles() as $tile) {
            if ($tile instanceof TileChest) {
                for ($i = 0; $i < $tile->getSize(); $i++) {
                    $tile->getInventory()->setItem($i, Item::get(0));
                }
                if(empty($contents))
                    $contents = $this->plugin->getChestContents();
                foreach (array_shift($contents) as $key => $val) {
                    $tile->getInventory()->setItem($key, Item::get($val[0], 0, $val[1]));
                }
            }
        }
        unset($contents, $tile);
    }
	
	public function generateBridge(){
		    $this->generated = true;
  			$center = $this->getCenterPos();
  			$cx = (int)$center->x;
  			$cy = (int)$center->y;
  			$cz = (int)$center->z;
  			foreach(MBattleBridge::$allteams as $team){
				$this->plugin->getServer()->getScheduler()->scheduleAsyncTask(new PrepareBridgeTask($this->getID(), $cx, $cy, $cz, (int)$this->info[$team]["x"], (int)$this->info[$team]["y"], (int)$this->info[$team]["z"]));    
			}
 	}
	
	public function generateMine(){
			  	$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new PrepareMineTask($this->plugin,$this->getID(), (int)$this->info["red"]["x"], (int)$this->info["red"]["y"],(int)$this->info["red"]["z"]), 1);
	  			$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new PrepareMineTask($this->plugin,$this->getID(), (int)$this->info["red"]["x"], (int)$this->info["blue"]["y"],(int)$this->info["blue"]["z"]), 120);
				$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new PrepareMineTask($this->plugin,$this->getID(), (int)$this->info["red"]["x"], (int)$this->info["yellow"]["y"],(int)$this->info["yellow"]["z"]), 240);
				$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new PrepareMineTask($this->plugin,$this->getID(), (int)$this->info["red"]["x"], (int)$this->info["green"]["y"],(int)$this->info["green"]["z"]), 360);
	}
	
	public function updateParticle($player = null){
		if(($level = $this->getWaitLevel()) instanceof Level){
			$particlemessage = "§6房間號§7: §f-=[§d".$this->getID()."§f]=-\n";
			$particlemessage .= "§b總人數§7:  §f[§e".$this->getPlayerNum()."§f]";
			foreach(MBattleBridge::$allteams as $team){
				$particlemessage .= "\n   ".Language::$message[$team]."隊 §6".$this->getPlayerNum($team);
			}
			//$particlemessage .= "\n§2".Language::$message[$this->chapter->getName()];
			//$this->particle->setText($particlemessage);
			if($player instanceof Player){
				$level->addParticle($this->particle,[$player]);
			}else{
				$level->addParticle($this->particle);
			}
		}
	}

	
	public function rollback($force = false){
		if(!$force){
			$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new RBTask($this->plugin, $this), $this->getRollbackTime());
		}else{
			$this->loaded = false;
			$level = $this->getGameLevel();
			if(!$level instanceof Level){
				$this->plugin->getLogger()->info(MBattleBridge::FORMAT."無法卸載遊戲地圖,原因是地圖未加載,地圖重置失敗!");
				return false;
			}
			$name = $level->getFolderName();
			$default = $this->plugin->getServer()->getDefaultLevel()->getFolderName();
			if($name == $default){
				$this->plugin->getLogger()->info(MBattleBridge::FORMAT."無法卸載服務器默認地圖,地圖重置失敗!");
				return false;
			}
			$ok1 = $this->plugin->getServer()->unloadLevel($level);
			if ($ok1 !== true) {
				$this->plugin->getLogger()->info(MBattleBridge::FORMAT."恢複地圖時，卸載地圖失敗");
				return false;
			}
			$p0 = $default;
			$p1 = dirname($p0);
			$path =  $p1. "/plugins/MGameBase/games/".$this->plugin->getGameName()."/worlds/";
			$path0 = $p1. "/worlds/";
			$this->plugin->getLogger()->info("備份的地圖目錄：".TextFormat::BLUE.$path);
			$files = scandir($path);
			foreach($files as $f) {
				if ($f !== "." && $f !== ".." && is_dir($path.$f)) {
					if($f === $name) {
						if($this->plugin->getServer()->isLevelLoaded($f) === false){
							$this->recurse_copy($path . '/' . $f,$path0 . '/' . $f);
							$ok2 = true;
							if ($ok2 !== true) {
								$this->plugin->getLogger()->info(MBattleBridge::FORMAT."恢複地圖時，創建地圖失敗");
								return false;
							}
							else {
								$ok3 = $this->plugin->getServer()->LoadLevel($name);
								if ($ok3 !== true) {
									$this->plugin->getLogger()->info(MBattleBridge::FORMAT."恢複地圖時，裝載地圖失敗");
									return false;
								}
								else {
									$this->plugin->getLogger()->info(MBattleBridge::FORMAT."房間 ".$this->getID()." 地圖已成功恢複");
									$this->plugin->getLogger()->info(MBattleBridge::FORMAT."已重新獲取世界對象：".$name);
									$this->loaded = true;
								}
							}
						}
					}
				}
			}
		}
	}

    public function recurse_copy($src,$dst) {
        $dir = opendir($src);
        @mkdir($dst);
        while(false !== ( $file = readdir($dir)) ) {
            if (( $file != '.' ) && ( $file != '..' )) {
                if ( is_dir($src . '/' . $file) ) {
                    $this->recurse_copy($src . '/' . $file,$dst . '/' . $file);
                }
                else {
                    copy($src . '/' . $file,$dst . '/' . $file);
                }
            }
        }
        closedir($dir);
    }
	
	public function ForceBalance(){
		foreach($this->getPlayers() as $player){
			$this->quitTeam($player);
			$this->joinTeam($player, "random", true);
		}
	}
	
	public function getStep(){
		if($this->loaded !== true){
			return "rollback";
		}elseif($this->ready !== true){
			return "prepare";
		}elseif($this->ready == true and $this->gamestart !== true){
			return "ready";
		}elseif($this->gamestart == true and $this->war !== true){
			return "start";
		}elseif($this->war == true and $this->generated !== true){
			return "war";
		}elseif($this->generated == true and $this->duel !== true){
			return "generated";
		}elseif($this->duel == true){
			return "duel";
		}
		return "normal";
	}

//------------------------------------------------------------
	public function isIn($player){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);
		if(in_array($player, $this->gamers["all"])){
			return true;
		}else{
			return false;
		}
	}
	
	public function isInTeam($player){
		if($this->getTeam($player) !== null){
			return true;
		}
		return false;
	}
	
	public function isSpectator($player){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);
		if(in_array($player, $this->spectators["all"])){
			return true;
		}else{
			return false;
		}
	}
	
	public function isLoaded(){
		return $this->loaded;
	}
		
	public function isFull(){
		if($this->getPlayerNum() >= $this->getMax()){
			return true;
		}else{
			return false;
		}
	}
	
	public function isFullTeam($team){
		if($this->getPlayerNum($team) >= $this->getMaxTeam($team)){
			return true;
		}else{
			return false;
		}
	}
	
	public function isReady(){
		return $this->ready;
	}
	
	public function isStarted(){
		return $this->gamestart;
	}
	
    public function isWar(){
		return $this->war;
	}
	
	public function isGenerated(){
		return $this->generated;
	}
	
	public function isDuel(){
		return $this->duel;
	}
	
	public function isBalanced(){
		$balance = $this->info["neglectable-balance"];
		if($this->getPlayerNum() <= 4 and $balance < 1){
			$balance = 1;
		}
		$red = $this->getPlayerNum("red");
		$blue = $this->getPlayerNum("blue");
		$yellow = $this->getPlayerNum("yellow");
		$green = $this->getPlayerNum("green");
		$abs1 = abs($red - $blue);
		$abs2 = abs($red - $yellow);
		$abs3 = abs($red - $green);
		$abs4 = abs($blue - $yellow);
		$abs5 = abs($blue - $green);
		$abs6 = abs($yellow - $green);
		if($abs1 > $balance or $abs2 > $balance or $abs3 > $balance or $abs4 > $balance or $abs5 > $balance or $abs6 > $balance){
			return false;
		}
		return true;
	}
	
	public function isTeammateDamage(){
		if($this->info["teammate-damage"] !== 0){
			return true;
		}else{
			return false;
		}
	}
	
	public function getID(){
		return $this->id;
	}
	
	public function getPlayerNum($team = null){
		if($team == null){
			return count($this->gamers["all"]);
		}else{
			return count($this->gamers[$team]);
		}
	}
	
	public function getGameTime(){
		return $this->time;
	}
	
	public function getReadyTime(){
		return $this->info["ready-time"];
	}
	
	public function getWarTime(){
		return $this->info["war-time"];
	}
	
   public function getChestTime(){
	   return $this->info["chest-time"];
   }
	
	public function getBridgeTime(){
		return $this->info["generate-time"];
	}
	
   public function getDuelTime(){
	   return max($this->getWarTime(),$this->getBridgeTime())+240;
   }
	
	public function getRollbackTime(){
		return $this->info["rollback-time"];
	}
	
	public function getLimitTime(){
		return $this->info["limit-time"];
	}
	
	public function getChapterBlock(){
		return $this->chapterblock;
	}
	
	public function getCenterPos(){
		$pos = new Position($this->info["center"]["x"], $this->info["center"]["y"], $this->info["center"]["z"], $this->getGameLevel());
		return $pos;
	}
	
	public function getWaitPos(){
		$pos = new Position($this->info["wait"]["x"], $this->info["wait"]["y"], $this->info["wait"]["z"], $this->getWaitLevel());
		return $this->plugin->getSafePos($pos);
	}
	
	public function getWaitLevel(){
		return $this->plugin->getServer()->getLevelByName($this->info["wait"]["level"]);
	}
	
	public function getGamePos($team){
		$pos = new Position($this->info[$team]["x"], $this->info[$team]["y"], $this->info[$team]["z"], $this->getGameLevel());
		return $this->plugin->getSafePos($pos);
	}
	
	public function getGameLevel(){
		return $this->plugin->getServer()->getLevelByName($this->info["game-level"]);
	}
	
	public function getStopPos(){
		$pos = new Position($this->info["stop"]["x"], $this->info["stop"]["y"], $this->info["stop"]["z"], $this->getStopLevel());
		return $this->plugin->getSafePos($pos);
	}
	
	public function getStopLevel(){
		return $this->plugin->getServer()->getLevelByName($this->info["stop"]["level"]);
	}
	
	public function getPlayers($team = "all"){
		$array = [];
		foreach($this->gamers[$team] as $name){
			$player = $this->plugin->getServer()->getPlayerExact($name);
			if($player instanceof Player){
				$array[] = $player;
			}
		}
		unset($player);
		return $array;
	}
	
	public function getTeam($player){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$player = strtolower($player);
		foreach($this->gamers as $team => $names){
			if($team !== "all"){
				foreach($names as $name){
					if($name == $player){
						return $team;
					}
				}
			}
		}
		foreach($this->spectators as $team => $names){
			if($team !== "all"){
				foreach($names as $name){
					if($name == $player){
						return $team;
					}
				}
			}
		}
		return null;
	}
	
	public function getMax(){
		if(!isset($this->info["max"])){
			return 0;
		}
		return $this->info["max"];
	}
	
	public function getMin(){
		if(!isset($this->info["min"])){
			return 0;
		}
		return $this->info["min"];
	}	
	
	public function getMaxTeam($team){
		if(!isset($this->info[$team]["max"])){
			return 0;
		}
		return $this->info[$team]["max"];
	}
	
	public function getMinTeam($team){
		if(!isset($this->info[$team]["min"])){
			return 0;
		}
		return $this->info[$team]["min"];
	}
	
	public function TimeAttribute($time){
		$str = "§a遊戲將在 §c".$time." §a秒後開啟\n";
		switch($time){
			case 5:
			$str .= 
			"§7     █████\n".
			"§7     █\n".
			"§7     █████\n".
			"§7              █\n".
			"§7     █████";
			break;
			case 4:
			$str .= 
			"§7     █       █\n".
			"§7     █       █\n".
			"§7     █████\n".
			"§7              █\n".
			"§7              █";
			break;
			case 3:
			$str .= 
			"§6     █████\n".
			"§6              █\n".
			"§6     █████\n".
			"§6              █\n".
			"§6     █████";
			break;
			case 2:
			$str .= 
			"§6     █████\n".
			"§6              █\n".
			"§6     █████\n".
			"§6     █\n".
			"§6     █████";
			break;
			case 1:
			$str .= 
			"§e         █\n".
			"§e         █\n".
			"§e         █\n".
			"§e         █\n".
			"§e         █";
			break;
			case 0:
			$str .= 
			"§3     █████\n".
			"§3     █       █\n".
			"§3     █       █\n".
			"§3     █       █\n".
			"§3     █████";
			break;
		}
		$this->wTip($str);
	}
	
	public function getChapterName(){
		return $this->info["chapter"];
	}
	
	public function getChapter(){
		return $this->chapter;
	}
	
	public function colorArmor($item, $team){
		if($item instanceof \pocketmine\item\Armor and $this->plugin->isPHP7()){
			switch($team){
					case "red":
					$item->setCustomColor(\pocketmine\utils\Color::getRGB(255,48,48));
					break;
					
					case "blue":
					$item->setCustomColor(\pocketmine\utils\Color::getRGB(0,255,255));
					break;
					
					case "yellow":
					$item->setCustomColor(\pocketmine\utils\Color::getRGB(255,255,0));
					break;
					
					case "green":
					$item->setCustomColor(\pocketmine\utils\Color::getRGB(0,205,0));
					break;
			}
			return $item;
		}
		return $item;
	}
	
	public function spawn($player){
		if($this->isStarted()){
			if($this->isSpectator($player))return;
			$team = $this->getTeam($player);
			if($team !== null){
				$pos = $this->getGamePos($team);
				$player->teleport($pos);
				$player->getLevel()->loadChunk($pos->getX() >> 4,$pos->getZ() >> 4);
				$this->plugin->calculate($player,"start");
				$inventory = $player->getInventory();
				$inventory->clearAll();
				$player->gamemode = 4;
				$player->setGamemode(0);
				$player->MsetAllowFlight(false);
				$player->MsetFlying(false);
				$this->plugin->calculate($player,"start");
				if(!$this->plugin->isVIP($player)){
	            $inventory->setHelmet($this->colorArmor(Item::get(298, 0, 1), $team));
                $inventory->setChestplate($this->colorArmor(Item::get(299, 0, 1), $team));
                $inventory->setLeggings($this->colorArmor(Item::get(300, 0, 1), $team));
                $inventory->setBoots($this->colorArmor(Item::get(301, 0, 1), $team));
                $inventory->sendArmorContents($player);
				$inventory->addItem(clone Item::get(267, 0, 1));  //鐵劍
				$inventory->addItem(clone Item::get(257, 0, 1));  //鐵鎬
				$inventory->addItem(clone Item::get(256, 0, 1));  //鐵鏟
				$inventory->addItem(clone Item::get(364, 0, 5));  //烤牛排
		#		$inventory->addItem(clone Item::get(332, 0, 1));  //雪球
				$inventory->sendContents($player);
				}else{
	            $inventory->setHelmet($this->colorArmor(Item::get(306, 0, 1), $team));
                $inventory->setChestplate($this->colorArmor(Item::get(307, 0, 1), $team));
                $inventory->setLeggings($this->colorArmor(Item::get(308, 0, 1), $team));
                $inventory->setBoots($this->colorArmor(Item::get(309, 0, 1), $team));
                $inventory->sendArmorContents($player);
				$inventory->addItem(clone Item::get(276, 0, 1));  //鑽劍
				$inventory->addItem(clone Item::get(257, 0, 1));  //鐵鎬
				$inventory->addItem(clone Item::get(256, 0, 1));  //鐵鏟
				$inventory->addItem(clone Item::get(364, 0, 5));  //烤牛排
				$inventory->addItem(clone Item::get(322, 0, 1));  //金蘋果
		#		$inventory->addItem(clone Item::get(332, 0, 3));  //雪球
				$inventory->sendContents($player);
				}
				$player->setMaxHealth(20 + $this->plugin->config["會員額外血量(遊戲中將乘以VIP等級)"]*$this->plugin->mgb->getVIP($player));
				$player->setHealth($player->getMaxHealth());
				$player->setSprinting(false);
				$player->setSneaking(false);
				$player->extinguish();
				$player->removeAllEffects();
				$player->MsetAllowFlight(false);
				$player->MsetFlying(false);
				unset($inventory,$player);
			}else{
				$this->joinTeam($player, "random", true);
				return $this->spawn($player);
			}
		}else{
			if($this->isSpectator($player))return;
			$this->plugin->saveInventory($player);
			$player->gamemode = 4;
			if($player->getGamemode() != 0) $player->setGamemode(0);
			$player->setNametag("§7[未選擇]§f".$this->plugin->mgb->getMP($player)->getGamename());
			$pos = $this->getWaitPos();
			$player->teleport($pos);
			//$player->getLevel()->loadChunk($pos->getX() >> 4,$pos->getZ() >> 4);
			$inventory = $player->getInventory();
			$inventory->clearAll();
//			$inventory->addItem(clone Item::get(288,0,1));//羽毛 查看該房間玩家
			$inventory->addItem(clone Item::get(318, 0, 1));//燧石 退出
			$inventory->addItem(clone Item::get(352, 0, 1));//骨頭 選擇隊伍
			$inventory->sendContents($player);
            $player->setSprinting(false);
            $player->setSneaking(false);
            $player->extinguish();
			$player->removeAllEffects();
			$player->MsetAllowFlight(false);
			$player->setMaxHealth(40 + $this->plugin->config["會員額外血量(遊戲中將乘以VIP等級)"]*$this->plugin->mgb->getVIP($player));
			$player->setHealth($player->getMaxHealth());
			unset($inventory,$player);
		}
		return true;
	}
	
	public function respawn($player){
		$player->setHealth($player->getMaxHealth());
		$inventory = $player->getInventory();
		$inventory->clearAll();
		$team = $this->getTeam($player);
	    $inventory->setHelmet($this->colorArmor(Item::get(298, 0, 1), $team));
        $inventory->setChestplate($this->colorArmor(Item::get(299, 0, 1), $team));
        $inventory->setLeggings($this->colorArmor(Item::get(300, 0, 1), $team));
        $inventory->setBoots($this->colorArmor(Item::get(301, 0, 1), $team));
        $inventory->sendArmorContents($player);
		$inventory->addItem(clone Item::get(267, 0, 1));  //鐵劍
		$inventory->addItem(clone Item::get(257, 0, 1));  //鐵鎬
		$inventory->addItem(clone Item::get(256, 0, 1));  //鐵鏟
		$inventory->addItem(clone Item::get(364, 0, 5));  //烤牛排
		$inventory->sendContents($player);
		$team = $this->getTeam($player);
		if($team !== null){
			$this->wPopup("game.respawn", [$this->plugin->mgb->getMP($player)->getGamename()], $team);
			return $this->getGamePos($team);
		}else{
			return $this->getWaitPos();
		}
	}
	
	public function spectate($player, $step = 1){
		if($this->getChapter()->onSpectate($player, $step) === "default"){
		if(!$this->isSpectator($player)){
			switch($step){
			case 0:
			if(!$this->isIn($player))return;
			$team = $this->getTeam($player);
			if($team !== null){
				$this->wPopup("game.spectate", [$this->plugin->mgb->getMP($player)->getGamename()], $team);
				return $this->getGamePos($team);
			}else{
				return $this->plugin->getSafePos($this->getCenterPos());
			}
			
			case 1:
			if(!$this->isIn($player))return;
			$this->spectators["all"][] = strtolower($player->getName());
			$player->gamemode = 4;
			$player->setGamemode(3);
			$this->plugin->hidePlayer($player);
			$this->wPopup("game.spectate", [$this->plugin->mgb->getMP($player)->getGamename()]);
            /*$pk = $this->plugin->getPacketObj("ContainerSetContentPacket");
			if($pk != false){
				$pk->windowid = 0x79;
				$player->dataPacket($pk);				
			}*/
			$inventory = $player->getInventory();
			$inventory->clearAll();
            $inventory->setHeldItemIndex(1);
            $inventory->addItem(clone Item::get(318,0,1));
			$inventory->addItem(clone Item::get(288,0,1));
			$inventory->addItem(clone Item::get(403,0,1));
            $inventory->sendContents($player);
            $inventory->sendContents($player->getViewers());
			$team = $this->getTeam($player);
			if($team !== null){
				$this->quitTeam($player);
				$this->spectators[$team][] = strtolower($player->getName());
				$this->ifwin();
				return $this->getGamePos($team);
			}else{
				return $this->plugin->getSafePos($this->getCenterPos());
			}
			
			case 2:
			$this->plugin->mgb->getMP($player)->setRoom($this->plugin->getGameName(), $this->getID());
			$this->spectators["all"][] = strtolower($player->getName());
			$this->gamers["all"][] = strtolower($player->getName());
			$config = $this->plugin->getPlayerConfig($player);
			$config->set("Quit",1);
			$config->save();
			$player->teleport($this->plugin->getSafePos($this->getCenterPos()));
			if($player->getGamemode() == 0){
				$this->plugin->saveInventory($player);
			}
			$player->gamemode = 4;
			$player->setGamemode(3);
			$this->plugin->hidePlayer($player);
			$this->wPopup("game.spectate", [$this->plugin->mgb->getMP($player)->getGamename()]);
			$inventory = $player->getInventory();
			$inventory->clearAll();
            $inventory->setHeldItemIndex(1);
            $inventory->addItem(clone Item::get(318,0,1));
			$inventory->addItem(clone Item::get(403,0,1));
			$inventory->addItem(clone Item::get(288,0,1));
            $inventory->sendContents($player);
            $inventory->sendContents($player->getViewers());
			unset($inventory,$player);
			return true;
		}
		}else{
			return false;
		}
		}
	}
	
	public function win($team){
		foreach($this->getPlayers($team) as $player){
			$this->sendMessage($player, $this->plugin->getMessage($player, "win"));
			$config = $this->plugin->getPlayerConfig($player);
			$config->set("Win",$config->get("Win")+1);
			$config->save();
			unset($config);
			$this->plugin->calculate($player,"win",1);
			$this->plugin->updateRanking($player);
			$this->plugin->mgb->updateCoin($player, 20);
			foreach($this->plugin->config["遊戲結束玩家勝利後服務器自動使用指令(%p代表此玩家的名字)"] as $command){
				$command = str_replace("%p", $player->getName(), $command);
				 $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), $command);
			}
		}
		unset($player);
	}
	
	public function lose($team){
		foreach($this->getPlayers($team) as $player){
			$this->sendMessage($player, $this->plugin->getMessage($player, "lose"));
			$config = $this->plugin->getPlayerConfig($player);
			$config->set("Lose",$config->get("Lose")+1);
			$config->save();
			unset($config);
			$this->plugin->calculate($player,"lose",1);
			$this->plugin->mgb->updateCoin($player, 5);
			foreach($this->plugin->config["遊戲結束玩家失敗後服務器自動使用指令(%p代表此玩家的名字)"] as $command){
				$command = str_replace("%p", $player->getName(), $command);
				 $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), $command);
			}
		}
		unset($player);
	}
	
	public function ban($player){
		if($player instanceof Player){
			$this->info["banners"][] = strtolower($player->getName());
			$this->quitPlayer($player);
		}else{
			$this->info["banners"][] = strtolower($player);
		}
		unset($player);
	}
	
	public function wMessage($str, $array = [], $team = "all"){
		foreach($this->getPlayers($team) as $player){
			$this->sendMessage($player, $this->plugin->getMessage($player, $str, $array));
		}
		unset($str,$player);
	}
	
	public function wTip($str, $array = [], $team = "all"){
		foreach($this->getPlayers($team) as $player){
			$this->sendTip($player, $this->plugin->getMessage($player, $str, $array));
		}
		unset($str,$player);
	}

	public function wPopup($str, $array = [], $team = "all"){
		foreach($this->getPlayers($team) as $player){
			$this->sendPopup($player, $this->plugin->getMessage($player, $str, $array));
		}
		unset($str,$player);
	}
	
	public function wTitle($str, $array = [], $team = "all"){
		try{
			if(!method_exists(Player::class, 'sendTitle')){
				return false;
			}
			$message = $this->plugin->getMessage(null, $str, $array);
			$pos = stripos($message,"\n");
			if($pos == false){
				$pos = strlen($str) + 1;
			}
			$title = mb_substr($message, 0,$pos,'utf-8');
			$subtitle = mb_substr($message, $pos+2,null,'utf-8');
			if($subtitle == null){
				$subtitle = "";
			}
			foreach($this->getPlayers($team) as $player){
				$player->sendTitle($title, $subtitle);
			}
			unset($str,$player);			
		}catch(\Exception $e){
			echo "1";
		}
	}

	
	public function sendMessage($player, $str){
		if($player instanceof Player){
			$pk = $this->plugin->getPacketObj("TextPacket");
			if($pk != false){
				$pk->type = 0;
				$pk->message = $str;
				@$player->MdataPacket($pk,false,true);
			}
		}else{
			$player->sendMessage($str);
		}
	}

	
	public function sendTip($player, $str){
		if($player instanceof Player){
			$pk = $this->plugin->getPacketObj("TextPacket");
			if($pk != false){
				$pk->type = 4;
				$pk->message = $str;
				@$player->MdataPacket($pk,false,true);
			}
		}else{
			$player->sendMessage($str);
		}
	}	

	public function sendPopup($player, $str, $sub= ""){
		if($player instanceof Player){
			$pk = $this->plugin->getPacketObj("TextPacket");
			if($pk != false){
				$pk->type = 3;
				$pk->message = $sub;
				$pk->source = $str;
				@$player->MdataPacket($pk,false,true);						
			}
		}else{
			$player->sendMessage($str);
		}
	}
}


?>