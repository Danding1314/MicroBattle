<?php
namespace MBattleBridge;

use pocketmine\command\Command;
use pocketmine\command\CommandExecutor;
use pocketmine\command\CommandSender;

use pocketmine\event\Listener;
use pocketmine\entity\Effect;
use pocketmine\item\Item;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityRegainHealthEvent;
use pocketmine\inventory\PlayerInventory;
use pocketmine\level\Level;
use pocketmine\block\Block;
use pocketmine\level\Position;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\level\particle\Particle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\HeartParticle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\particle\RedstoneParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\WaterParticle;
use pocketmine\level\sound\ClickSound;
use pocketmine\level\sound\DoorSound;
use pocketmine\level\sound\LaunchSound;
use pocketmine\level\sound\PopSound;

use pocketmine\block\Chest;
use pocketmine\tile\Tile;
use pocketmine\tile\Chest as TileChest;
use pocketmine\level\format\mcregion\Chunk;
use pocketmine\level\format\FullChunk;
use pocketmine\tile\Sign as TileSign;

use pocketmine\scheduler\PluginTask;

use pocketmine\plugin\PluginBase;
use pocketmine\Player;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Config;
use pocketmine\math\Vector3 as Vector3;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\EnumTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;

use MBattleBridge\Language;
use MGameBase\MGameBase;
use MBattleBridge\chapters\Chapter;
class MBattleBridge extends PluginBase implements Listener{
	
	const FORMAT = "§l§7|§a戰§b橋§7|§r§o ";
		
	public static $MGB_VERSION = 51;	
		
	public $listener;
	/** @var  BeerMC */
    public static $instance;
		
	public $rooms;
	
	public $roomsinfo;
		
	public $path;
	
	public $signs;
		
	public static $allchapters = ["alaska","venice","arctic","australia","sahara","bedwars","skywars","moon"];
	
	public static $defaultchapter = "arctic";
	
	public static $allteams = ["red","blue","green","yellow"];
	
	public static $allcolors = ["red"=>"§c","blue"=>"§b","green"=>"§a","yellow"=>"§e"];
	
	public static $room_info_format = [
	"max" => 40,
	"min" => 4,
	"red" => ["x"=>0,"y"=>0,"z"=>0,"max"=>10,"min"=>1],
	"blue" => ["x"=>0,"y"=>0,"z"=>0,"max"=>10,"min"=>1],
	"green" => ["x"=>0,"y"=>0,"z"=>0,"max"=>10,"min"=>1],
	"yellow" => ["x"=>0,"y"=>0,"z"=>0,"max"=>10,"min"=>1],
	"teammate-damage" => 0,
	"neglectable-balance" => 1,
	"level-time" => 10000,
	"ready-time" => 30,
	"war-time" => 360,
	"chest-time" => 400,
	"generate-time" => 400,
	"rollback-time" => 3,
	"limit-time" => 3600,
	"banners" => [],
	];
	
	public function isNewAPI(){
		$reflector = new \ReflectionClass('\pocketmine\tile\Tile');
		$parameters = $reflector->getMethod('createTile')->getParameters();
		if(is_object($parameters[1])){
			if(stripos($parameters[1]->name, "level") !== false or $parameters[1] instanceof Level){
				return true;
			}
		}
		return false;
	}
	
	public static function getInstance(){
		return self::$instance;
	}	
	
	public static function getGameName(){
		return "MBattleBridge";
	}
	
	public static function getGameAbbreviation(){
		return "MbB";
	}
	
	public function checkMGameBase(){
		if(($plugin = $this->getServer()->getInstance()->getPluginManager()->getPlugin("MGameBase")) == null){
			$this->getLogger()->info("§c本插件需要MGameBase才可使用");
			$this->getLogger()->info("§dMGameBase的下載鏈接:http://pan.baidu.com/s/1hsqa9Q8");
			return false;
		}elseif($plugin->getDescription()->getVersion() < self::$MGB_VERSION){
			$this->getLogger()->info("§c本插件需要MGameBase_v".self::$MGB_VERSION."才可使用");
			return false;
		}
		return true;
	}
		/*
public function check()
	{
		return;
		$this->getServer()->broadcastMessage("§e▃▃▃▃▃▃▃▃▃▃▃▃▃");
		$this->getServer()->broadcastMessage(self::FORMAT."§b開始檢測更新！");
		try
		{
			$name=self::getGameName();
			$ver=file_get_contents("http://cdn.diqiucloud.com:88/plugins/Matt/${name}/ver.txt");
			if(version_compare($ver,$this->getDescription()->getVersion())<=0){
				$this->getServer()->broadcastMessage("§e這個插件為最新版本！");
				$this->getServer()->broadcastMessage("§e▃▃▃▃▃▃▃▃▃▃▃▃▃");
			}
			else
			{
				$自動更新=$this->config["自動更新"];
				if($自動更新=="true")
				{
					$this->getServer()->broadcastMessage(self::FORMAT."§4開始自動下載最新版插件……");
					$this->update();
				}
				else
				{
					$this->getServer()->broadcastMessage(self::FORMAT."§4插件有新版本！");
					$this->getServer()->broadcastMessage("§5請輸入[/bb update]來更新插件！");
				}
				$this->getServer()->broadcastMessage("更新日誌：".file_get_contents("http://cdn.diqiucloud.com:88/plugins/Matt/${name}/log.txt"));
				$this->getServer()->broadcastMessage("§e▃▃▃▃▃▃▃▃▃▃▃▃▃");
			}
		}
		catch(\Exception $e)
		{
			$this->getServer()->broadcastMessage(self::FORMAT."§4[插件自動檢查更新]失敗！請聯系作者！");
			$this->getServer()->broadcastMessage("§e▃▃▃▃▃▃▃▃▃▃▃▃▃");
		}
	}

	 public function update()
	{
		return;
		$this->getServer()->broadcastMessage("§e▃▃▃▃▃▃▃▃▃▃▃▃▃");
		$this->getServer()->broadcastMessage(self::FORMAT."§5插件開始自動更新插件！");
		$name=self::getGameName();
		$ver=file_get_contents("http://cdn.diqiucloud.com:88/plugins/Matt/${name}/ver.txt");
		try
		{
			if(version_compare($ver,$this->getDescription()->getVersion())<=0)
			{
				$this->getServer()->broadcastMessage(self::FORMAT."§3插件已經是最新版了！");
				$this->getServer()->broadcastMessage("§e▃▃▃▃▃▃▃▃▃▃▃▃▃");
			}
			else
			{
				$rawname=null;
				if(substr(PHP_VERSION,0,3)=='5.6')
				{
					$rawname='[5.6]'.$name.'_v'.$ver;
				}
				if(substr(PHP_VERSION,0,3)=='7.0')
				{
					$rawname='[7.0]'.$name.'_v'.$ver;
				}
				if($rawname==null)
				{
					$this->getServer()->broadcastMessage("§3您的PHP版本出現錯誤！");
					$this->getServer()->broadcastMessage("§e▃▃▃▃▃▃▃▃▃▃▃▃▃");
					return true;
				}
				$rawdata=file_get_contents("http://cdn.diqiucloud.com:88/plugins/Matt/${name}/${rawname}.phar");
				$cwd=$this->getserver()->getpluginPath().basename(dirname(dirname(dirname(__FILE__))));
				$old = umask(0);
				chmod($cwd,0777);
				umask($old);
				//$srcdata=file_get_contents($cwd);
				file_put_contents($cwd,$rawdata);
				$this->getServer()->broadcastMessage(self::FORMAT."§3插件自動更新完畢！§d將在3秒後重啟服務器！§e[§1$rawname"."§e]");
				$this->getServer()->broadcastMessage("§e▃▃▃▃▃▃▃▃▃▃▃▃▃");
				sleep(3.5);
				$this->getserver()->shutdown();
			}
		}
		catch(\Exception $e)
		{
			$this->getServer()->broadcastMessage(self::FORMAT."§3[自動更新插件]失敗！請聯系作者！");
			$this->getServer()->broadcastMessage("§e▃▃▃▃▃▃▃▃▃▃▃▃▃");
		}
	}
		*/
	public function onLoad(){
		self::$instance = $this;	
	}
	
	public $newapi;
	
	public $commands = [
		"bb" => "\\MBattleBridge\\BBCommand"
	];
		
	
	public function registerCommands(){
		$map = $this->getServer()->getCommandMap();
		foreach($this->commands as $cmd => $class){
			$map->register($cmd, new $class($this));
		}
	}		
	
	public function onEnable(){
		if(!$this->checkMGameBase()){
			return false;
		}
        $this->getLogger()->info("§d開始初始化...");
		if($this->isNewAPI()){
			$this->newapi = true;
		}else{
			$this->newapi = false;
		}
		$this->loadAllLevels();
		$this->listener = new EventListener($this);
		$this->getServer()->getPluginManager()->registerEvents($this->listener, $this);
		
		$this->mgb = MGameBase::getInstance();

		$this->path = $this->getDataFolder();
		@mkdir($this->path . "rooms/", 0777, true);
		$this->config = (new Config($this->path . "config.yml", Config::YAML))->getAll();
		$this->loadConfig();
		$this->rooms = [];
		$this->signs = (new Config($this->path . "signs.yml", Config::YAML))->getAll();
		$this->loadSigns();
		$this->loadRooms();
		$this->getLogger()->info("§a初始化完畢");
		$this->ranking = new FloatingTextParticle(new Vector3(0,0,0),"","");
		if(is_array($this->config["排行榜坐標"])){
			$this->ranking->x = $this->config["排行榜坐標"]["x"];
			$this->ranking->y = $this->config["排行榜坐標"]["y"];
			$this->ranking->z = $this->config["排行榜坐標"]["z"];
		}
		$this->convertRanking();
		foreach($this->getAllRooms() as $room){
			if($room instanceof Room){
				$room->stop(true);
			}
		}
		$this->registerCommands();
	}
	
	public function onDisable(){
		$this->saveSigns();
		$this->saveConfigs();
		$this->saveRooms();
		foreach($this->getAllRooms() as $room){
			$room->stop(true);
		}
	}
	
	public function isPHP7(){
		if(in_array(substr(PHP_VERSION,0,1),["7",7])){
			return true;
		}
		return false;	
	}
	
	public function getPacketObj($name){
		if(class_exists('\pocketmine\network\protocol'."\\".$name, false)){
			$str = '\pocketmine\network\protocol'."\\".$name;
			return new $str();
		}elseif(class_exists('\pocketmine\network\mcpe\protocol'."\\".$name, false)){
			$str = '\pocketmine\network\mcpe\protocol'."\\".$name;
			return new $str();
		}else{
			return false;
		}
	}	
	
	public function LoadAllLevels(){
		$level = $this->getServer()->getDefaultLevel();
   		$path = $level->getFolderName();
   		$p1 = dirname($path);
   		$p2 = $p1."/worlds/";
   		$dirnowfile = scandir($p2, 1);
        foreach ($dirnowfile as $dirfile){
	    	if($dirfile != '.' && $dirfile != '..' && $dirfile != $path && is_dir($p2.$dirfile)) {
				if (!$this->getServer()->isLevelLoaded($dirfile)) {  //如果這個世界未加載
					$this->getLogger()->info(TextFormat::YELLOW . "正在加載世界：$dirfile");
					$this->getServer()->generateLevel($dirfile);
					$this->getServer()->loadLevel($dirfile);
				}
			}
	  	}
	}	

    public function loadConfig(){
    	$configs = [
    	"註意" => '選項的格式:true為打開,false為關閉,加入其他字符的後果自負',
		"自動更新" => true,
		"阻止玩家高頻刷戰橋類行動" => true,
		"螺旋粒子開關" => true,
		"自動生成遊戲地圖礦物(生成時服務器性能不好的可能會卡頓十多秒)" => true,
		"遊戲途中處理其他popup和tip消息(0為不啟用但容易造成消息沖突閃爍,1為屏蔽其他消息【建議】,2為轉化為message但容易刷屏)" => 1,
		"會員額外血量(遊戲中將乘以VIP等級)" => 10,
		"擊殺獲得金幣量" => 5,
		"點擊方塊進行某行動的額外確認次數" => 1,
		"遊戲結束玩家勝利後服務器自動使用指令(%p代表此玩家的名字)" => [],
		"遊戲結束玩家失敗後服務器自動使用指令(%p代表此玩家的名字)" => [],
		"禁止OP破壞遊戲地圖的方塊"=>true,
		"禁止OP遊戲中輸入其他指令"=>true,
		"排行榜" => ["未知1"=>0,"未知2"=>0,"未知3"=>0,"未知4"=>0,"未知5"=>0,"未知6"=>0,"未知7"=>0,"未知8"=>0,"未知9"=>0,"未知10"=>0],
		"排行榜坐標" => null,
    	];
    	foreach ($configs as $key => $value) {
    		if(isset($this->config[$key]) == false){
				$this->config[$key] = $value;
				@$this->getServer()->getLogger()->info("§7[初始化]已將§a".$key."§7設置為§b".$value);
    		}
			if(is_array($value)){
				foreach($value as $key2 => $val2){
					if(!isset($this->config[$key][$key2])){
						$this->config[$key][$key2] = $val2;
						@$this->getServer()->getLogger()->info("§7[初始化]已將§a".$key."§7中的§a".$key2."§7設置為§b".$val2);
					}
				}
			}
    	}
    	$this->saveConfigs();
		if($this->config["遊戲途中處理其他popup和tip消息(0為不啟用但容易造成消息沖突閃爍,1為屏蔽其他消息【建議】,2為轉化為message但容易刷屏)"] !== 0){
			if(!defined(self::getGameName())){
				define(self::getGameName(),"true");
			}
		}else{
			if(!defined(self::getGameName())){
				define(self::getGameName(),"false");
			}
		}
    }
	
    public function saveConfigs(){
    	$config = new Config($this->path . "config.yml",Config::YAML);
    	if(!isset($this->config)){
    		$config->setAll(array());
    	}elseif(!is_array($this->config)){
			$config->setAll(array());
    	}else{
    		$config->setAll($this->config);
    	}
    	$config->save();
    }
	
    public function loadSigns(){
		$this->signs = (new Config($this->path . "signs.yml", Config::YAML))->getAll();
    }
	
	public function saveSigns(){
		$file = new Config($this->path."signs.yml", Config::YAML);
		$file->setAll($this->signs);
		$file->save();
	}
	
	public function updateSigns(){
		foreach($this->signs as $loc => $info){
			if($info["type"] == "join" and isset($this->rooms[$info["room"]])){
				$pos = new Vector3($info["x"],$info["y"],$info["z"]);
				if(($level = $this->getServer()->getLevelByName($info["level"])) instanceof Level){
				$tile = $level->getTile($pos);
				if($tile instanceof TileSign){
					$lines = $tile->getText();
					$room = $this->getRoom($info["room"]);
					if(!$room->isStarted()){
						if($room->isLoaded()){
							$tile->setText($lines[0],$lines[1],$lines[2],'§l§c<§f---§b'.$room->getPlayerNum().'§7/§e'.$room->getMax().'§f---§c>');
						}else{
							$tile->setText($lines[0],$lines[1],$lines[2],'§l§c<§f---§c未加載§f---§c>');
						}
					}else{
					$tile->setText($lines[0],$lines[1],$lines[2],'§l§c<§f---§c已開始§f---§c>');
					}
				}
				unset($pos,$tile);
				}
			}
		}
	}
	
	public function updateRanking($player){
		if($player instanceof Player){
			$name = $player->getName();
		}else{
			$name = $player;
		}
		$config = $this->getPlayerConfig($name)->getAll();
		$win = $config["Win"];
		$new = $this->config["排行榜"];
		$new[$name] = $win;
		arsort($new);
		$new = array_slice($new,0,10);
		if(array_slice($this->config["排行榜"],0,10) !== $new){
			$this->config["排行榜"] = $new;
			$this->saveConfigs();
			$this->convertRanking();
		}
	}
	
	public function str2hex($str){
		$hex = '';
		for($i=0,$length=mb_strlen($str); $i<$length; $i++){
			$hex .= dechex(ord($str{$i}));
		}
		return $hex;
	}	
	
	public function convertRanking(){
		$rank = [];
		$ranking = $this->config["排行榜"];
		$i = 1;
		foreach($ranking as $name => $win){
			if(strpos($this->str2hex($name),$this->str2hex("未知")) !== false){
				$list = ["Kill"=>0, "Death"=>0, "Win"=>0, "Lose"=>0, "Win"=>0];
			}else{
				$list = $this->getPlayerConfig($name)->getAll();
			}
			$rank[$i] = ["name"=>$name,"kill"=>$list["Kill"],"death"=>$list["Death"],"win"=>$list["Win"],"total"=>$list["Lose"]+$list["Win"]];
			$i += 1;
		}
		$this->ranking->setTitle(self::FORMAT."§6全服排行  §a勝利  §b局數  §e消滅 §c死亡");
		$str = 
		"§6No.1§a === §6".$rank[1]["name"]."§5  >>>  "."§7/§a  ".$rank[1]["win"]."  §7/§b  ".$rank[1]["total"]."  §7/§e  ".$rank[1]["kill"]."  §7/§c  ".$rank[1]["death"]."\n".
		"§cNo.2§a === §c".$rank[2]["name"]."§5  >>>  "."§7/§a  ".$rank[2]["win"]."  §7/§b  ".$rank[2]["total"]."  §7/§e  ".$rank[2]["kill"]."  §7/§c  ".$rank[2]["death"]."\n".
		"§3No.3§a === §3".$rank[3]["name"]."§5  >>>  "."§7/§a  ".$rank[3]["win"]."  §7/§b  ".$rank[3]["total"]."  §7/§e  ".$rank[3]["kill"]."  §7/§c  ".$rank[3]["death"]."\n";
		for($i = 4;$i <= 10;$i++){
			$str .= "§fNo.".$i."§a === §f".$rank[$i]["name"]."§5  >>>  "."§7/§a  ".$rank[$i]["win"]."  §7/§b  ".$rank[$i]["total"]."  §7/§e  ".$rank[$i]["kill"]."  §7/§c  ".$rank[$i]["death"]."\n";
		}
		$this->ranking->setText($str);
	}
	
	public function loadRooms(){
		$files = preg_grep("/\.yml$/", scandir($this->path. "rooms/"));
		foreach($files as $file){
			$this->loadRoom(basename($file,".yml"));
		}
		$this->saveRooms();
	}
	
	public function loadRoom($id){
		$config = (new Config($this->path . "rooms/".$id.".yml",Config::YAML))->getAll();
		if($config !== null){
			$this->roomsinfo[$id] = $config;
			$room = new Room($this, $id);
			$this->rooms[$id] = $room;
		}
	}
	
	public function getRoom($id){
		if(isset($this->rooms[$id])){
			return $this->rooms[$id];
		}
		return null;
	}
	
	public function getRoomInfo($id){
		if(isset($this->roomsinfo[$id])){
			return $this->roomsinfo[$id];
		}
		return null;
	}

    public function saveRooms($id = null){
		if($id == null){
			foreach($this->getAllRooms() as $room){
				$config = new Config($this->path . "rooms/".$room->getID().".yml",Config::YAML);
				if($config->getAll() !== null and $config->getAll() !== []){
					$config->setAll($this->roomsinfo[$room->getID()]);
					$config->save();
				}else{
					$room->delete();
				}
			}
		}else{
			if($this->getRoom($id) !== null){
				$config = new Config($this->path . "rooms/".$id.".yml",Config::YAML);
				if($config->getAll() !== null and $config->getAll() !== []){
					$config->setAll($this->roomsinfo[$id]);
					$config->save();
				}else{
					$room->delete();
				}
			}
		}
    }
	
	/*public function findRoom($player){
		if($player instanceof Player){
			if(($room = $player->getRoom(self::getGameName())) !== null){
				return $room;
			}
			$player = $player->getName();
		}
		$player = strtolower($player);
		foreach($this->getAllRooms() as $room){
			if($room->isIn($player)){
				return $room;
			}
		}
		return null;
	}*/
	
	public function findRoom($player){
		if($player instanceof Player){
			$mp = $this->mgb->getMP($player);
			if($mp != null){
				if(!($room = $mp->getRoom(self::getGameName()))){
					$player = $player->getName();
				}else{
					return $room;
				}
			}else{
				$player = $player->getName();
			}
		}
		$player = strtolower($player);
		foreach($this->getAllRooms() as $room){
			if($room->isIn($player)){
				return $room;
			}
		}
		return null;
	}
	
	public static function getMessage($player, $str, $array = []){
		if(isset(Language::$message[$str])){
			$msg = Language::$message[$str];
			foreach($array as $key => $val){
				$msg = str_replace("%".$key, $val, $msg);
			}
			if($player !== null){
				$msg = self::FORMAT.$msg;
			}
		}else{
			$msg = $str;
		}
		$msg = str_replace("red", "§c紅§f", $msg);
		$msg = str_replace("green", "§a綠§f", $msg);
		$msg = str_replace("blue", "§b藍§f", $msg);
		$msg = str_replace("yellow", "§e黃§f", $msg);
		return $msg;
	}
	
	public function configExists($player){
		return $this->mgb->configExists($player, self::getGameName());
	}
	
	public function getPlayerConfig($player){
		return $this->mgb->getPlayerConfig($player, self::getGameName());
	}
	
	public function getPlayerNameTag($player){
		if($player instanceof Player){
			$player = $player->getName();
		}
		$nametag = $this->getPlayerConfig($player)->getAll()["Nametag"];
		if($nametag == 0){
			return $player;
		}else{
			return $nametag;
		}
	}
		
	public function isVIP($player){
		return $this->mgb->isVIP($player);
	}
	
	public function isSVIP($player){
		return $this->mgb->isSVIP($player);
	}
	
	public function createRoom($id, $values){
		$this->roomsinfo[$id] = $values;
		foreach(self::$room_info_format as $key => $val){
			if(isset($this->roomsinfo[$id][$key])){
				if(is_array($val)){
					foreach($val as $key2 => $val2){
						if(!isset($this->roomsinfo[$id][$key][$key2])){
							$this->roomsinfo[$id][$key][$key2] = $val2;
						}
					}
				}
			}else{
				if(is_array($val)){
					foreach($val as $key2 => $val2){
						$this->roomsinfo[$id][$key][$key2] = $val2;
					}
				}else{
					$this->roomsinfo[$id][$key] = $val;
				}
			}
		}
		$config = new Config($this->path . "rooms/".$id.".yml",Config::YAML);
		$config->setAll($this->roomsinfo[$id]);
		$config->save();
		$this->loadRoom($id);
		$this->saveLevel($this->getRoom($id));
	}
	
	public function setRoom($id, $k, $v){
		$this->roomsinfo[$id][$k] = $v;
		$this->saveRooms();
		if(($room = $this->getRoom($id)) !== null){
			$room->info = $this->roomsinfo[$id];
		}
	}
	
	public function deleteRoom($id){
        $p = $this->path. "/rooms/";
		$files = scandir($p);
        foreach($files as $f) {
			if ($f !== "." && $f !== "..") {
			if($f == $id.".yml"){
				@unlink($p.$f);
			}
			}
	  	}
		unset($this->rooms[$id]);
		unset($this->roomsinfo[$id]);
	}
	
	public function reloadRoom($id){
		$room = $this->getRoom($id);
		if($room == null){
			return false;
		}
		$room->stop(true);
		if(($info = $this->getRoomInfo($id)) !== null){
			foreach(MBattleBridge::$room_info_format as $key => $val){
				if(!isset($this->roomsinfo[$id][$key])){
					$this->roomsinfo[$id][$key] = $val;
					if(!is_array($val)){
						$this->getServer()->getLogger()->info(MBattleBridge::FORMAT."房間{$this->getID()}的 [$key] 沒有設置,已暫時自動改為 [$val]");
					}
				}else{
					if(is_array($val)){
						foreach($val as $key2 => $val2){
							if(!isset($this->roomsinfo[$id][$key][$key2])){
								$this->roomsinfo[$id][$key][$key2] = $val2;
							}
						}
					}
				}
				if(getType($this->roomsinfo[$id][$key]) != getType($val)){
					if(is_numeric($this->roomsinfo[$id][$key]) and is_numeric($val)){
						
					}else{
						$this->roomsinfo[$id][$key] = $val;
						if(!is_array($val)){
							$this->getServer()->getLogger()->info(MBattleBridge::FORMAT."房間{$this->getID()}的 [$key] 數據類型不符,已暫時自動改為 [$val]");
						}
					}
				}else{
					if(is_array($val)){
						foreach($val as $key2 => $val2){
						if(getType($this->roomsinfo[$id][$key][$key2]) != getType($val2)){
							if(is_numeric($this->roomsinfo[$id][$key][$key2]) and is_numeric($val2)){
						
							}else{
								$this->roomsinfo[$id][$key][$key2] = $val2;
								if(!is_array($val2)){
									$this->getServer()->getLogger()->info(MBattleBridge::FORMAT."房間{$this->getID()}中的[$key]中的 [$key2] 數據類型不符,已暫時自動改為 [$val2]");
								}
							}
						}
						}
					}
				}
			}
			$room->info = $this->getRoomInfo($id);
			if(!isset($room->info["game-level"]) or !isset($room->info["wait"]) or !isset($room->info["center"]) or !isset($room->info["stop"])){
				$room->loaded = false;
				$room->delete();
				return false;
			}
			foreach(MBattleBridge::$allteams as $team){
				if(!isset($room->info[$team])){
					$room->delete();
					return false;
				}
			}
			if(!in_array(strtolower($room->info["chapter"]),MBattleBridge::$allchapters)){
				$room->info["chapter"] = MBattleBridge::$defaultchapter;
			}
			$room->gamers = [];
			$room->gamers["all"] = [];
			$room->gamers["red"] = [];
			$room->gamers["blue"] = [];
			$room->gamers["green"] = [];
			$room->gamers["yellow"] = [];
			$room->spectators = [];
			$room->spectators["all"] = [];
			$room->spectators["red"] = [];
			$room->spectators["blue"] = [];
			$room->spectators["green"] = [];
			$room->spectators["yellow"] = [];
			$room->chapter = Chapter::getChapter($room);
			$room->chapterblock = $room->chapter->getChapterBlock();
			$room->loaded = true;
			$room->gamestart  = false;
			$room->tt = false;
			$room->time = 0;
			$room->generated = false;
			$room->war = false;
			$room->duel = false;
			$room->prepareTick();
			if($this->config["螺旋粒子開關"] == true){
				$room->particleTick();
			}
			if($this->getServer()->isLevelLoaded($room->info["game-level"]) === false){
				$room->loaded = false;
			}else{
				$room->loadChunks();
			}
		}else{
			$room->loaded = false;
		}
	}
	
	public function isGameLevel($level){
		if($level instanceof Level){
			$level = $level->getFolderName();
		}
		foreach($this->getAllRooms() as $room){
			if($room->info["game-level"] == $level){
				return true;
			}
		}
		return false;
	}
	
	public function isWaitLevel($level){
		if($level instanceof Level){
			$level = $level->getFolderName();
		}
		foreach($this->getAllRooms() as $room){
			if($room->info["wait"]["level"] == $level){
				return true;
			}
		}
		return false;
	}
	
	public function isNormalLevel($level){
		if($this->isGameLevel($level) or $this->isWaitLevel($level)){
			return false;
		}
		return true;
	}
	
	public function getGameLevels(){
		$levels = [];
		foreach($this->getAllRooms() as $room){
			$levels[$room->getID()] = $room->info["game-level"];
		}
		return $levels;//[string]
	}
	
	public function getWaitLevels(){
		$levels = [];
		foreach($this->getAllRooms() as $room){
			$levels[$room->getID()] = $room->info["wait"]["level"];
		}
		return $levels;//[string]
	}
	
	public function getRoomByLevel($level, $type = "game"){
		if($level instanceof Level){
			$level = $level->getFolderName();
		}		
		if($type == "game"){
			foreach($this->getAllRooms() as $room){
				if($room->info["game-level"] == $level){
					return $room;
				}
			}
		}else{
			foreach($this->getAllRooms() as $room){
				if($room->info["wait"]["level"] == $level){
					return $room;
				}
			}
		}
	}
	
	public function getAllRooms(){
		$array = [];
		foreach($this->rooms as $id => $room){
			if($room instanceof Room){
				$array[$id] = $room;
			}else{
				unset($this->rooms[$id]);
			}
		}
		return $array;
		/*
		$rooms = [];
		$files = preg_grep("/\.yml$/", scandir($this->path. "rooms/"));
		foreach($files as $file){
			$id = basename($file,".yml");
			$room = $this->getRoom($id);
			if($room instanceof Room){
				$rooms[$id] = $room; 
			}
		}
		return $rooms;
		*/
	}
	
	public function getRoomsNum(){
		return count($this->rooms);
		//return count(preg_grep("/\.yml$/", scandir($this->path. "rooms/")));
	}
	
	public function saveLevel($room){
		if($room instanceof Room){
			$level = $room->getGameLevel()->getFolderName();
		}else{
			$level = $room;
		}
		$this->mgb->copyLevel($level, self::getGameName());
	}
	
	public function saveInventory(Player $player){
     if($player->getGamemode() == 0){
		    $inventory = $player->getInventory();
		    $config = $this->getPlayerConfig($player);
			if(empty($inventory->getContents())){
				return false;
			}
			$items = $config->getAll()["Items"];
            foreach($inventory->getContents() as $item)
            {
                $id = $item->getId();
                $damage = $item->getDamage();
                $count = $item->getCount();
				$enchantments = $item->getEnchantments();
				$str = "";
				if(!empty($enchantments)){
					foreach($enchantments as $enchantment){
						$eid = $enchantment->getId();
						$elevel = $enchantment->getLevel();
						$str .= ":$eid-$elevel";
					}
				}
                if(!isset($items["$id:$damage".$str])){
				$items["$id:$damage".$str] = 0;
				}
                $items["$id:$damage".$str] += $count;
            }
			$config->setNested("Items", $items);
			$config->save();
			$inventory->sendContents($player);
	 }
	}
	
	public function checkRate(Player $player, $type){
		if(!$this->config["阻止玩家高頻刷戰橋類行動"]){
			return true;
		}else{
			$name = $player->getName();
			if(!isset($this->rate[$name])){
				$this->rate[$name] = ["rate"=>0,"time"=>microtime(true)];
			}else{
				$this->rate[$name]["rate"] = $this->rate[$name]["rate"] + 1;
				if($this->rate[$name]["rate"] >= 3){
					if(microtime(true) - $this->rate[$name]["time"] <= 4){
						if($type !== "message"){
							$player->sendMessage($this->getMessage($player, "checkrate"));
						}
						return false;
					}else{
						$this->rate[$name] = ["rate"=>0,"time"=>microtime(true)];
						return true;
					}
				}
			}
			return true;
		}
	}
	
	public function giveInventory(Player $player){
		if($player->getGamemode() == 0){
			$inventory = $player->getInventory();
			$config = $this->getPlayerConfig($player);
			$itemsList = $config->getNested("Items");
			if(!empty($itemsList)){
                foreach($itemsList as $itemInfo => $count){
                    $tmp = explode(":", $itemInfo);
                    $id = (int) $tmp[0];
                    $damage = (int) $tmp[1];
                    $count = (int) $count;
                    $item = Item::get($id, $damage, $count);
					if(isset($tmp[2])){
						for($i = 2;$i < count($tmp);$i++){
							$a = explode("-", $tmp[$i]);
							$eid = $a[0];
							$elevel = $a[1];
							$enchantment = \pocketmine\item\enchantment\Enchantment::getEnchantment($eid);
							$enchantment->setLevel($elevel);
							$item->addEnchantment($enchantment);
						}
					}
                    $inventory->addItem($item);
                }
                $config->setNested("Items", []);
                $config->save();
            }
			$inventory->sendContents($player);
		}
	}
	
	/**
	 * @param Player $player
	 * 隱身某玩家
	 */
	public function hidePlayer(Player $player) {
		$effect = Effect::getEffect(Effect::INVISIBILITY);
		$effect->setDuration(20 * 10000);
        $effect->setVisible(false);
		$player->addEffect($effect);
		foreach($this->getServer()->getOnlinePlayers() as $p) {
			if ($p !== $player) {
				$p->hidePlayer($player);
			}
		}
	}
	

	/**
	 * @param Player $player
	 * 去除隱身某玩家
	 */
	public function showPlayer(Player $player) {
		$player->removeEffect(Effect::INVISIBILITY);  
		foreach ($this->getServer()->getOnlinePlayers() as $p) {
			if ($p !== $player) {
				$p->showPlayer($player);
			}
		}
	}
	
    public function getChestContents(){
        $items = array(
            //ARMOR
            'armor' => array(
                array(
                    Item::LEATHER_CAP,
                    Item::LEATHER_TUNIC,
                    Item::LEATHER_PANTS,
                    Item::LEATHER_BOOTS
                ),
                array(
                    Item::GOLD_HELMET,
                    Item::GOLD_CHESTPLATE,
                    Item::GOLD_LEGGINGS,
                    Item::GOLD_BOOTS
                ),
                array(
                    Item::CHAIN_HELMET,
                    Item::CHAIN_CHESTPLATE,
                    Item::CHAIN_LEGGINGS,
                    Item::CHAIN_BOOTS
                ),
                array(
                    Item::IRON_HELMET,
                    Item::IRON_CHESTPLATE,
                    Item::IRON_LEGGINGS,
                    Item::IRON_BOOTS
                ),
                array(
                    Item::DIAMOND_HELMET,
                    Item::DIAMOND_CHESTPLATE,
                    Item::DIAMOND_LEGGINGS,
                    Item::DIAMOND_BOOTS
                )
            ),

            //WEAPONS
            'weapon' => array(
                array(
                    Item::WOODEN_SWORD,
                    Item::WOODEN_AXE,
                ),
                array(
                    Item::GOLD_SWORD,
                    Item::GOLD_AXE
                ),
                array(
                    Item::STONE_SWORD,
                    Item::STONE_AXE
                ),
                array(
                    Item::IRON_SWORD,
                    Item::IRON_AXE
                ),
                array(
                    Item::DIAMOND_SWORD,
                    Item::DIAMOND_AXE
                )
            ),

            //FOOD
            'food' => array(
                array(
                    Item::RAW_PORKCHOP,
                    Item::RAW_CHICKEN,
                    Item::MELON_SLICE,
                    Item::COOKIE
                ),
                array(
                    Item::RAW_BEEF,
                    Item::CARROT
                ),
                array(
                    Item::APPLE,
                    Item::GOLDEN_APPLE
                ),
                array(
                    Item::BEETROOT_SOUP,
                    Item::BREAD,
                    Item::BAKED_POTATO
                ),
                array(
                    Item::MUSHROOM_STEW,
                    Item::COOKED_CHICKEN
                ),
                array(
                    Item::COOKED_PORKCHOP,
                    Item::STEAK,
                    Item::PUMPKIN_PIE
                ),
            ),

            //THROWABLE
            'throwable' => array(
                array(
                    Item::BOW,
                    Item::ARROW
                ),
                array(
                    Item::SNOWBALL
                ),
                array(
                    Item::EGG
                )
            ),

            //BLOCKS
            'block' => array(
                Item::STONE,
                Item::WOODEN_PLANK,
                Item::COBBLESTONE,
                Item::DIRT
            ),

            //OTHER
            'other' => array(
                array(
                    Item::WOODEN_PICKAXE,
                    Item::GOLD_PICKAXE,
                    Item::STONE_PICKAXE,
                    Item::IRON_PICKAXE,
                    Item::DIAMOND_PICKAXE
                ),
                array(
                    Item::STICK,
                    Item::STRING
                )
            )
        );

        $templates = [];
        for ($i = 0; $i < 15; $i++) {

            $armorq = mt_rand(0, 1);
            $armortype = $items['armor'][mt_rand(0, (count($items['armor']) - 1))];
            $armor1 = array($armortype[mt_rand(0, (count($armortype) - 1))], 1);
            if ($armorq) {
                $armortype = $items['armor'][mt_rand(0, (count($items['armor']) - 1))];
                $armor2 = array($armortype[mt_rand(0, (count($armortype) - 1))], 1);
            } else {
                $armor2 = array(0, 1);
            }
            unset($armorq, $armortype);

            $weapontype = $items['weapon'][mt_rand(0, (count($items['weapon']) - 1))];
            $weapon = array($weapontype[mt_rand(0, (count($weapontype) - 1))], 1);
            unset($weapontype);

            $ftype = $items['food'][mt_rand(0, (count($items['food']) - 1))];
            $food = array($ftype[mt_rand(0, (count($ftype) - 1))], mt_rand(2, 5));
            unset($ftype);

            $add = mt_rand(0, 1);
            if ($add) {
                $tr = $items['throwable'][mt_rand(0, (count($items['throwable']) - 1))];
                if (count($tr) == 2) {
                    $throwable1 = array($tr[1], mt_rand(10, 20));
                    $throwable2 = array($tr[0], 1);
                } else {
                    $throwable1 = array(0, 1);
                    $throwable2 = array($tr[0], mt_rand(5, 10));
                }
                $other = array(0, 1);
            } else {
                $throwable1 = array(0, 1);
                $throwable2 = array(0, 1);
                $ot = $items['other'][mt_rand(0, (count($items['other']) - 1))];
                $other = array($ot[mt_rand(0, (count($ot) - 1))], 1);
            }
            unset($add, $tr, $ot);

            $block = array($items['block'][mt_rand(0, (count($items['block']) - 1))], 64);

            $contents = array(
                $armor1,
                $armor2,
                $weapon,
                $food,
                $throwable1,
                $throwable2,
                $block,
                $other
            );
            shuffle($contents);
            $fcontents = array(
                mt_rand(1, 2) => array_shift($contents),
                mt_rand(3, 5) => array_shift($contents),
                mt_rand(6, 10) => array_shift($contents),
                mt_rand(11, 15) => array_shift($contents),
                mt_rand(16, 17) => array_shift($contents),
                mt_rand(18, 20) => array_shift($contents),
                mt_rand(21, 25) => array_shift($contents),
                mt_rand(26, 27) => array_shift($contents),
            );
            $templates[] = $fcontents;

        }

        shuffle($templates);
        return $templates;
    }
	
	public function getSafePos($pos){
		if($pos instanceof Vector3){
			if(!$pos->level instanceof Level){
				return $pos;
			}
			$v = $pos->floor();
			$chunk = $pos->level->getChunk($v->x >> 4, $v->z >> 4, false);
			$x = $v->x & 0x0f;
			$z = $v->z & 0x0f;
			if($chunk !== null){
				$y = (int) min(126, $v->y);
				$wasAir = ($chunk->getBlockId($x, $y - 1, $z) === 0);
				for(; $y > 0; --$y){
					$b = $chunk->getFullBlock($x, $y, $z);
					$block = Block::get($b >> 4, $b & 0x0f);
					if($pos->level->isFullBlock($block)){
						if($wasAir){
							$y++;
							break;
						}
					}else{
						$wasAir = true;
					}
				}

				for(; $y >= 0 and $y < 128; ++$y){
					$b = $chunk->getFullBlock($x, $y + 1, $z);
					$block = Block::get($b >> 4, $b & 0x0f);
					if(!$pos->level->isFullBlock($block)){
						$b = $chunk->getFullBlock($x, $y, $z);
						$block = Block::get($b >> 4, $b & 0x0f);
						if(!$pos->level->isFullBlock($block)){
							return new Position($pos->x, $y === (int) $pos->y ? $pos->y : $y, $pos->z, $pos->level);
						}
					}else{
						++$y;
					}
				}

				$v->y = $y;
			}

			return new Position($pos->x, $v->y, $pos->z, $pos->level);
		}else{
			return $this->getServer()->getDefaultLevel()->getSafeSpawn();
		}
	}
	
	public $record = [];
	
	public function calculate($player, $type = "stop", $value = 0){
		if($player instanceof Player){
			$name = $player->getName();
		}else{
			$name = $player;
		}
		$name = strtolower($name);
		$type = strtolower($type);
		unset($player);
		switch($type){
			
			case "start":
			$this->record[$name] = [
			"win" => 0,
			"lose" => 0,
			"kill" => 0,
			"death" => 0,
			"damage" => 0,
			];
			break;
			
			case "stop":
			unset($this->record[$name]);
			break;
			
			case "get":
			switch($value){
				case "exp":
				$exp = $this->record[$name]["kill"] * 10 + $this->record[$name]["death"] * 2 + $this->record[$name]["damage"] / 20 + $this->record[$name]["win"] * 25 - $this->record[$name]["lose"] * 10;
				return $exp > 5 ? (int)$exp : 5;
				break;
				
				default:
				return $this->record[$name][strtolower($value)];
				break;
			}
			break;
			
			default:
			$this->record[$name][$type] += $value;
			return false;
		}
	}
	
	public function sendMessage($player, $str){
		if($player instanceof Player){
			$pk = $this->getPacketObj("TextPacket");
			if($pk != false){
				$pk->type = 0;
				$pk->message = $str;
				@$player->MdataPacket($pk,false,true);
			}
		}else{
			$player->sendMessage($str);
		}
	}

	
	public function sendTip($player, $str){
		if($player instanceof Player){
			$pk = $this->getPacketObj("TextPacket");
			if($pk != false){
				$pk->type = 4;
				$pk->message = $str;
				@$player->MdataPacket($pk,false,true);
			}
		}else{
			$player->sendMessage($str);
		}
	}	

	public function sendPopup($player, $str, $sub= ""){
		if($player instanceof Player){
			$pk = $this->getPacketObj("TextPacket");
			if($pk != false){
				$pk->type = 3;
				$pk->message = $sub;
				$pk->source = $str;
				@$player->MdataPacket($pk,false,true);						
			}
		}else{
			$player->sendMessage($str);
		}
	}
	
	public function sendCommandHelp($sender){
		$this->sendMessage($sender,self::FORMAT."§7加入遊戲房間§a/bb §bjoin ");
		$this->sendMessage($sender,self::FORMAT."§7退出遊戲房間§a/bb §bleft ");
		$this->sendMessage($sender,self::FORMAT."§7選擇遊戲隊伍§a/bb §bteam ");
		$this->sendMessage($sender,self::FORMAT."§7觀戰某個房間§a/bb §bwatch ");
		$this->sendMessage($sender,self::FORMAT."§7查看個人資料§a/bb §binfo ");
		//$this->sendMessage($sender,self::FORMAT."§7取回生存背包§a/bb §bbag ");
		$this->sendMessage($sender,self::FORMAT."§7查看房間列表§a/bb §blist ");
		if($sender->isOp()){
			$this->sendMessage($sender,self::FORMAT."§7強制開始遊戲§e/bb §bstart ");
			$this->sendMessage($sender,self::FORMAT."§7強制結束遊戲§e/bb §bstop ");
			$this->sendMessage($sender,self::FORMAT."§7修改玩家稱號§e/bb §btag ");
			$this->sendMessage($sender,self::FORMAT."§7添加獎罰指令§e/bb §6command ");
			$this->sendMessage($sender,self::FORMAT."§7重載遊戲房間§e/bb §breload ");
			$this->sendMessage($sender,self::FORMAT."§7刪除遊戲房間§e/bb §bdelete ");
			$this->sendMessage($sender,self::FORMAT."§7設排行榜坐標§e/bb §6ranking ");
			$this->sendMessage($sender,self::FORMAT."§7關閉/開啟粒子§e/bb §bparticle ");
			$this->sendMessage($sender,self::FORMAT."§7修改房間配置§e/bb §broom ");
			$this->sendMessage($sender,self::FORMAT."§7創建遊戲房間§e/bb §6set ");
		}
	}
	
	public function runCommand(CommandSender $sender, Command $cmd, $label, array $args){
        if($cmd->getName() == "bb"){
			if($args == null){
				$this->sendMessage($sender,self::FORMAT."§7輸入§b/bb help§7來查看幫助");
				return true;
			}
			switch(strtolower($args[0])){
				case "list":
				if(!isset($args[1])){
					$args[1] = "null";
				}
				switch($args[1]){
					case "rooms":
					case "room":
					$str = "";
					foreach($this->getAllRooms() as $room){
						$str .= "\n§b房間§d[{$room->getID()}]§7: ";
						if($room->isLoaded()){
							$str .= "§2已加載 ";
						}else{
							$str .= "§4未加載 ";
						}
						
						if($room->isStarted()){
							$str .= "§c已開始 ";
						}else{
							$str .= "§a未開始 ";
						}
						$str .= "§2".Language::$message[$room->getChapter()->getName()]." ";
						$str .= "§b".Language::$message[$room->getStep()]." ";
						foreach(self::$allteams as $team){
							$str .= $team.$room->getPlayerNum($team)." ";
						}
						$str .= "§a".$room->getPlayerNum()."§7/§c".$room->getMax();
					}
					$this->sendMessage($sender,$this->getMessage($sender, $str));
					return true;
					
					
					case "teams":
					case "team":
					$str = "";
					foreach(self::$allteams as $team){
						$str .= "\n§f".$team."§7=>".Language::$message[$team];
					}
					$this->sendMessage($sender,$str);
					return true;
					
					default:
					$this->sendMessage($sender,self::FORMAT."§7/bb list [room | team]");
					return true;
				}
				
				case "join":
				case "enter":
				case "進入":
				case "加入":
				if(!$sender instanceof Player){
					$this->sendMessage($sender,$this->getMessage(null, "command.not.player"));
					return true;
				}
				if(count($args) !== 2){
					$this->sendMessage($sender,self::FORMAT."§7/bb join [房間號]");
					return true;
				}else{
					$id = str_replace(array("[","]"), "", $args[1]);
					if(($room = $this->getRoom($id)) !== null){
						$room->joinPlayer($sender);
					}else{
						$this->sendMessage($sender,$this->getMessage($sender, "join.no.room", [$id]));
					}
					return true;
				}
								
				case "spectate":
				case "view":
				case "watch":
				case "see":
				case "look":
				case "觀戰":
				if(!$sender instanceof Player){
					$this->sendMessage($sender,$this->getMessage(null, "command.not.player"));
					return true;
				}
				if(count($args) !== 2){
					$this->sendMessage($sender,self::FORMAT."§7/bb watch [房間號]");
					return true;
				}else{
					$id = str_replace(array("[","]"), "", $args[1]);
					if(($room = $this->getRoom($id)) !== null){
						if($this->findRoom($sender) !== null){
							$this->sendMessage($sender,$this->getMessage($sender, "join.room.joined"));
							return true;
						}else{
							if(!$room->isLoaded()){
								$player->sendMessage($this->getMessage($player, "join.room.unloaded", [$room->id]));
								return true;
							}
							$room->spectate($sender, 2);
							return true;
						}
					}else{
						$this->sendMessage($sender,$this->getMessage($sender, "join.no.room", [$id]));
					}
					return true;
				}
				
				case "quit":
				case "left":
				case "leave":
				case "離開":
				case "退出":
				if(!$sender instanceof Player){
					$this->sendMessage($sender,$this->getMessage(null, "command.not.player"));
					return true;
				}
				if(($room = $this->findRoom($sender->getName())) !== null){
					$room->quitPlayer($sender);
				}else{
					$this->sendMessage($sender,$this->getMessage($sender, "quit.no.room"));
				}
				return true;
				
				case "choose":
				case "team":
				case "選擇":
				case "隊伍":
				if(!$sender instanceof Player){
					$this->sendMessage($sender,$this->getMessage(null, "command.not.player"));
					return true;
				}
				if(count($args) !== 2){
					$this->sendMessage($sender,self::FORMAT."§7/bb team [隊伍]");
					return true;
				}else{
					if(($room = $this->findRoom($sender)) !== null){
						$team = str_replace(array("[","]"), "", $args[1]);
						$room->joinTeam($sender, $team);
					}else{
						$this->sendMessage($sender,$this->getMessage($sender, "team.no.room"));
					}
				}
				return true;
				
				case "set":
				case "設置":
				if(!$sender instanceof Player){
					$this->sendMessage($sender,$this->getMessage(null, "command.not.player"));
					return true;
				}
				if(!$sender->isOp()){
					$this->sendMessage($sender,$this->getMessage($sender, "no.permission"));
					return true;
				}
				if($sender instanceof Player){
					$name = strtolower($sender->getName());
					$level = $sender->getLevel();
					if(!isset($this->setter[$name]) or $this->setter[$name] < 0){
						$this->setter[$name] = 0;
						$this->setting[$name] = [];
						$this->id = $this->getRoomsNum() + 1;
						for(;;){
							if($this->getRoom($this->id) !== null){
								$this->id += 1;
							}else{
								break;
							}
						}
						$this->sendMessage($sender,$this->getMessage($sender, "set.start", [$this->id]));
						$this->sendMessage($sender,$this->getMessage($sender, "set.warning"));
						$this->sendMessage($sender,$this->getMessage($sender, "set.step0"));
						return true;
					}elseif(isset($args[1])){
						switch($args[1]){
							case "back":
							case "b":
							case "return":
							case "返回":
							$this->setter[$name]--;
							$this->sendMessage($sender,$this->getMessage($sender, "set.back"));
							$this->sendMessage($sender,$this->getMessage($sender, "set.step".$this->setter[$name]));
							break;
							
							default:
							$chapter = strtolower($args[1]);
							if(in_array($chapter, self::$allchapters)){
								if(!$this->isPHP7() and $chapter == "bedwars"){
									$this->sendMessage($sender,$this->getMessage($sender, "set.no.php7", [$chapter]));
									return true;
								}
								$this->setting[$name]["chapter"] = $chapter;
								$this->id = $this->getRoomsNum() + 1;
								for(;;){
									if($this->getRoom($this->id) !== null){
										$this->id += 1;
									}else{
										break;
									}
								}
								$this->createRoom($this->id, $this->setting[$name]);
		                        $this->sendMessage($sender,$this->getMessage($sender, "§c紅§7隊最大人數:10,最少人數:1"));
								$this->sendMessage($sender,$this->getMessage($sender, "§b藍§7隊最大人數:10,最少人數:1"));
								$this->sendMessage($sender,$this->getMessage($sender, "§e黃§7隊最大人數:10,最少人數:1"));
								$this->sendMessage($sender,$this->getMessage($sender, "§a綠§7隊最大人數:10,最少人數:1"));
								$this->sendMessage($sender,$this->getMessage($sender, "§7總房間最大人數:40,最少人數:4"));
								$this->sendMessage($sender,$this->getMessage($sender, "§7可忽視人數平衡常數:2"));
								$this->sendMessage($sender,$this->getMessage($sender, "§7此房間隊友傷害(不為零均為開啟隊友傷害): 0"));
								$this->sendMessage($sender,$this->getMessage($sender, "§7遊戲地圖時間: 10000 白天"));
								$this->sendMessage($sender,$this->getMessage($sender, "§7準備時間: 30 秒"));
								$this->sendMessage($sender,$this->getMessage($sender, "§7正式戰鬥時間點:第 360 秒"));
								$this->sendMessage($sender,$this->getMessage($sender, "§7寶箱重置時間點:第 400 秒"));
								$this->sendMessage($sender,$this->getMessage($sender, "§7戰橋生成時間點:第 400 秒"));
								$this->sendMessage($sender,$this->getMessage($sender, "§7地圖回檔延遲時間:在遊戲結束後第 3 秒進行回檔"));
								$this->sendMessage($sender,$this->getMessage($sender, "§7遊戲限制時間: 3600 秒"));
								$this->sendMessage($sender,$this->getMessage($sender, "§7此房間的黑名單: 無"));
								$this->sendMessage($sender,$this->getMessage($sender, "set.finish", [$this->id]));
								unset($this->setter[$name]);
								unset($this->setting[$name]);
							}else{
							}
							break;
						}
					}else{
						$pos = $sender->getPosition();
						if($pos->y >= 125 or $pos->y <= 1){
							$this->sendMessage($sender,$this->getMessage($sender, "set.y.125"));
							return true;
						}
						switch($this->setter[$name]){
							case 0://等待區
							if($this->isGameLevel($pos->level)){
								$this->sendMessage($sender,$this->getMessage($sender, "set.level.game"));
								return true;
							}
							$this->setting[$name]["wait"]["x"] = $pos->x;
							$this->setting[$name]["wait"]["y"] = $pos->y;
							$this->setting[$name]["wait"]["z"] = $pos->z;
							$this->setting[$name]["wait"]["level"] = $pos->level->getFolderName();
							$this->setter[$name]++;
							$this->sendMessage($sender,$this->getMessage($sender, "set.step1"));
							break;
							
							case 1://中心
							if($pos->level->getFolderName() == $this->getServer()->getDefaultLevel()->getFolderName()){
								$this->sendMessage($sender,$this->getMessage($sender, "set.default"));
								return true;
							}
							if($this->isGameLevel($pos->level) or $this->isWaitLevel($pos->level)){
								$this->sendMessage($sender,$this->getMessage($sender, "set.level"));
								return true;
							}
							$this->setting[$name]["center"]["x"] = $pos->x;
							$this->setting[$name]["center"]["y"] = $pos->y;
							$this->setting[$name]["center"]["z"] = $pos->z;
							$this->setter[$name]++;
							$this->sendMessage($sender,$this->getMessage($sender, "set.step2"));
							break;
							
							case 2://紅
							if($pos->level->getFolderName() == $this->getServer()->getDefaultLevel()->getFolderName()){
								$this->sendMessage($sender,$this->getMessage($sender, "set.default"));
								return true;
							}
							if($this->isGameLevel($pos->level) or $this->isWaitLevel($pos->level)){
								$this->sendMessage($sender,$this->getMessage($sender, "set.level"));
								return true;
							}
							$this->setting[$name]["red"]["x"] = $pos->x;
							$this->setting[$name]["red"]["y"] = $pos->y;
							$this->setting[$name]["red"]["z"] = $pos->z;
							$this->setter[$name]++;
							$this->sendMessage($sender,$this->getMessage($sender, "set.step3"));
							break;
							
							case 3://藍
							if($pos->level->getFolderName() == $this->getServer()->getDefaultLevel()->getFolderName()){
								$this->sendMessage($sender,$this->getMessage($sender, "set.default"));
								return true;
							}
							if($this->isGameLevel($pos->level) or $this->isWaitLevel($pos->level)){
								$this->sendMessage($sender,$this->getMessage($sender, "set.level"));
								return true;
							}
							$this->setting[$name]["blue"]["x"] = $pos->x;
							$this->setting[$name]["blue"]["y"] = $pos->y;
							$this->setting[$name]["blue"]["z"] = $pos->z;
							$this->setter[$name]++;
							$this->sendMessage($sender,$this->getMessage($sender, "set.step4"));
							break;
							
							case 4://綠
							if($pos->level->getFolderName() == $this->getServer()->getDefaultLevel()->getFolderName()){
								$this->sendMessage($sender,$this->getMessage($sender, "set.default"));
								return true;
							}
							if($this->isGameLevel($pos->level) or $this->isWaitLevel($pos->level)){
								$this->sendMessage($sender,$this->getMessage($sender, "set.level"));
								return true;
							}
							$this->setting[$name]["green"]["x"] = $pos->x;
							$this->setting[$name]["green"]["y"] = $pos->y;
							$this->setting[$name]["green"]["z"] = $pos->z;
							$this->setter[$name]++;
							$this->sendMessage($sender,$this->getMessage($sender, "set.step5"));
							break;
							
							case 5://黃
							if($pos->level->getFolderName() == $this->getServer()->getDefaultLevel()->getFolderName()){
								$this->sendMessage($sender,$this->getMessage($sender, "set.default"));
								return true;
							}
							if($this->isGameLevel($pos->level) or $this->isWaitLevel($pos->level)){
								$this->sendMessage($sender,$this->getMessage($sender, "set.level"));
								return true;
							}
							$sender->getLevel()->saveChunks();
							$sender->getLevel()->save();
							$this->setting[$name]["yellow"]["x"] = $pos->x;
							$this->setting[$name]["yellow"]["y"] = $pos->y;
							$this->setting[$name]["yellow"]["z"] = $pos->z;
							$this->setting[$name]["game-level"] = $pos->level->getFolderName();
							$this->setter[$name]++;
							$this->sendMessage($sender,$this->getMessage($sender, "set.step6"));
							break;
							
							case 6://結束
							if($this->isGameLevel($pos->level) or $pos->level->getFolderName() == $this->setting[$name]["game-level"]){
								$this->sendMessage($sender,$this->getMessage($sender, "set.level.game"));
								return true;
							}
							$this->setting[$name]["stop"]["x"] = $pos->x;
							$this->setting[$name]["stop"]["y"] = $pos->y;
							$this->setting[$name]["stop"]["z"] = $pos->z;
							$this->setting[$name]["stop"]["level"] = $pos->level->getFolderName();
							$this->setter[$name]++;
							$this->sendMessage($sender,$this->getMessage($sender, "set.step7"));
							$str = "§3".implode("§c | §3",MBattleBridge::$allchapters);
							$this->sendMessage($sender,$str);
							break;
						}
					}
				}
				return true;
				
				
				case "del":
				case "delete":
				case "刪除":
				if(!$sender->isOp()){
					$this->sendMessage($sender,$this->getMessage($sender, "no.permission"));
					return true;
				}
				if(count($args) !== 2){
					$this->sendMessage($sender,self::FORMAT."§7/bb del [房間號]");
					return true;
				}
				$id = str_replace(array("[","]"), "", $args[1]);
				if(($room = $this->getRoom($id)) !== null){
					$room->delete();
					$this->sendMessage($sender,$this->getMessage($sender, "room.delete", [$id]));
				}else{
					$this->sendMessage($sender,$this->getMessage($sender, "room.delete.no", [$id]));
				}
				return true;
				// bb command [add/del/list/delall]
				case "c":
				case "command":
				if(!$sender->isOp()){
					$this->sendMessage($sender,$this->getMessage($sender, "no.permission"));
					return true;
				}
				if(!isset($args[1])){
					$this->sendMessage($sender,self::FORMAT."§7/bb command [add | del | list | delall]");
					return true;
				}
				switch($args[1]){
					case "添加":
					case "增加":
					case "add":
					case "+":
					if(count($args) <= 3){
						$this->sendMessage($sender,self::FORMAT."§7/bb command add [win | lose] <command>");
					}else{
							$command = "";
							foreach($args as $key => $arg){
								if($key > 2){
									$command .= " ".$arg;
								}
							}
							$command = substr($command, 1);
						    switch($args[2]){
							case "win":
							$this->config["遊戲結束玩家勝利後服務器自動使用指令(%p代表此玩家的名字)"][] = $command;
							$this->sendMessage($sender,self::FORMAT."§7成功添加玩家§6勝利§7指令:§a$command");
							$this->saveConfigs();
							return true;
							
							case "lose":
							$this->config["遊戲結束玩家失敗後服務器自動使用指令(%p代表此玩家的名字)"][] = $command;
							$this->sendMessage($sender,self::FORMAT."§7成功添加玩家§c失敗§7指令:§a$command");
							$this->saveConfigs();
							return true;
							
							default:
							$this->sendMessage($sender,self::FORMAT."§7/bb command add [win | lose] <command>");
							return true;
							}
					}
					return true;
					
					case "刪除":
					case "del":
					case "delete":
					case "-":
					if(count($args) <= 3){
						$this->sendMessage($sender,self::FORMAT."§7/bb command del [win | lose] <command>");
					}else{
							$command = "";
							foreach($args as $key => $arg){
								if($key > 2){
									$command .= " ".$arg;
								}
							}
							$command = substr($command, 1);
						    switch($args[2]){
							case "win":
							if(($find = array_search($command,$this->config["遊戲結束玩家勝利後服務器自動使用指令(%p代表此玩家的名字)"])) !== false){
								array_splice($this->config["遊戲結束玩家勝利後服務器自動使用指令(%p代表此玩家的名字)"], $find, 1);
								$this->saveConfigs();
							}
							$this->sendMessage($sender,self::FORMAT."§7成功刪除玩家§6勝利§7指令:§a$command");
							return true;
							
							case "lose":
							if(($find = array_search($command,$this->config["遊戲結束玩家失敗後服務器自動使用指令(%p代表此玩家的名字)"])) !== false){
								array_splice($this->config["遊戲結束玩家失敗後服務器自動使用指令(%p代表此玩家的名字)"], $find, 1);
								$this->saveConfigs();
							}
							$this->sendMessage($sender,self::FORMAT."§7成功刪除玩家§c失敗§7指令:§a$command");
							return true;
							
							default:
							$this->sendMessage($sender,self::FORMAT."§7/bb command del [win | lose] <command>");
							return true;
						}
					}
					return true;
					
					case "delall":
					if(count($args) !== 3){
						$this->sendMessage($sender,self::FORMAT."§7/bb command delall [win | lose]");
					}else{
						    switch($args[2]){
							case "win":
							$this->config["遊戲結束玩家勝利後服務器自動使用指令(%p代表此玩家的名字)"] = [];
							$this->sendMessage($sender,self::FORMAT."§7成功刪除所有的玩家§6勝利§7指令");
							$this->saveConfigs();
							return true;
							
							case "lose":
							$this->config["遊戲結束玩家失敗後服務器自動使用指令(%p代表此玩家的名字)"] = [];
							$this->sendMessage($sender,self::FORMAT."§7成功刪除所有的玩家§c失敗§7指令");
							$this->saveConfigs();
							return true;
							
							default:
							$this->sendMessage($sender,self::FORMAT."§7/bb command delall [win | lose]");
							return true;
						}
					}
					return true;
										
					case "list":
					if(count($args) !== 3){
						$this->sendMessage($sender,self::FORMAT."§7/bb command list [win | lose]");
					}else{
						    switch($args[2]){
							case "win":
							$commands = implode("\n§a",$this->config["遊戲結束玩家勝利後服務器自動使用指令(%p代表此玩家的名字)"]);
							$this->sendMessage($sender,self::FORMAT."§7玩家§6勝利§7指令:\n".$commands);
							return true;
							
							case "lose":
							$commands = implode("\n§a",$this->config["遊戲結束玩家失敗後服務器自動使用指令(%p代表此玩家的名字)"]);
							$this->sendMessage($sender,self::FORMAT."§7玩家§c失敗§7指令:\n".$commands);
							return true;
							
							default:
							$this->sendMessage($sender,self::FORMAT."§7/bb command list [win | lose]");
							return true;
						}
					}
					return true;
					
					default:
					$this->sendMessage($sender,self::FORMAT."§7/bb command [add | del | list | delall]");
					return true;
				}
				return true;
				
				case "room":
				if(!$sender->isOp()){
					$this->sendMessage($sender,$this->getMessage($sender, "no.permission"));
					return true;
				}
				if(count($args) < 4){
					$this->sendMessage($sender,self::FORMAT."§7/bb room [房間號] [條目] [參數]");
					$str = "§b條目列表: ";
					foreach(self::$room_info_format as $key => $val){
						if(is_array($val)){
							$str .= "§7| §6".$key;
						}else{
							$str .= "§7| §a".$key;
						}
					}
					$this->sendMessage($sender,$str);
					return true;
				}
				$id = str_replace(array("[","]"), "", $args[1]);
				if(($room = $this->getRoom($id)) !== null){
					$key = strtolower(str_replace(array("[","]"), "", $args[2]));
					if(in_array($key, self::$allteams)){
						$key2 = strtolower(str_replace(array("[","]"), "", $args[3]));
						if(!isset($args[4])){
							$args[4] = null;
						}
						$val = $args[4];
						if(is_numeric($val)){
							$room->info[$key][$key2] = $val;
							$this->roomsinfo[$id][$key][$key2] = $val;
							$this->saveRooms($id);
							$this->sendMessage($sender,$this->getMessage($sender, "command.room.set.success2", [$id,$key,$key2,$val]));
						}else{
							$this->sendMessage($sender,self::FORMAT."§7/bb room [房間號] [隊伍] [min | max] [參數(數字)]");
						}
						return true;
					}else{
						if(isset(self::$room_info_format[$key]) or $key == "banners"){
							$val = strtolower(str_replace(array("[","]"), "", $args[3]));
							if(getType($val) != getType(self::$room_info_format[$key])){
								if(is_numeric($val) and is_numeric(self::$room_info_format[$key])){
									$room->info[$key] = $val;
									$this->roomsinfo[$id][$key] = $val;
									$this->saveRooms($id);
									$this->sendMessage($sender,$this->getMessage($sender, "command.room.set.success1", [$id,$key,$val]));
								}else{
									if($key == "banners"){
										$key2 = strtolower(str_replace(array("[","]"), "", $args[3]));
										// bb room 1 banners awdsad
										switch($key2){
											case "list":
											if(!is_array($room->info[$key])){
												$room->info[$key] = [];
												$this->roomsinfo[$id][$key] = [];
												$this->saveRooms($id);
											}
											$str = "§7房間§d[".$id."]§7的§c封禁列表: ";
											foreach($room->info[$key] as $banner){
												$str .= "§7,§3".$banner;
											}
											$this->sendMessage($sender,$str);
											return true;
											
											default:
											if(!is_array($room->info[$key]) or !is_array($this->roomsinfo[$id][$key])){
												$room->info[$key] = [];
												$this->roomsinfo[$id][$key] = [];
											}
											$find = array_search($key2, $room->info[$key]);
											if($find !== false){
												array_splice($room->info[$key], $find, 1);
												$find2 = array_search($key2, $this->roomsinfo[$id][$key]);
												if($find2 !== false){
													array_splice($this->roomsinfo[$id][$key], $find2, 1);
												}
												$this->sendMessage($sender,$this->getMessage($sender, "command.room.set.banner-", [$id,$key2]));
											}else{
												$room->info[$key][] = $key2;
												$this->roomsinfo[$id][$key][] = $key2;
												$this->sendMessage($sender,$this->getMessage($sender, "command.room.set.banner+", [$id,$key2]));
											}
											$this->saveRooms($id);
											return true;
										}
									}
									$this->sendMessage($sender,$this->getMessage($sender, "command.room.set.fail.type", [$id,$key,$val,self::$room_info_format[$key]]));
								}
							}else{
								$room->info[$key] = $val;
								$this->roomsinfo[$id][$key] = $val;
								$this->saveRooms($id);
								$this->sendMessage($sender,$this->getMessage($sender, "command.room.set.success1", [$id,$key,$val]));
							}
						}else{
							$this->sendMessage($sender,$this->getMessage($sender, "command.room.set.fail.key", [$id,$key]));
						}
					}
				}else{
					$this->sendMessage($sender,$this->getMessage($sender, "command.room.set.fail.room", [$id]));
				}
				return true;
				
				case "particle":
				if(!$sender->isOp()){
					$this->sendMessage($sender,$this->getMessage($sender, "no.permission"));
					return true;
				}
				if($this->config["螺旋粒子開關"] == true){
					$this->config["螺旋粒子開關"] = false;
					$this->sendMessage($sender,$this->getMessage($sender, "command.particle.close"));
				}else{
					$this->config["螺旋粒子開關"] = true;
					$this->sendMessage($sender,$this->getMessage($sender, "command.particle.open"));
				}
				$this->saveConfigs();
				return true;
				
				case "reload":
				case "重載":
				if(!$sender->isOp()){
					$this->sendMessage($sender,$this->getMessage($sender, "no.permission"));
					return true;
				}
				if(count($args) !== 2){
					$this->sendMessage($sender,self::FORMAT."§7/bb reload [房間號]");
					return true;
				}
				$id = str_replace(array("[","]"), "", $args[1]);
				if(($room = $this->getRoom($id)) !== null){
					$room->reload();
					$this->sendMessage($sender,$this->getMessage($sender, "room.reload", [$id]));
				}else{
					$this->sendMessage($sender,$this->getMessage($sender, "room.reload.no", [$id]));
				}
				return true;
				
				
				case "tag":
				case "nametag":
				if(!$sender->isOp()){
					$this->sendMessage($sender,$this->getMessage($sender, "no.permission"));
					return true;
				}				
				if(count($args) < 3){
					$this->sendMessage($sender,self::FORMAT."§7/bb tag [玩家名稱] [遊戲稱號]");
					return true;
				}
				$name = str_replace(array("[","]"), "", $args[1]);
				$config = $this->getPlayerConfig($name);
				$nametag = $args[3];
				$config->set("Nametag", $nametag);
				$config->save();
				$this->sendMessage($sender,$this->getMessage($sender, "set.nametag", [$name, $nametag]));
				return true;
				
				case "stract":
				case "開啟":
				case "start":
				if(!$sender->isOp()){
					$this->sendMessage($sender,$this->getMessage($sender, "no.permission"));
					return true;
				}				
				if(count($args) < 2){
					$this->sendMessage($sender,self::FORMAT."§7/bb start [房間號]");
					return true;
				}
				$id = str_replace(array("[","]"), "", $args[1]);
				if(($room = $this->getRoom($id)) !== null){
					$room->ready(true);
					$this->sendMessage($sender,$this->getMessage($sender, "start.force", [$id]));
				}
				return true;
				
				case "stop":
				if(!$sender->isOp()){
					$this->sendMessage($sender,$this->getMessage($sender, "no.permission"));
					return true;
				}				
				if(count($args) < 2){
					$this->sendMessage($sender,self::FORMAT."§7/bb stop [房間號]");
					return true;
				}
				$id = str_replace(array("[","]"), "", $args[1]);
				if(($room = $this->getRoom($id)) !== null){
					$room->stop(true);
					$this->sendMessage($sender,$this->getMessage($sender, "stop.force", [$id]));
				}
				return true;
				
				case "ranking":
				if(!$sender instanceof Player){
					$this->sendMessage($sender,$this->getMessage(null, "command.not.player"));
					return true;
				}
				if(!$sender->isOp()){
					$this->sendMessage($sender,$this->getMessage($sender, "no.permission"));
					return true;
				}
				$pos = $sender->getPosition();
				$this->config["排行榜坐標"] = ["x"=>$pos->x,"y"=>$pos->y+2,"z"=>$pos->z,"level"=>$pos->level->getFolderName()];
				$this->ranking->x = $this->config["排行榜坐標"]["x"];
				$this->ranking->y = $this->config["排行榜坐標"]["y"];
				$this->ranking->z = $this->config["排行榜坐標"]["z"];
				$this->saveConfigs();
				$this->sendMessage($sender,$this->getMessage($sender, "command.ranking"));
				return true;
				
				case "info":
				if(isset($args[1])){
					$name = str_replace(array("[","]"), "", $args[1]);
					if(!$this->configExists($name)){
						$this->sendMessage($sender,$this->getMessage($sender, "no.player", [$name]));
						return true;
					}
				}else{
					$name = $sender->getName();
				}
				$info = $this->getPlayerConfig($name)->getAll();
				$msg = "§7(|-<>-§a[§5".$name."§a]的§b戰橋§e信息§7-<>-|)\n";
				$msg .= "§6勝利場次§7:§f ".$info["Win"]."\n";
				$msg .= "§3殺敵數§7:§f ".$info["Kill"]."\n";
				$msg .= "§c死亡數§7:§f ".$info["Death"]."\n";
				if($info["Death"] <= 0){
					$kd = "100%";
				}else{
					$kd = round($info["Kill"]/$info["Death"], 2);
				}
				$msg .= "§aKD比§7:§f ".$kd."\n";
				$msg .= "§2遊戲稱號§7:§f ".$info["Nametag"]."\n";
				$msg .= "§e戰橋時間§7:§f ".intval($info["Time"] / 60)."分鐘"."\n";
				$this->sendMessage($sender,$msg);
				return true;
				
				
			    case "bag":
				if(!$sender instanceof Player){
					$this->sendMessage($sender,$this->getMessage(null, "command.not.player"));
					return true;
				}
				if($sender->getGamemode() !== 0){
					$this->sendMessage($sender,$this->getMessage($sender, "command.bag.gamemode"));
					return true;
				}elseif($this->findRoom($sender) !== null){
					$this->sendMessage($sender,$this->getMessage($sender, "command.bag.ingame"));
					return true;
				}else{
				$this->giveInventory($sender);
				$this->sendMessage($sender,$this->getMessage($sender, "command.bag.ok"));
				return true;
				}
				break;
				
				case "update":
				case "更新":
				if(!$sender->isOp()){
					$this->sendMessage($sender,$this->getMessage($sender, "no.permission"));
					return true;
				}
				$this->update();
				return true;
				
				case "help":
				$this->sendCommandHelp($sender);
				return true;
				
				default:
				$this->sendMessage($sender,self::FORMAT."§7輸入§b/bb help§7來查看幫助");
				return true;
			}
		}
	}
	
}

?>