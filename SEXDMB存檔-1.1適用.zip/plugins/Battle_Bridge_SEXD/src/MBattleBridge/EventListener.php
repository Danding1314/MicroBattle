<?php
namespace MBattleBridge;

use pocketmine\entity\Effect;
use pocketmine\entity\Snowball;
use pocketmine\entity\Attribute;
use pocketmine\entity\AttributeMap;

use pocketmine\Player;
use pocketmine\item\Item;
use pocketmine\block\Block;
use pocketmine\block\Air;
use pocketmine\block\Chest;
use pocketmine\tile\Tile;
use pocketmine\tile\Sign;
use pocketmine\tile\Chest as TileChest;
use pocketmine\scheduler\ServerScheduler;
use pocketmine\scheduler\PluginTask;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Config;
use pocketmine\math\Vector3;
use pocketmine\inventory\PlayerInventory;
use pocketmine\inventory\BigShapedRecipe;
use pocketmine\inventory\ShapedRecipe;
use pocketmine\inventory\ShapelessRecipe;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerKickEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\ProjectileLaunchEvent;
use pocketmine\event\entity\EntityDespawnEvent;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\ExplosionPrimeEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerTextPreSendEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\event\server\DataPacketSendEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityRegainHealthEvent;

use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\format\mcregion\Chunk;
use pocketmine\level\format\FullChunk;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\level\particle\Particle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\HeartParticle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\particle\RedstoneParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\WaterParticle;
use pocketmine\level\sound\ClickSound;
use pocketmine\level\sound\DoorSound;
use pocketmine\level\sound\LaunchSound;
use pocketmine\level\sound\PopSound;

use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\EnumTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;

use MBattleBridge\MBattleBridge;
use MBattleBridge\Room;
use MBattleBridge\chapters\Chapter;
use MBattleBridge\chapters\bedwars;
use MBattleBridge\Language;
class EventListener implements Listener{
	public $edit;
	
	public $tap;
	
	public $use;
	
	public $order;
	
	public function __construct(MBattleBridge $plugin){
		$this->plugin = $plugin;
		$this->edit = [];
		$this->tap = [];
		$this->use = [];
		$this->order = [];
	}
	
	public function onJoin(PlayerJoinEvent $event){
		$player = $event->getPlayer();
		if($player instanceof Player){
		$config = $this->plugin->getPlayerConfig($player);
		if($config->get("Quit") != 0){
			$config->set("Quit", 0);
			$config->save();
			$this->plugin->showPlayer($player);
			$player->teleport($this->plugin->getServer()->getDefaultLevel()->getSafeSpawn());
		    $player->getInventory()->clearAll();
			$player->getInventory()->sendContents($player);
			$player->gamemode = 4;
			$player->setGamemode($this->plugin->getPlayerConfig($player)->get("Gamemode"));
            $player->setMaxHealth(20);
            $player->setMaxHealth($player->getMaxHealth());
			$player->getInventory()->clearAll();
			$player->getInventory()->sendContents($player);
			$player->setSprinting(false);
            $player->setSneaking(false);
            $player->extinguish();
			$player->removeAllEffects();
            $player->setHealth($player->getMaxHealth());
			if(!empty($player->getInventory()->getContents())){
				$config->set("Quit", 1);
				$config->save();
				$player->kick();
			}
		}
		}
	}
	
	public function onQuit(PlayerQuitEvent $event){
		$player = $event->getPlayer();
		$room = $this->plugin->findRoom($player->getName());
		if($room !== null){
			$room->quitPlayer($player->getName());
			$config = $this->plugin->getPlayerConfig($player->getName());
			$config->set("Quit",1);
			$config->save();
		}
	}

	
	/**
	 * @param BlockPlaceEvent $event
	 *
	 * @priority MONITOR
	 */		
	public function onBlockPlace(BlockPlaceEvent $event){
		$player = $event->getPlayer();
		$level = $player->getLevel();
		$room = $this->plugin->getRoomByLevel($level);
		if($room == null){
			return true;
		}
		if($room->getChapter()->onBlockPlace($event) !== "default"){
			return;
		}
		if($room->isStarted()){
			if($event->isCancelled()){
				$event->setCancelled(false);
			}
			$block = $event->getBlock();
			if($block instanceof Chest){
				$event->setCancelled();
				return;
			}
			if($room->isSpectator($player)){
				$event->setCancelled();
				return;
			}
					//todo:more function
		}else{
			if($player->isOp() and $this->plugin->config["禁止OP破壞遊戲地圖的方塊"] !== true){
				if(in_array($player->getName(), $this->edit)){
				}else{
					$this->edit[] = $player->getName();
					$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "edit.op"));
				}
				return;
			}
			$event->setCancelled();
			if(in_array($player->getName(), $this->edit)){
				
			}else{
				$this->edit[] = $player->getName();
				$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "edit.before.start"));
			}
		}
	}
	
	
	/**
	 * @param BlockBreakEvent $event
	 *
	 * @priority MONITOR
	 */		
	public function onBlockBreak(BlockBreakEvent $event){
		$player = $event->getPlayer();
		$name = $player->getName();
		$block = $event->getBlock();
		$loc = $block->getX().":".$block->getY().":".$block->getZ().":".$block->getLevel()->getFolderName();
		if(isset($this->plugin->signs[$loc])){
			if($player->isOp()){
				$this->plugin->sendMessage($player,$this->plugin->getMessage($player,"remove.sign"));
				unset($this->plugin->signs[$loc]);
				$this->plugin->saveSigns();
			}else{
				$event->setCancelled();
			}
	    }
		$level = $player->getLevel();
		$room = $this->plugin->getRoomByLevel($level);
		if($room == null){
			return true;
		}
		if($room->getChapter()->onBlockBreak($event) !== "default"){
			return;
		}
		if($room->isStarted()){
			if($event->isCancelled()){
				$event->setCancelled(false);
			}
			$block = $event->getBlock();
			if(($team2 = $room->getTeam($name)) == null){
				$event->setCancelled();
				return;
			}
			if($room->isSpectator($player)){
				$event->setCancelled();
				return;
			}
			switch($block->getID()){
				case 14:
				$event->setDrops([Item::get([314,315,316,317,283,284,285,286][mt_rand(0,7)],0,1)]);
				break;
				
				case 15:
				$event->setDrops([Item::get([306,307,308,309,256,257,258,267][mt_rand(0,7)],0,1)]);
				break;
				
				break;

				case 56:
				$event->setDrops([Item::get([276,277,278,279,310,311,312,313][mt_rand(0,7)],0,1)]);
				break;

				case 16:
				case 73:
				case 74:
				$event->setDrops([Item::get([259,46,264,265,266,364,366,354,322,320,261,262][mt_rand(0,11)],0,mt_rand(1,3))]);
				$event->setDrops([Item::get([259,46,264,265,266,364,366,354,322,320,261,262][mt_rand(0,11)],0,mt_rand(1,3))]);
				break;

				case 21:
				case 129:
				$event->setDrops([Item::get([302,303,304,305][mt_rand(0,3)],0,1)]);
				$event->setDrops([Item::get([302,303,304,305][mt_rand(0,3)],0,1)]);
				break;
			}
		}else{
			if($player->isOp() and $this->plugin->config["禁止OP破壞遊戲地圖的方塊"] !== true){
				if(in_array($player->getName(), $this->edit)){
				}else{
					$this->edit[] = $player->getName();
					$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "edit.op"));
				}
				return;
			}
			$event->setCancelled();
			if(in_array($player->getName(), $this->edit)){
				
			}else{
				$this->edit[] = $player->getName();
				$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "edit.before.start"));
			}
		}
    }
	
	public function onPlayerCmd(PlayerCommandPreprocessEvent $event){
		if(substr($event->getMessage(), 0, 1) === "/"){
	    $player = $event->getPlayer();
		if(substr($event->getMessage(), 0, 3) == "/bb"){
			if(!$this->plugin->checkRate($player, "command")){
				$event->setCancelled();
			}
			return false;
		}
		if($this->plugin->findRoom($player) !== null and substr($event->getMessage(), 0, 3) !== "/bb"){
			if($player->isOp()){
				if($this->plugin->config["禁止OP遊戲中輸入其他指令"] == true){
					$event->setCancelled();
					$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "command.ingame"));					
				}
				return;
			}
			$event->setCancelled();
			$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "command.ingame"));
		}
		}
	}
	
	public function onTeleport(EntityTeleportEvent $event){
		$player = $event->getEntity();
		if($player instanceof Player){
			if($event->getTo()->level instanceof Level){
			if($this->plugin->isGameLevel($event->getTo()->level->getFolderName()) and !$player->isOp()){
				if($this->plugin->findRoom($player) == null){
					$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "teleport.togame"));
					$event->setCancelled();
				}
			}
			}
		}
	}
	
	public function onDeath(PlayerDeathEvent $event){
		$player = $event->getEntity();
		if($player instanceof Player){
			$room = $this->plugin->findRoom($player);
			if($room !== null){
				if($room->getChapter()->onDeath($event) !== "default"){
					return;
				}
				if($room->isSpectator($player) or !$room->isStarted()){
					$room->quitPlayer($player);
					return;
				}
                $config = $this->plugin->getPlayerConfig($player);
				$config->set("Death", $config->get("Death") + 1);
				$config->save();
				unset($config);
				$this->plugin->calculate($player,"death",1);
				$cause = $this->getLastDamager($player);
				if($cause instanceof Player){
					$config = $this->plugin->getPlayerConfig($cause);
					$config->set("Kill", $config->get("Kill") + 1);
					$config->save();
					unset($config);
					$this->plugin->calculate($cause,"kill",1);
					$this->plugin->mgb->updateCoin($cause, $this->plugin->config["擊殺獲得金幣量"]);
					$cause->sendMessage($this->plugin->getMessage($cause, "game.kill.getcoins", [$this->plugin->mgb->getMP($player)->getGamename(), $this->plugin->config["擊殺獲得金幣量"]]));
					$room->wMessage("game.die.player", [$this->plugin->mgb->getMP($player)->getGamename(), $this->plugin->mgb->getMP($cause)->getGamename()]);
					$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "game.die.player",[$this->plugin->mgb->getMP($cause)->getGamename()]));
					$event->setDeathMessage("");
				}elseif($cause == "magic"){
					$room->wMessage("game.die.magic", [$this->plugin->mgb->getMP($player)->getGamename(), $this->plugin->getMessage(null, $room->getChapter()->getDeathMessage())]);
					$event->setDeathMessage("");
				}else{
					$room->wMessage("game.die.unknown", [$this->plugin->mgb->getMP($player)->getGamename()]);
				}

				$id = $player->getId();
				if(array_key_exists($id,$this->order)){
					$this->order[$id]=array();
				}				
				$room->ifwin();
				if(!$room->isStarted()){
					$event->setKeepInventory(false);
					$event->setDrops([]);
				}else{
					$event->setKeepInventory(false);
				}
			}
		}
	}
	
	public function onItemHeld(PlayerItemHeldEvent $event){
		$player = $event->getPlayer();
		$item = $player->getInventory()->getItemInHand();
		if(($room = $this->plugin->findRoom($player)) !== null){
			if($room->getChapter()->onItemHeld($event) !== "default"){
				return;
			}
			switch($item->getID()){
				case 318:
				$nbt=new CompoundTag("", [
					"ench"=>new CompoundTag("ench",[]),
					"display"=> new CompoundTag("display", [
					"Name" => new StringTag("Name",$this->plugin->getMessage(null, "item.318"))
					])
				]);
				$player->getInventory()->setItemInHand($item->setNamedTag($nbt));
				return;
				
				case 352:
				$nbt=new CompoundTag("", [
					"ench"=>new CompoundTag("ench",[]),
					"display"=> new CompoundTag("display", [
					"Name" => new StringTag("Name",$this->plugin->getMessage(null, "item.352"))
					])
				]);
				$player->getInventory()->setItemInHand($item->setNamedTag($nbt));
				return;
				
				case 403:
				$nbt=new CompoundTag("", [
					"ench"=>new CompoundTag("ench",[]),
					"display"=> new CompoundTag("display", [
					"Name" => new StringTag("Name",$this->plugin->getMessage(null, "item.403"))
					])
				]);
				$player->getInventory()->setItemInHand($item->setNamedTag($nbt));
				return;

				case 288:
				$nbt=new CompoundTag("", [
					"ench"=>new CompoundTag("ench",[]),
					"display"=> new CompoundTag("display", [
					"Name" => new StringTag("Name",$this->plugin->getMessage(null, "item.288"))
					])
				]);
				$player->getInventory()->setItemInHand($item->setNamedTag($nbt));
				return;
			}
		}
	}
	
	/**
	 * @param PlayerRespawnEvent $event
	 *
	 * @priority LOWEST
	 */
	public function onRespawn(PlayerRespawnEvent $event){
		$player = $event->getPlayer();
		if($player instanceof Player){
			$room = $this->plugin->findRoom($player);
			if($room !== null){
				if($room->getChapter()->onRespawn($event) !== "default"){
					return;
				}
				if($room->isWar()){
					$room->spectate($player, 0);
					$this->plugin->sendMessage($player, $this->plugin->getMessage($player, "game.spectate.ready"));
					$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new \MBattleBridge\tasks\RespawnTask($this->plugin, $player, $room, "spectate"), 1200/$this->plugin->getServer()->getTicksPerSecondAverage()+0.5);
				}else{
					if($room->isStarted()){
						$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "game.respawn.ready"));
					$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new \MBattleBridge\tasks\RespawnTask($this->plugin, $player, $room, "respawn"), 1200/$this->plugin->getServer()->getTicksPerSecondAverage()+0.5);						
					}else{
						$room->quitPlayer($player);
					}
				}
			}else{
				$level = $this->plugin->getServer()->getLevelByName($this->plugin->config["排行榜坐標"]["level"]);
				if($level instanceof Level){
					$level->addParticle($this->plugin->ranking,[$player]);
				}
			}
		}
	}

	public function onDamage(EntityDamageEvent $event){
	    $player = $event->getEntity();
		$room = $this->plugin->findRoom($player);
		if($room !== null){
			if(!$room->isStarted()){
				$event->setCancelled();
				return true;
			}
			if($room->getChapter()->onDamage($event) !== "default"){
				return;
			}
			if($event instanceof EntityDamageByEntityEvent){
				$damager = $event->getDamager();
				if($player instanceof Player and $damager instanceof Player){
					$name = $player->getName();
					if($room->isSpectator($damager)){
						$event->setCancelled();
						return false;
					}
				if(!$room->isWar()){
					$event->setCancelled();
				}else{
					if($room->getTeam($damager) == $room->getTeam($player)){
						if($room->isTeammateDamage()){
							
						}else{
							$event->setCancelled();
							return;
						}
					}
					$this->plugin->calculate($damager,"damage",(int)$event->getDamage());
				}
				}
			}
		}
	}
	
    public static function getLastDamager($player) {
		$cause = $player->getLastDamageCause();
		if ($cause instanceof EntityDamageByEntityEvent) {
            $killer = $cause->getDamager();
		    return $killer;
		}elseif(@$cause->getCause() == EntityDamageEvent::CAUSE_MAGIC){
			return "magic";
		}
		else {
			return false;
		}
	}
	
	/**
	 * @param PlayerChatEvent $event
	 *
	 * @priority LOWEST
	 */
	public function onChat(PlayerChatEvent $event){
		$player = $event->getPlayer();
		$room = $this->plugin->findRoom($player);
		if($room !== null){
			$message = "";
			if($room->isSpectator($player)){
				$message .= "§7觀戰";
			}
			$team = $room->getTeam($player);
			switch($team){
				case "red":
				$message .= "§7[§d❤".$player->getHealth()." §c".$this->plugin->mgb->getMP($player)->getGamename()."§7]: ";
				break;
				case "blue":
				$message .= "§7[§d❤".$player->getHealth()." §b".$this->plugin->mgb->getMP($player)->getGamename()."§7]: ";
				break;
				case "yellow":
				$message .= "§7[§d❤".$player->getHealth()." §e".$this->plugin->mgb->getMP($player)->getGamename()."§7]: ";
				break;
				case "green":
				$message .= "§7[§d❤".$player->getHealth()." §a".$this->plugin->mgb->getMP($player)->getGamename()."§7]: ";
				break;
				default:
				$message .= "§7[§d❤".$player->getHealth()." §f".$this->plugin->mgb->getMP($player)->getGamename()."§7]: ";
				break;
			}
			$room->wMessage($message.$event->getMessage());
			$event->setCancelled();
		}
	}
	
	public function onPickup(\pocketmine\event\inventory\InventoryPickupItemEvent $event){
		$player = $event->getInventory()->getHolder();
		if($player instanceof Player){
			$room = $this->plugin->findRoom($player);
			if($room !== null){
				if($room->isSpectator($player)){
					$event->setCancelled();
				}
			}
		}
	}
	
	public function onOpenInventory(\pocketmine\event\inventory\InventoryOpenEvent $event){
		if($this->plugin->isPHP7()){
		$player = $event->getPlayer();
		$room = $this->plugin->findRoom($player);
		if($room !== null){
			if($room->isSpectator($player)){
				$event->setCancelled();
			}
		}
		}
	}
	
	public function onCraft(\pocketmine\event\inventory\CraftItemEvent $event){
		if($this->plugin->isPHP7()){
		$player = $event->getPlayer();
		$room = $this->plugin->findRoom($player);
		if($room !== null){
			if($room->isSpectator($player)){
				$event->setCancelled();
			}
		}
		}
	}
	
   public function dataSendPacket(DataPacketSendEvent $event){
        $pk = $event->getPacket();
        if($pk->getName() == "CraftingDataPacket" and $this->plugin->isPHP7()){
			$player = $event->getPlayer();
			if(!$player instanceof Player){
				return;
			}
            if(($room = $this->plugin->findRoom($player)) !== null){
                if($room->getChapter() instanceof bedwars){
                    $list = $pk->entries;
                    foreach($list as $k=>$v){
                        unset($list[$k]);
                    }
                    $pk->clean();
                    $pk->entries = $list;
                        $item = new BigShapedRecipe(Item::get(Item::COOKED_PORKCHOP, 0, 2),
                            " P ",
                            "P P",
                            " P "
                        );
                        $item->setIngredient("P", Item::get(Item::BRICK, 0, 4));
                        $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                        $pk->addShapedRecipe($item);

                        $item = new BigShapedRecipe(Item::get(Item::GOLDEN_APPLE, 0, 1),
                            "   ",
                            " P ",
                            "   "
                        );
                        $item->setIngredient("P", Item::get(Item::IRON_INGOT, 0, 1));
                        $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                        $pk->addShapedRecipe($item);

                        $item = new BigShapedRecipe(Item::get(Item::STICK, 0, 1),
                            "PPP",
                            "P P",
                            "PPP"
                        );
                        $item->setIngredient("P", Item::get(Item::BRICK, 0, 8));
                        $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                        $pk->addShapedRecipe($item);

                        $item = new BigShapedRecipe(Item::get(369, 0, 1),
                            "PPP",
                            "P P",
                            "PPP"
                        );
                        $item->setIngredient("P", Item::get(Item::IRON_INGOT, 0, 8));
                        $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                        $pk->addShapedRecipe($item);

                        $item = new BigShapedRecipe(Item::get(Item::CHAIN_BOOTS, 0, 1),
                            "PPP",
                            "PPP",
                            "PPP"
                        );
                        $item->setIngredient("P", Item::get(Item::GOLD_INGOT, 0, 9));
                        $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                        $pk->addShapedRecipe($item);

                        $item = new BigShapedRecipe(Item::get(Item::COBWEB, 0, 1),
                            " P ",
                            "PPP",
                            " P "
                        );
                        $item->setIngredient("P", Item::get(Item::IRON_INGOT, 0, 5));
                        $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                        $pk->addShapedRecipe($item);

                        $item = new BigShapedRecipe(Item::get(Item::GUNPOWDER, 0, 1),
                            "PPP",
                            "AAA",
                            "LLL"
                        );
                        $item->setIngredient("P", Item::get(Item::BRICK, 0, 3));
                        $item->setIngredient("A", Item::get(Item::IRON_INGOT, 0, 3));
                        $item->setIngredient("L", Item::get(Item::GOLD_INGOT, 0, 3));
                        $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                        $pk->addShapedRecipe($item);

                    $item = new BigShapedRecipe(Item::get(Item::GOLD_SWORD, 0, 1),
                        "   ",
                        " P ",
                        "   "
                    );
                    $item->setIngredient("P", Item::get(Item::IRON_INGOT, 0, 1));
                    $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                    $pk->addShapedRecipe($item);

                    $item = new BigShapedRecipe(Item::get(Item::STONE_SWORD, 0, 1),
                        " P ",
                        "PPP",
                        " P "
                    );
                    $item->setIngredient("P", Item::get(Item::IRON_INGOT, 0, 5));
                    $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                    $pk->addShapedRecipe($item);

                    $item = new BigShapedRecipe(Item::get(Item::IRON_SWORD, 0, 1),
                        "   ",
                        "PPP",
                        "   "
                    );
                    $item->setIngredient("P", Item::get(Item::GOLD_INGOT, 0, 3));
                    $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                    $pk->addShapedRecipe($item);

                    $item = new BigShapedRecipe(Item::get(Item::SANDSTONE, 0, 2),
                        "   ",
                        " P ",
                        "   "
                    );
                    $item->setIngredient("P", Item::get(Item::BRICK, 0, 1));
                    $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                    $pk->addShapedRecipe($item);

                    $item = new BigShapedRecipe(Item::get(Item::CHEST, 0, 1),
                        "   ",
                        " P ",
                        "   "
                    );
                    $item->setIngredient("P", Item::get(Item::IRON_INGOT, 0, 1));
                    $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                    $pk->addShapedRecipe($item);

                    $item = new BigShapedRecipe(Item::get(Item::CHAIN_CHESTPLATE, 0, 1),
                        "   ",
                        "PPP",
                        "   "
                    );
                    $item->setIngredient("P", Item::get(Item::IRON_INGOT, 0, 3));
                    $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                    $pk->addShapedRecipe($item);

                    $item = new BigShapedRecipe(Item::get(Item::IRON_HELMET, 0, 1),
                        "PPP",
                        "PPP",
                        "PPP"
                    );
                    $item->setIngredient("P", Item::get(Item::GOLD_INGOT, 0, 9));
                    $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                    $pk->addShapedRecipe($item);

                    $item = new BigShapedRecipe(Item::get(Item::IRON_BOOTS, 0, 1),
                        "P P",
                        "PAP",
                        "P P"
                    );
                    $item->setIngredient("A", Item::get(Item::GOLD_INGOT, 0, 1));
                    $item->setIngredient("P", Item::get(Item::IRON_INGOT, 0, 6));
                    $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                    $pk->addShapedRecipe($item);

                    $item = new BigShapedRecipe(Item::get(Item::STONE_PICKAXE, 0, 1),
                        "P P",
                        "   ",
                        "P P"
                    );
                    $item->setIngredient("P", Item::get(Item::BRICK, 0, 4));
                    $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                    $pk->addShapedRecipe($item);

                    $item = new BigShapedRecipe(Item::get(Item::IRON_PICKAXE, 0, 1),
                        "   ",
                        "P P",
                        "   "
                    );
                    $item->setIngredient("P", Item::get(Item::IRON_INGOT, 0, 2));
                    $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                    $pk->addShapedRecipe($item);

                    $item = new BigShapedRecipe(Item::get(Item::GOLD_PICKAXE, 0, 1),
                        "   ",
                        " P ",
                        "   "
                    );
                    $item->setIngredient("P", Item::get(Item::GOLD_INGOT, 0, 1));
                    $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                    $pk->addShapedRecipe($item);

                    $item = new BigShapedRecipe(Item::get(Item::ARROW, 0, 64),
                        "   ",
                        " P ",
                        "   "
                    );
                    $item->setIngredient("P", Item::get(Item::GOLD_INGOT, 0, 1));
                    $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                    $pk->addShapedRecipe($item);
                    $item = new BigShapedRecipe(Item::get(Item::BOW, 0, 1),
                        " P ",
                        "PPP",
                        " P "
                    );
                    $item->setIngredient("P", Item::get(Item::GOLD_INGOT, 0, 5));
                    $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                    $pk->addShapedRecipe($item);
					
                    $item = new BigShapedRecipe(Item::get(Item::SNOWBALL, 0, 2),
                        " P ",
                        "P P",
                        " P "
                    );
                    $item->setIngredient("P", Item::get(Item::GOLD_INGOT, 0, 4));
                    $this->plugin->getServer()->getCraftingManager()->registerRecipe($item);
                    $pk->addShapedRecipe($item);				
                }else {
					
                }
            }else{
				
            }
        }
    }
	
	public function onProjectileLaunch(ProjectileLaunchEvent $event){
		$entity = $event->getEntity();
		if($entity instanceof Snowball){
			$shooter = $entity->shootingEntity;
			$ballid = $entity->getId();
			if($shooter instanceof Player){
				if(!$this->plugin->isGameLevel($shooter->getLevel()->getFolderName())){
					return true;
				}
				$shooter->sendMessage(MBattleBridge::FORMAT."§6傳送球§a發射成功");
				$id = $shooter->getId();
				if(array_key_exists($id,$this->order)){
					array_push($this->order[$id],$ballid);
				}
				else{
					$this->order += array($id => array($ballid));
				}
			}
		}
	}	
	
	public function onEntityClose(EntityDespawnEvent $event){
		if($event->getType() === 81){
			$entity = $event->getEntity();
			$ballid = $entity->getId();
			$shooter = $entity->shootingEntity;
			$posTo = $entity->getPosition();
			if($posTo instanceof Position){
				if($shooter instanceof Player){
				if(!$this->plugin->isGameLevel($shooter->getLevel()->getFolderName())){
					return true;
				}
				if($posTo->y <= 2){
					$shooter->sendMessage(MBattleBridge::FORMAT."§6傳送球§c目標高度過低,無法傳送");
					return true;
				}
					$id = $shooter->getId();
					$key = array_search($ballid,$this->order[$id]);
					if(array_key_exists($id,$this->order) && $key!==false ){
						unset($this->order[$id][$key]);
						$posFrom = $shooter->getPosition();
						$shooter->teleport($posTo);
					}
				}
			}
		}
		if($event->isHuman() ){
			$entity = $event->getEntity();
			$id = $entity->getId();
			if(array_key_exists($id,$this->order)){
				unset($this->order[$id]);
			}
		}
	}	
	/*
	public function onTextPreSend(\MGameBase\event\PlayerTextPreSendEvent $event){
		$player = $event->getPlayer();
		if($this->plugin->findRoom($player) !== null and $event->getMessageType() !== 0){
			switch($this->plugin->config["遊戲途中處理其他popup和tip消息(0為不啟用但容易造成消息沖突閃爍,1為屏蔽其他消息【建議】,2為轉化為message但容易刷屏)"]){
				case "1":
				case 1:
				$event->setMessage("");
				$event->setCancelled();
				break;
				
				case "2":
				case 2:
				$message = $event->getMessage();
				$message = str_replace(array("\n",'\n'," "), "", $message);
				$this->plugin->sendMessage($player,$message);
				$event->setMessage("");
				$event->setCancelled();
				break;
				
				default:
				break;
			}
		}
	}
	*/
	
	/**
	 * @param PlayerInteractEvent $event
	 *
	 * @priority MONITOR
	 */		
	public function ouTouch(PlayerInteractEvent $event){
		$block = clone $event->getBlock();
		$player = $event->getPlayer();
		$name = strtolower($player->getName());
		$v3 = new Vector3($block->x, $block->y, $block->z);
		$loc = $block->getX().":".$block->getY().":".$block->getZ().":".$block->getLevel()->getFolderName();
		if(isset($this->plugin->signs[$loc])){
			if(!$this->plugin->checkRate($player, "touch")){
				return false;
			}
			$now = microtime(true);
			if(!isset($this->tap[$name])){
				$this->tap[$name] = [$loc, $now, 0];
				if(0 == $this->plugin->config["點擊方塊進行某行動的額外確認次數"]){
				unset($this->tap[$name]);
				switch($this->plugin->signs[$loc]["type"]){
				case "join":
				$room = $this->plugin->getRoom($this->plugin->signs[$loc]["room"]);
				if($room !== null and $this->plugin->findRoom($player) == null){
					$room->joinPlayer($player);
				}
				break;
				
				case "spectate":
				$room = $this->plugin->getRoom($this->plugin->signs[$loc]["room"]);
				if($room !== null and $this->plugin->findRoom($player) == null){
					$room->spectate($player,2);
				}
				break;
				
				case "quit";
				$room = $this->plugin->findRoom($player);
				if($room !== null){
					$room->quitPlayer($player);
				}
				break;
				
				case "team":
				$room = $this->plugin->findRoom($player);
				if($room == null){
					$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "join.team.no.room"));
					return false;
				}
				if($this->plugin->signs[$loc]["team"] == "quit"){
					$room->quitTeam($player);
				}else{
					$room->joinTeam($player, $this->plugin->signs[$loc]["team"]);
				}
				break;
				}
				return;	
				}
				$player->sendPopup($this->plugin->getMessage($player, "tap.again"));
				return;
			}
			if($now - $this->tap[$name][1] >= 2  or $this->tap[$name][0] !== $loc or $this->tap[$name][2] < $this->plugin->config["點擊方塊進行某行動的額外確認次數"]){
				$this->tap[$name] = [$loc, $now, $this->tap[$name][2]+1];
				$this->plugin->sendPopup($player,$this->plugin->getMessage($player, "tap.again"));
				return;
			}else{
				unset($this->tap[$name]);
			}
			switch($this->plugin->signs[$loc]["type"]){
				case "join":
				$room = $this->plugin->getRoom($this->plugin->signs[$loc]["room"]);
				if($room !== null and $this->plugin->findRoom($player) == null){
					$room->joinPlayer($player);
				}
				break;
				
				case "spectate":
				$room = $this->plugin->getRoom($this->plugin->signs[$loc]["room"]);
				if($room !== null and $this->plugin->findRoom($player) == null){
					$room->spectate($player,2);
				}
				break;
				
				case "quit";
				$room = $this->plugin->findRoom($player);
				if($room !== null){
					$room->quitPlayer($player);
				}
				break;
				
				case "team":
				$room = $this->plugin->findRoom($player);
				if($room == null){
					$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "join.team.no.room"));
					return false;
				}
				if($this->plugin->signs[$loc]["team"] == "quit"){
					$room->quitTeam($player);
				}else{
					$room->joinTeam($player, $this->plugin->signs[$loc]["team"]);
				}
				break;
			}
		}
		if(($room = $this->plugin->findRoom($player)) !== null){
		switch($event->getItem()->getId()){
			case 318:
			$now = microtime(true);
			if(!isset($this->use[$name]) or $now - $this->use[$name][0] >= 1.5){
				$this->use[$name] = [$now];
				$this->plugin->sendPopup($player,$this->plugin->getMessage($player, "use.again"));
				break;
			}else{
				unset($this->use[$name]);
			}
			$room->quitPlayer($player);
			break;
			
			
			case 352:
			$now = microtime(true);
			if(!isset($this->use[$name]) or $now - $this->use[$name][0] >= 1.5){
				$this->use[$name] = [$now];
				$this->plugin->sendPopup($player,$this->plugin->getMessage($player, "use.again"));
				break;
			}else{
				unset($this->use[$name]);
			}
			switch($block->getID().":".$block->getDamage()){
				case "35:14":
				case "159:14":
				$room->joinTeam($player, "red");
				break;
				
				case "35:5":
				case "159:5":
				$room->joinTeam($player, "green");
				break;
				
				case "35:3":
				case "35:9":
				case "35:11":
				case "159:3":
				case "159:11":
				$room->joinTeam($player, "blue");
				break;
				
				case "35:4":
				case "159:4":
				$room->joinTeam($player, "yellow");
				break;
				
				default:
				$room->joinTeam($player, "random");
				break;
				
			}
			break;
			
			
			case 347:
			$this->plugin->sendMessage($player,MBattleBridge::FORMAT."§b現實§7時間:§e".date('y-m-d h:i:s',time()));
			$this->plugin->sendMessage($player,MBattleBridge::FORMAT."§c地圖§7時間:§e".$player->getLevel()->getTime());
			break;
			
			
			case 403:
			$info = $this->plugin->getPlayerConfig($name)->getAll();
			$msg = "§7(|-<>-§7[§5我§7]§e的§b戰橋§e信息§7-<>-|)\n";
			$msg .= "§3勝利場次§7:§f ".$info["Win"]."\n";
			$msg .= "§3殺敵數§7:§f ".$info["Kill"]."\n";
			$msg .= "§3死亡數§7:§f ".$info["Death"]."\n";
			if($info["Death"] <= 0){
				$kd = "100%";
			}else{
				$kd = round($info["Kill"]/$info["Death"], 2);
			}
			//$msg .= "§3KD比§7:§f ".$kd."\n";
			$msg .= "§3遊戲稱號§7:§f ".$info["Nametag"]."\n";
			$msg .= "§3戰橋時間§7:§f ".intval($info["Time"] / 60)."分鐘"."\n";
			$this->plugin->sendMessage($player,$msg);
			unset($msg);
			break;
			
			
			case 288:
			$now = microtime(true);
			if(!isset($this->use[$name]) or $now - $this->use[$name][0] >= 1.5){
				$this->use[$name] = [$now];
				$this->plugin->sendPopup($player,$this->plugin->getMessage($player, "use.again"));
				break;
			}else{
				unset($this->use[$name]);
			}
			$array = [];
			$array2 = [];
			foreach(MBattleBridge::$allteams as $team){
				foreach($room->gamers[$team] as $p){
					if(!$room->isSpectator($p)){
						$array[$team]["alive"][] = $p;
					}else{
						$array[$team]["dead"][] = $p;
					}
					$array2[] = $p;
				}
			}
			unset($p);
			foreach($room->gamers["all"] as $p){
				if(!in_array($p, $array2)){
					$array["extra"][] = $p;
				}
			}
			unset($array2,$p);
			$msg = "\n";
			$msg .= "\n§7[§cRed§7]:§l§c".@implode("§7-§c", $array["red"]["alive"])." §r§o§7".@implode(",", $array["red"]["dead"]);
			$msg .= "\n§7[§bBlue§7]:§l§b".@implode("§7-§b", $array["blue"]["alive"])." §r§o§7".@implode(",", $array["blue"]["dead"]);
			$msg .= "\n§7[§eYellow§7]:§l§e".@implode("§7-§e", $array["yellow"]["alive"])." §r§o§7".@implode(",", $array["yellow"]["dead"]);
			$msg .= "\n§7[§aGreen§7]:§l§a".@implode("§7-§a", $array["green"]["alive"])." §r§o§7".@implode(",", $array["green"]["dead"]);
			$msg .= "\n§6非遊戲內觀戰玩家:§7".@implode(",",$array["extra"]);
			$this->plugin->sendMessage($player,MBattleBridge::FORMAT."§5此房間的戰橋遊戲玩家:".$msg);
			unset($array);
			break;
			
			case 289:
			if($room->getChapter() instanceof bedwars and $event->getAction() == PlayerInteractEvent::RIGHT_CLICK_AIR){
				if(($team == $room->getTeam($player)) !== null){
					$player->teleport($room->getGamePos($team));
					$player->getInventory()->removeItem(new Item(289, 0, 1));
                    $player->getInventory()->sendContents($player);
                    $player->getInventory()->open($player);
				}
			}
			break;
		}
			if($event->isCancelled()){
				$event->setCancelled(false);
			}
		}
	}
	
   public function onSignChange(SignChangeEvent $event){
		$line = $event->getLines();
		if($line[0] == "bb"){
			$player = $event->getPlayer();
			if(!$player->isOp()){
				$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "no.permission"));
				$event->setCancelled();
				return;
			}
			switch($line[1]){
				case "enter":
				case "join":
				case "room":
				case "加入":
			    if(!isset($line[2]) or !is_numeric($line[2])){
					$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "sign.join.line_3_must_be_number"));
				    return;
			    }
				$room = (int)$line[2];
			    if($room <= 0){
					$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "sign.join.room_0"));
				    return;
			    }
				$block = $event->getBlock();
			    $this->plugin->signs[$block->getX().":".$block->getY().":".$block->getZ().":".$block->getLevel()->getFolderName()] = [
				"x" => $block->getX(),
				"y" => $block->getY(),
				"z" => $block->getZ(),
				"level" => $block->getLevel()->getFolderName(),
				"room" => $room,
				"team" => null,
				"type" => "join",
			    ];
			    $event->setLine(0, MBattleBridge::FORMAT);
			    $event->setLine(1, "§7[§6加入遊戲§7]");
			    $event->setLine(2, "§b房間§7: §e".$room);
			    $event->setLine(3, MBattleBridge::FORMAT);
				$this->plugin->saveSigns();
				break;
//---------------------------------------------------------------------------
				case "left":
				case "quit":
				case "退出":
				$block = $event->getBlock();
			    $this->plugin->signs[$block->getX().":".$block->getY().":".$block->getZ().":".$block->getLevel()->getFolderName()] = [
				"x" => $block->getX(),
				"y" => $block->getY(),
				"z" => $block->getZ(),
				"level" => $block->getLevel()->getFolderName(),
				"room" => null,
				"team" => null,
				"type" => "quit",
			    ];
			    $event->setLine(0, MBattleBridge::FORMAT);
			    $event->setLine(1, "§7[§6退出遊戲§7]");
			    $event->setLine(2, "§3退出您所在的房間");
			    $event->setLine(3, MBattleBridge::FORMAT);
				$this->plugin->saveSigns();
				break;
				
				case "watch":
				case "see":
				case "look":
				case "看":
				case "觀戰":
				case "spectate":
			    if(!isset($line[2]) or !is_numeric($line[2])){
					$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "sign.spectate.line_3_must_be_number"));
				    return;
			    }
				$room = (int)$line[2];
			    if($room <= 0){
					$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "sign.spectate.room_0"));
				    return;
			    }
				$block = $event->getBlock();
			    $this->plugin->signs[$block->getX().":".$block->getY().":".$block->getZ().":".$block->getLevel()->getFolderName()] = [
				"x" => $block->getX(),
				"y" => $block->getY(),
				"z" => $block->getZ(),
				"level" => $block->getLevel()->getFolderName(),
				"room" => $room,
				"team" => null,
				"type" => "spectate",
			    ];
				$this->plugin->saveSigns();
			    $event->setLine(0, MBattleBridge::FORMAT);
			    $event->setLine(1, "§7[§3觀戰§7]");
			    $event->setLine(2, "§b房間§7: §e".$room);
			    $event->setLine(3, MBattleBridge::FORMAT);
				$this->plugin->saveSigns();
				break;
				
				case "team":
				case "choose":
				case "選擇":
				case "隊伍":
			    if(!isset($line[2])){
					$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "sign.team.line_3"));
				     return;
			    }
				$team = strtolower($line[2]);
				switch($team){
					case "紅隊":
					case "紅":
					$team = "red";
					break;
						
					case "藍隊":
					case "藍":
					$team = "blue";
					break;
						
					case "黃隊":
					case "黃":
					$team = "yellow";
					break;
						
					case "綠隊":
					case "綠":
					$team = "green";
					break;
					
					case "隨機":
					$team = "random";
					break;
					
					case "退出":
					case "left":
					$team = "quit";
					break;
				}
			    if(!in_array($team, MBattleBridge::$allteams) and $team !== "random" and $team !== "quit"){
					$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "sign.team.line_3_must_be_team"));
				    return;
			    }
				$block = $event->getBlock();
			    $this->plugin->signs[$block->getX().":".$block->getY().":".$block->getZ().":".$block->getLevel()->getFolderName()] = [
				"x" => $block->getX(),
				"y" => $block->getY(),
				"z" => $block->getZ(),
				"level" => $block->getLevel()->getFolderName(),
				"room" => null,
				"team" => $team,
				"type" => "team",
			    ];
			    $event->setLine(0, MBattleBridge::FORMAT);
			    $event->setLine(1, "§7[§6選擇隊伍§7]");
			    $event->setLine(2, "§b隊伍§7: §e".Language::$message[$team]);
			    $event->setLine(3, MBattleBridge::FORMAT);
				$this->plugin->saveSigns();
				break;				
				
				default:
				$this->plugin->sendMessage($player,$this->plugin->getMessage($player, "sign.line_2"));
				break;
			}
		}	
	}
}


