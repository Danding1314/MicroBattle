<?php
namespace MBattleBridge\chapters;

use MBattleBridge\chapters\Chapter;
use MBattleBridge\MBattleBridge;
use MBattleBridge\Room;
use pocketmine\block\Block;
use pocketmine\entity\Effect;
use pocketmine\level\Level;
use pocketmine\level\weather\Weather;
use pocketmine\event\entity\EntityCombustByBlockEvent;
use pocketmine\event\entity\EntityDamageByBlockEvent;
use pocketmine\event\entity\EntityDamageEvent;
class sahara extends Chapter{
	
	public function __construct(Room $room){
		$this->hasChanged = false;
		$this->room = $room;
	}
	
	public function onTick($newtime){
		$class = get_class($this->getChapterBlock());
		foreach($this->room->getPlayers() as $player){
			$block = $player->getLevel()->getBlock(new \pocketmine\level\Position($player->x,$player->y-1,$player->z));
			if($block instanceof $class and !$this->room->isSpectator($player)){
				$this->onTouch($player);
			    break;
			}
		}
	}
	
	public function onTouch($player){
		$ev = new EntityDamageEvent($player, EntityDamageEvent::CAUSE_MAGIC, mt_rand(2,8));
		$player->attack($ev->getFinalDamage(), $ev);
		if(mt_rand(1,100) < 5){
			$player->getLevel()->setBlock(new \pocketmine\level\Position($player->x,$player->y-1,$player->z), new \pocketmine\block\Air());
			$player->getLevel()->setBlock(new \pocketmine\level\Position($player->x,$player->y-2,$player->z), new \pocketmine\block\Air());
			$player->getLevel()->setBlock(new \pocketmine\level\Position($player->x,$player->y-3,$player->z), new \pocketmine\block\Air());
			$player->getLevel()->setBlock(new \pocketmine\level\Position($player->x+mt_rand(-1,1),$player->y-1,$player->z+mt_rand(-1,1)), new \pocketmine\block\Air());
			$player->getLevel()->setBlock(new \pocketmine\level\Position($player->x+mt_rand(-1,1),$player->y-2,$player->z+mt_rand(-1,1)), new \pocketmine\block\Air());
			$player->getLevel()->setBlock(new \pocketmine\level\Position($player->x+mt_rand(-1,1),$player->y-1,$player->z+mt_rand(-1,1)), new \pocketmine\block\Air());
			$player->sendMessage($this->room->plugin->getMessage($player, "chapter.sahara.touch"));
		}
	}
	
	public function getName(){
		return "chapter.sahara";
	}
	
	public function getIntroduction(){
		return "chapter.saraha.introduction";
	}	
	
	public function getChapterBlock(){
		return Block::get(12);
	}
	
	public function getBridgeBlock(){
		return array(Block::get(17,1), Block::get(20));
	}
	
	public function getDeathMessage(){
		return "chapter.sahara.deathmessage";
	}	
}

?>