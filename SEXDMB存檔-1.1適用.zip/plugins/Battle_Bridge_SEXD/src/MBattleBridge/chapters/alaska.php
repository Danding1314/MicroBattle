<?php
namespace MBattleBridge\chapters;

use MBattleBridge\chapters\Chapter;
use MBattleBridge\chapters\Dynamic;
use MBattleBridge\MBattleBridge;
use MBattleBridge\Room;
use pocketmine\block\Block;
use pocketmine\entity\Effect;
use pocketmine\level\Level;
use pocketmine\level\weather\Weather;
use pocketmine\event\entity\EntityCombustByBlockEvent;
use pocketmine\event\entity\EntityDamageByBlockEvent;
use pocketmine\event\entity\EntityDamageEvent;
class alaska extends Dynamic{
	
	public function __construct(Room $room){
		$this->hasChanged = false;
		$this->room = $room;
		$this->changetime = mt_rand(240, 300);
	}
	
	public function onTick($newtime){
		$class = get_class($this->getChapterBlock());
		foreach($this->room->getPlayers() as $player){
			$block = $player->getLevel()->getBlock(new \pocketmine\level\Position($player->x,$player->y-1,$player->z));
			if($block instanceof $class and !$this->room->isSpectator($player)){
				$this->onTouch($player);
			    break;
			}
		}
	}	
	
	public function onTouch($player){
		if(!$this->isChanged()){
			$ev = new EntityDamageEvent($player, EntityDamageEvent::CAUSE_MAGIC, 8);
			$player->attack($ev->getFinalDamage(), $ev);
		}else{
			$ev = new EntityDamageEvent($player, EntityDamageEvent::CAUSE_MAGIC, 16);
			$player->attack($ev->getFinalDamage(), $ev);
		}
	}
	
	public function onChange(){
		$this->hasChanged = true;
		$this->room->getGameLevel()->getWeather()->setWeather(Weather::RAINY, 72000);
		foreach($this->room->getPlayers() as $player){
			$player->sendMessage($this->room->plugin->getMessage($player, "chapter.alaska.change"));
			if(!$this->room->isSpectator($player)){
			$player->sendMessage($this->room->plugin->getMessage($player, "chapter.alaska.change"));
			$player->removeAllEffects();
			$player->addEffect(Effect::getEffect(9)->setDuration(2147483648)->setAmplifier(0)->setVisible(false));
			}
		}
	}
	
	public function getName(){
		return "chapter.alaska";
	}
	
	public function getIntroduction(){
		return "chapter.alaska.introduction";
	}
	
	public function getChangeTime(){
		return $this->changetime;
	}
	
	public function isChanged(){
		return $this->hasChanged;
	}
	
	public function getChapterBlock(){
		return Block::get(80);
	}
	
	public function getDeathMessage(){
		return "chapter.alaska.deathmessage";
	}
	
	public function getBridgeBlock(){
		return array(Block::get(5,1),Block::get(5,5),Block::get(5,2));
	}
	
}

?>