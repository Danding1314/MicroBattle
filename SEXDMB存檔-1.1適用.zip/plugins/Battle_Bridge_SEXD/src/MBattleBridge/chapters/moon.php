<?php
namespace MBattleBridge\chapters;

use MBattleBridge\chapters\Chapter;
use MBattleBridge\chapters\Dynamic;
use MBattleBridge\MBattleBridge;
use MBattleBridge\Room;
use MBattleBridge\Language;
use MBattleBridge\EventListener;

use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\Player;

use pocketmine\block\Block;
use pocketmine\block\Chest;
use pocketmine\block\Air;

use pocketmine\level\Level;
use pocketmine\level\weather\Weather;
use pocketmine\level\Position;

use pocketmine\event\entity\EntityCombustByBlockEvent;
use pocketmine\event\entity\EntityDamageByBlockEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\level\particle\FloatingTextParticle;

use pocketmine\entity\Entity;
use pocketmine\entity\Effect;

use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\EnumTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;

class moon extends Chapter{
			
	public $level;
		
	public function __construct(Room $room){
		if(!$room->plugin->isPHP7()){
			$room->delete();
			return false;
		}
		$this->hasChanged = false;
		$this->room = $room;
		$this->edit = [];
		$this->order = [];
		$this->tap = [];
		$this->use = [];
		$this->money = [];
		$this->level = $room->getGameLevel();
	}
	
	public function isCustomTip(){
		return true;
	}
	
	public function onJoinPlayer($player){
		if($player instanceof Player){
			$player = strtolower($player->getName());
		}else{
			$player = strtolower($player);
		}
		$this->money[$player] = 0;
	}
	
	public function onQuitPlayer($player){
		if($player instanceof Player){
			$player = strtolower($player->getName());
		}else{
			$player = strtolower($player);
		}
		unset($this->money[$player]);
	}
	
	public function onTick($newtime){
		
		if(!$this->room->isStarted() or !$this->room->isLoaded() or !$this->level instanceof Level or (time() % 2) !== 0){
			
		}else{
			foreach($this->money as $owner => $m){
				$this->money[$owner] += 500;
			}
			
				if(!$this->room->isWar()){
					$newtime2 = $this->room->getWarTime()-$newtime;
				}elseif(!$this->isGenerated()){
					$newtime2 = $this->room->getBridgeTime()-$newtime;
				}else{
					$newtime2 = $newtime;
				}
				$minite = floor($newtime2 / 60);
				if($minite < 10)$minite = "0".$minite;
				$second = $newtime2 - $minite*60;
				if($second < 10)$second = "0".$second;
				$str = "                                 §6<>--§e[戰橋]§6--<>\n".
				"                                 §r§2時間§a:§7".$minite.":".$second."\n".
				"                                 §r§c紅隊§7:§o§3 ".$this->room->getPlayerNum("red")." §f|  "."§r§b藍隊§7:§o§3 ".$this->room->getPlayerNum("blue")."\n".
				"                                 §r§e黃隊§7:§o§3 ".$this->room->getPlayerNum("yellow")." §f|  "."§r§a綠隊§7:§o§3 ".$this->room->getPlayerNum("green")."\n".
				"                                 §8遊戲篇目§7: §3".$this->room->plugin->getMessage(null, $this->getName())."\n".
				"                                 §d當前階段§7: §3".$this->room->plugin->getMessage(null, $this->room->getStep())."\n";
				foreach($this->room->getPlayers() as $player){
					$new = "";
					$new .= "                                 §e遊戲金幣§7: §f".$this->money[strtolower($player->getName())]."\n";
					if($this->room->isSpectator($player)){
						$newmessage = "§f觀戰";
					}else{
						if($player->distance($this->room->getGamePos($this->room->getTeam($player))) <= 6){
							$new .= "                                 §8[§a可向腐竹買道具§8]\n";
						}else{
							$new .= "                                 §8[§7離腐竹距離過遠§8]\n";
						}
						$newmessage = $this->room->plugin->getMessage(null, $this->room->getTeam($player))."§7隊";
					}
					$newstr = $str.$new."                                 §r§6<>--§e[".$newmessage."§e]§6--<>\n\n\n\n";
					$player->sendTip($this->room->plugin->getMessage(null, $newstr));
					unset($newmessage,$newstr);
				}
		}
	}

	
	public function onTouch($player){
		
	}
	
	public function getName(){
		return "chapter.moon";
	}
	
	public function getIntroduction(){
		return "chapter.moon.introduction";
	}
	
	public function getChapterBlock(){
		return null;
	}
	
	public function getDeathMessage(){
		return "chapter.moon.deathmessage";
	}	
	
	public function getBridgeBlock(){
		return 121;
	}
	
}

?>