<?php
namespace MBattleBridge\chapters;

use MBattleBridge\chapters\Chapter;
use MBattleBridge\chapters\Dynamic;
use MBattleBridge\MBattleBridge;
use MBattleBridge\Room;
use MBattleBridge\Language;
use MBattleBridge\EventListener;

use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\Player;

use pocketmine\block\Block;
use pocketmine\block\Chest;
use pocketmine\block\Air;

use pocketmine\level\Level;
use pocketmine\level\weather\Weather;
use pocketmine\level\Position;

use pocketmine\event\entity\EntityCombustByBlockEvent;
use pocketmine\event\entity\EntityDamageByBlockEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\level\particle\FloatingTextParticle;

use pocketmine\entity\Entity;
use pocketmine\entity\Effect;

use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\EnumTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;

class skywars extends Chapter{
			
	public $level;
		
	public function __construct(Room $room){
		if(!$room->plugin->isPHP7()){
			$room->delete();
			return false;
		}
		$this->hasChanged = false;
		$this->room = $room;
		$this->edit = [];
		$this->order = [];
		$this->tap = [];
		$this->use = [];
		$this->room->info["war-time"] = 5;
		$this->level = $room->getGameLevel();
	}
	
	public function onTick($newtime){
		
		if(!$this->room->isStarted() or !$this->room->isLoaded() or !$this->level instanceof Level){
		}else{
			
		}
			
	}

	
	public function onBlockPlace($event){
		$room = &$this->room;
		$player = $event->getPlayer();
		$level = $player->getLevel();
		if($this->room->isStarted()){
			$block = $event->getBlock();
			if($block instanceof Chest){
				$event->setCancelled();
				return;
			}
			if($this->room->isSpectator($player)){
				$event->setCancelled();
				return;
			}
		    $id = $block->getId();
		    switch($id){
			case 46:
			$block->onActivate(new Item(259));
			break;
			
			case 6:
			$block->onActivate(new Item(352));
			break;
		   }
		}else{
			if($player->isOp() and $room->plugin->config["禁止OP破壞遊戲地圖的方塊"] !== true){
				if(in_array($player->getName(), $this->edit)){
				}else{
					$this->edit[] = $player->getName();
					$player->sendMessage($room->plugin->getMessage($player, "edit.op"));
				}
				return;
			}
			$event->setCancelled();
			if(in_array($player->getName(), $this->edit)){
				
			}else{
				$this->edit[] = $player->getName();
				$player->sendMessage($room->plugin->getMessage($player, "edit.before.start"));
			}
		}
	}
	
	public function onBlockBreak($event){
		$room = &$this->room;
		$player = $event->getPlayer();
		$level = $player->getLevel();
		$name = $player->getName();
		$block = $event->getBlock();
		if($room->isStarted()){
			if(($team2 = $room->getTeam($name)) == null){
				$event->setCancelled();
				return;
			}
			if($block instanceof Chest){
				$event->setCancelled();
				return;
			}
			if($room->isSpectator($player)){
				$event->setCancelled();
				return;
			}
			$v3 = $block;
		    switch($block->getID()){
			    case 14://金礦
				$event->setDrops([]);
			    $event->setCancelled();
			    $level->setBlock($v3,new Air());
				$r2 = mt_rand(1,20);
				switch($r2){
					case 1:
					$newblock = new Item(6, 3, 1);  //樹苗
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 2:
					$newblock = new Item(30, 0, 2);  //蛛網
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
				
					case 3:
					$newblock = new Item(50, 0, 5);  //火把
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 4:
					$newblock = new Item(263, 0, 2);  //煤炭
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
				
					case 5:
					$newblock = new Item(260, 0, 2);  //蘋果
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 6:
					$newblock = new Item(303, 0, 1);  //鎖鏈甲
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 7:
					$newblock = new Item(302, 0, 1);  //鎖鏈頭
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 8:
					$newblock = new Item(304, 0, 1);  //鎖鏈褲
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 9:
					$newblock = new Item(305, 0, 1);  //鎖鏈靴
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 10:
					$newblock = new Item(319, 0, 2);  //豬肉
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 11:
					$newblock = new Item(334, 0, 5);  //皮革
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 12:
					$newblock = new Item(357, 0, 2);  //曲奇
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 13:
					$newblock = new Item(363, 0, 2);  //豬肉
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 14:
					$newblock = new Item(366, 0, 2);  //熟雞肉
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 15:
					$newblock = new Item(393, 0, 2);  //烤馬鈴薯
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;		

					case 16:
					$newblock = new Item(283, 0, 1);  //金劍
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;			

					case 17:
					$newblock = new Item(314, 0, 1);  //金頭盔
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;			

					case 18:
					$newblock = new Item(315, 0, 1);  //金盔甲
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;			

					case 19:
					$newblock = new Item(316, 0, 1);  //金褲甲
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;			

					case 20:
					$newblock = new Item(317, 0, 1);  //金靴子
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;					
				}
			break;
			

			case 15://鐵礦
			$event->setDrops([]);
			$event->setCancelled();
			$level->setBlock($v3,new Air());
				$r2 = mt_rand(1,14);
				switch($r2){
					case 1:
					$newblock = new Item(262, 0, 5);  //箭支
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 2:
					$newblock = new Item(264, 0, 2);  //鉆石
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
				
					case 3:
					$newblock = new Item(265, 0, 3);  //鐵錠
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 4:
					$newblock = new Item(266, 0, 3);  //金錠
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
				
					case 5:
					$newblock = new Item(280, 0, 4);  //木棍
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 6:
					$newblock = new Item(287, 0, 3);  //繩子
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 7:
					$newblock = new Item(288, 0, 4);  //羽毛
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 8:
					$newblock = new Item(306, 0, 1);  //鐵盔
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 9:
					$newblock = new Item(307, 0, 1);  //鐵甲
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 10:
					$newblock = new Item(308, 0, 1);  //鐵褲
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 11:
					$newblock = new Item(309, 0, 1);  //鐵靴
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 12:
					$newblock = new Item(318, 0, 1);  //燧石
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 13:
					$newblock = new Item(325, 0, 1);  //鐵桶
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 14:
					$newblock = new Item(259, 0, 1);  //打火石
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
				}
			break;
			
			
			
			case 16://煤礦
			$event->setDrops([]);
			$event->setCancelled();
			$level->setBlock($v3,new Air());
				$r2 = mt_rand(1,6);
				switch($r2){
					case 1:
					$newblock = new Item(262, 0, 3);  //箭支
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 2:
					$newblock = new Item(46, 0, 2);  //tnt
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
				
					case 3:
					$newblock = new Item(332, 0, 1);  //雪球
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 4:
					$newblock = new Item(318, 0, 1);  //燧石
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
				
					case 5:
					$newblock = new Item(288, 0, 3);  //羽毛
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 6:
					$newblock = new Item(287, 0, 2);  //繩子
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
			}
			break;
			
			
			
			case 21://青金石礦
			$event->setDrops([]);
			$event->setCancelled();
			$level->setBlock($v3,new Air());
			$r2 = mt_rand(1,15);
				switch($r2){
					case 1:
					$player->addEffect(Effect::getEffect(Effect::SPEED)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;
					
					case 2:
					$player->addEffect(Effect::getEffect(Effect::SLOWNESS)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;
				
					case 3:
					$player->addEffect(Effect::getEffect(Effect::HASTE)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;
					
					case 4:
					$player->addEffect(Effect::getEffect(Effect::SWIFTNESS)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;
				
					case 5:
					$player->addEffect(Effect::getEffect(Effect::FATIGUE)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;
					
					case 6:
					$player->addEffect(Effect::getEffect(Effect::MINING_FATIGUE)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;
					
					case 7:
					$player->addEffect(Effect::getEffect(Effect::STRENGTH)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;
					
					case 8:
					$player->addEffect(Effect::getEffect(Effect::JUMP)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;
					
					case 9:
					$player->addEffect(Effect::getEffect(Effect::NAUSEA)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;
					
					case 10:
					$player->addEffect(Effect::getEffect(Effect::CONFUSION)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;
					
					case 11:
					$player->addEffect(Effect::getEffect(Effect::REGENERATION)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;
					
					case 12:
					$player->addEffect(Effect::getEffect(Effect::DAMAGE_RESISTANCE)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;
					
					case 13:
					$player->addEffect(Effect::getEffect(Effect::FIRE_RESISTANCE)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;
					
					case 14:
					$player->addEffect(Effect::getEffect(Effect::WATER_BREATHING)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;
					
					case 15:
					$player->addEffect(Effect::getEffect(Effect::INVISIBILITY)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;	

					case 16:
					$player->addEffect(Effect::getEffect(Effect::WEAKNESS)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;	

					case 17:
					$player->addEffect(Effect::getEffect(Effect::POISON)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;	

					case 18:
					$player->addEffect(Effect::getEffect(Effect::WITHER)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;			

					case 19:
					$player->addEffect(Effect::getEffect(Effect::HEALTH_BOOST)->setVisible(true)->setAmplifier(0)->setDuration(20*15));
					break;						
				}
			break;
			
			
			
			case 56://鉆石礦
			$event->setDrops([]);
			$event->setCancelled();
			$level->setBlock($v3,new Air());
				$r2 = mt_rand(1,8);
				switch($r2){
					case 1:
					$newblock = new Item(264, 0, 2);  //
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 2:
					$newblock = new Item(276, 0, 1);  //
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
				
					case 3:
					$newblock = new Item(279, 0, 1);  //
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 4:
					$newblock = new Item(278, 0, 1);  //
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
				
					case 5:
					$newblock = new Item(310, 0, 1);  //
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 6:
					$newblock = new Item(311, 0, 1);  //
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 7:
					$newblock = new Item(312, 0, 1);  //
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;
					
					case 8:
					$newblock = new Item(313, 0, 1);  //
					$level->dropItem($v3,$newblock);
					unset($newblock);
					break;				
				}
			break;
			
			
			case 73:		
			case 74://紅石
			$event->setDrops([]);
			$event->setCancelled();
			$level->setBlock($v3,new Air());
			$par = new HeartParticle(new Vector3($block->getX() + mt_rand(-1,1),$block->getY() + mt_rand(-1,1),$block->getZ() + mt_rand(-1,1)), mt_rand(3,10));
			for($i=0;$i<=5;$i++){
			$level->addParticle($par);
			}
			$more = mt_rand(3,6);
			$player->setMaxHealth($player->getMaxHealth() + $more);
			$player->setHealth($player->getHealth() + $more);
			break;
			
			case 129://綠寶石
			break;
		}
		}else{
			if($player->isOp() and $room->plugin->config["禁止OP破壞遊戲地圖的方塊"] !== true){
				if(in_array($player->getName(), $this->edit)){
				}else{
					$this->edit[] = $player->getName();
					$player->sendMessage($room->plugin->getMessage($player, "edit.op"));
				}
				return;
			}
			$event->setCancelled();
			if(in_array($player->getName(), $this->edit)){
				
			}else{
				$this->edit[] = $player->getName();
				$player->sendMessage($room->plugin->getMessage($player, "edit.before.start"));
			}
		}
	}
	
	public function onTouch($player){
		
	}
	
	public function getName(){
		return "chapter.skywars";
	}
	
	public function getIntroduction(){
		return "chapter.skywars.introduction";
	}
	
	public function getChapterBlock(){
		return null;
	}
	
	public function getDeathMessage(){
		return "chapter.skywars.deathmessage";
	}	
	
	public function getBridgeBlock(){
		return null;
	}
	
}

?>