<?php
namespace MBattleBridge\chapters;

use MBattleBridge\Room;
use MBattleBridge\chapters\Dynamic;
use MBattleBridge\chapters\sahara;
use MBattleBridge\chapters\arctic;
use MBattleBridge\chapters\australia;
use MBattleBridge\chapters\venice;
use MBattleBridge\chapters\alaska;
use MBattleBridge\chapters\bedwars;
use MBattleBridge\chapters\skywars;
use MBattleBridge\chapters\moon;
abstract class Chapter{
	
	public static function getChapter(Room $room){
		$obj = $room->getChapterName();
		switch($obj){
			case "sahara":
			return new sahara($room);
			case "arctic":
			return new arctic($room);
			case "australia":
			return new australia($room);
			case "venice":
			return new venice($room);
			case "alaska":
			return new alaska($room);
			case "bedwars":
			return new bedwars($room);
			case "skywars":
			return new skywars($room);
			case "moon":
			return new moon($room);
		}
	}
	
	public function isDynamic(){
		return false;
	}
	
	abstract public function onTick($newtime);
	
 	abstract public function onTouch($player);
	
	abstract public function getName();
	
	abstract public function getChapterBlock();
	
	abstract public function getBridgeBlock();
	
	abstract public function getDeathMessage();
	
	abstract public function getIntroduction();
	
	public function onJoinPlayer($player){
		return "default";
	}
	
	public function onQuitPlayer($player){
		return "default";
	}	
	
	 public function onStart($force = false){
		return "default";
	}
	
	 public function onStop($force = false){
		return "default";
	}
	
	 public function onSpectate($player, $step = 1){
		return "default";
	}
	
	 public function onBlockPlace($event){
		return "default";
	}
	
	 public function onBlockBreak($event){
		return "default";
	}
	
	 public function onDeath($event){
		return "default";
	}
	
	 public function onItemHeld($event){
		return "default";
	}
	
	 public function onRespawn($event){
		return "default";
	}
	
	 public function onDamage($event){
		return "default";
	}
	
	public function isCustomTip(){
		return false;
	}
	
}

?>