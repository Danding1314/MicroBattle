<?php
namespace MBattleBridge\chapters;

use MBattleBridge\chapters\Chapter;
use MBattleBridge\chapters\Dynamic;
use MBattleBridge\MBattleBridge;
use MBattleBridge\Room;
use pocketmine\block\Block;
use pocketmine\entity\Effect;
use pocketmine\level\Level;
use pocketmine\level\weather\Weather;
use pocketmine\event\entity\EntityCombustByBlockEvent;
use pocketmine\event\entity\EntityDamageByBlockEvent;
use pocketmine\event\entity\EntityDamageEvent;
class venice extends Dynamic{
	
	public function __construct(Room $room){
		$this->hasChanged = false;
		$this->room = $room;
		$this->changetime = mt_rand(20, 300);
	}		
	
	public function onTick($newtime){
		$class = get_class($this->getChapterBlock());
		foreach($this->room->getPlayers() as $player){
			$block = $player->getLevel()->getBlock($player);
			if($block instanceof $class and !$this->room->isSpectator($player)){
				$this->onTouch($player);
			    break;
			}
		}
	}	
	
	public function onTouch($player){
		if(!$this->isChanged()){
			$ev = new EntityDamageEvent($player, EntityDamageEvent::CAUSE_MAGIC, 2);
			$player->attack($ev->getFinalDamage(), $ev);
		}else{
			$ev = new EntityDamageEvent($player, EntityDamageEvent::CAUSE_MAGIC, 6);
			$player->attack($ev->getFinalDamage(), $ev);
		}
	}	
	
	public function onChange(){
		$this->hasChanged = true;
		$this->room->getGameLevel()->getWeather()->setWeather(Weather::RAINY, 72000);
		foreach($this->room->getPlayers() as $player){
			$player->sendMessage($this->room->plugin->getMessage($player, "chapter.venice.change"));
			if(!$this->room->isSpectator($player)){
			$player->removeAllEffects();
			$player->addEffect(Effect::getEffect(4)->setDuration(2147483648)->setAmplifier(0)->setVisible(true));
			}
		}
	}
	
	public function getName(){
		return "chapter.venice";
	}
	
	public function getIntroduction(){
		return "chapter.venice.introduction";
	}	
	
	public function getChangeTime(){
		return $this->changetime;
	}
	
	public function isChanged(){
		return $this->hasChanged;
	}
	
	public function getChapterBlock(){
		return Block::get(8);
	}
	
	public function getBridgeBlock(){
		return array(Block::get(43,5),Block::get(43,0));
	}
	
	public function getDeathMessage(){
		return "chapter.venice.deathmessage";
	}	
	
}

?>