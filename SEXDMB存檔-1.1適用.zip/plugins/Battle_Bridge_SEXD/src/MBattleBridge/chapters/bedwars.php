<?php
namespace MBattleBridge\chapters;

use MBattleBridge\chapters\Chapter;
use MBattleBridge\chapters\Dynamic;
use MBattleBridge\MBattleBridge;
use MBattleBridge\Room;
use MBattleBridge\Language;
use MBattleBridge\EventListener;

use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\Player;

use pocketmine\block\Block;
use pocketmine\block\Chest;
use pocketmine\block\Air;

use pocketmine\level\Level;
use pocketmine\level\weather\Weather;
use pocketmine\level\Position;

use pocketmine\event\entity\EntityCombustByBlockEvent;
use pocketmine\event\entity\EntityDamageByBlockEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\level\particle\FloatingTextParticle;

use pocketmine\entity\Entity;
use pocketmine\entity\Effect;

use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\EnumTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;

class bedwars extends Chapter{
			
	public $level;
		
	public function __construct(Room $room){
		if(!$room->plugin->isPHP7()){
			$room->delete();
			return false;
		}
		$this->hasChanged = false;
		$this->room = $room;
		$this->array = [];
		$this->edit = [];
		$this->order = [];
		$this->tap = [];
		$this->use = [];
		$this->room->info["war-time"] = 5;
		$this->room->info["generate-time"] = 10;
		$this->level = $room->getGameLevel();
		foreach(MBattleBridge::$allteams as $team){
			$pos = $this->room->getGamePos($team);
			if($pos->y >= 128){
				$pos->y = 125;
			}
			if($pos->y <= 1){
				$pos->y = 2;
			}
			$this->array[$team] = [
			"床"=>new Position($pos->x,$pos->y-1,$pos->z,$pos->level),
			"銅"=>new Position($pos->x+3,$pos->y-1,$pos->z+2,$pos->level),
			"鐵"=>new Position($pos->x+3,$pos->y-1,$pos->z,$pos->level),
			"金"=>new Position($pos->x+3,$pos->y-1,$pos->z-2,$pos->level),
			"合成臺"=>new Position($pos->x,$pos->y+3,$pos->z,$pos->level),
			"life"=> 3,
			"particle"=> new FloatingTextParticle(new Position($pos->x,$pos->y+1,$pos->z,$pos->level),"",""),
			];
		}
		$this->setBeds();
	}
	
	public function onTick($newtime){
		if(!$this->room->isStarted() or !$this->room->isLoaded() or !$this->level instanceof Level){
		}else{
		if(($newtime % 3) == 0) {
			foreach(MBattleBridge::$allteams as $team){
				$loc = $this->array[$team]["銅"];
				$this->level->dropItem(new Vector3($loc->x,$loc->y + 0.5,$loc->z), Item::get(Item::BRICK, 0, 1));
			}
		}
						
		if(($newtime % 8) == 0) {
			foreach(MBattleBridge::$allteams as $team){
				$loc = $this->array[$team]["鐵"];
				$this->level->dropItem(new Vector3($loc->x,$loc->y + 0.5,$loc->z), Item::get(Item::IRON_INGOT, 0, 1));
			}
		}
						
		if(($newtime % 25) == 0){
			foreach(MBattleBridge::$allteams as $team){
				$loc = $this->array[$team]["金"];
				$this->level->dropItem(new Vector3($loc->x,$loc->y + 0.5,$loc->z), Item::get(Item::GOLD_INGOT, 0, 1));
			}
		}
		
		if(($newtime % 30) == 0){
			foreach(MBattleBridge::$allteams as $team){
				$this->sendBedLife($team);
			}
		}
	  }
	}
	
	public function setBeds(){
		foreach(MBattleBridge::$allteams as $team){
			$damage = 0;
			switch($team){
				case "red":
				$damage = 14;
				break;
				case "green":
				$damage = 5;
				break;
				case "blue":
				$damage = 11;
				break;
				case "yellow":
				$damage = 4;
				break;
			}
			$this->level->setBlock($this->array[$team]["床"], Block::get(35,$damage));
			$this->level->setBlock($this->array[$team]["銅"], Block::get(159,12));
			$this->level->setBlock($this->array[$team]["鐵"], Block::get(42));
			$this->level->setBlock($this->array[$team]["金"], Block::get(41));
			$this->level->setBlock($this->array[$team]["合成臺"], Block::get(58));
			$this->sendBedLife($team, false);
		}
	}
	
	public function getBedLife($team){
		if($team !== null){
			return $this->array[$team]["life"];
		}
	}
	
	public function setBedLife($team,$life){
		$this->array[$team]["life"] = $life;
		$this->sendBedLife($team,false);
	}
	
	public function updateBedLife($team, $life){
		$this->setBedLife($team,$this->getBedLife($team)+$life);
	}
	
	public function sendBedLife($team, $onlydelete = false){
		$this->array[$team]["particle"]->setTitle(Language::$message[$team]."§f隊§6核心");
		if($this->array[$team]["life"] <= 0){
			$this->array[$team]["particle"]->setText("§4|---§e已被破壞§4---|");
		}else{
			$str = "";
			for($i = 0;$i < $this->array[$team]["life"];$i++){
				$str .= "❤ ";
			}
			$this->array[$team]["particle"]->setText("§4".$str);			
		}
		$this->level->addParticle($this->array[$team]["particle"]);
	}

	public function onJoinPlayer($player){
		if($this->level == null){
			$this->level = $this->room->getGameLevel();
		}
		return true;
	}
	
	public function onStart($force = false){
		if($this->room->gamestart !== true){
			$this->room->gamestart = true;
		}
		foreach($this->room->getPlayers() as $player){
			$this->room->spawn($player);
		}
			$this->setBeds();
			foreach(MBattleBridge::$allteams as $team){
				$this->sendBedLife($team);
			}
			$this->room->plugin->getServer()->getScheduler()->scheduleDelayedTask(new \MBattleBridge\tasks\GameTickTask($this->room->plugin, $this->room, 0), 20);
			$this->room->wMessage("game.start");
			$this->room->wMessage($this->getIntroduction());
			$this->room->ifwin();
			$this->room->plugin->updateSigns();
	}
	
	public function onStop($force = false){
		$this->room->time = 0;
		$this->room->ready = false;
		$this->room->gamestart = false;
		$this->room->war = false;
		$this->room->generated = false;
		$this->room->duel = false;
		foreach ($this->room->getPlayers() as $player) {
			if ($player instanceof Player) {
				if($player->isOnline()){
					$this->room->quitPlayer($player);  
				}else{
					
				}
			}
		}
		$this->room->gamers = [];
		$this->room->gamers["all"] = [];
		$this->room->gamers["red"] = [];
		$this->room->gamers["blue"] = [];
		$this->room->gamers["green"] = [];
		$this->room->gamers["yellow"] = [];
		$this->room->spectators = [];
		$this->room->spectators["all"] = [];
		$this->room->spectators["red"] = [];
		$this->room->spectators["blue"] = [];
		$this->room->spectators["green"] = [];
		$this->room->spectators["yellow"] = [];
		$this->level = null;
		$this->room->rollback($force);
		$this->room->plugin->updateSigns();
		$this->room->prepareTick();
	}
	
	public function onSpectate($player, $step = 1){
		if(!$this->room->isSpectator($player)){
			switch($step){
			case 0:
			if(!$this->room->isIn($player))return;
			$team = $this->room->getTeam($player);
			if($team !== null){
				$this->room->wPopup("game.spectate", [$player->getName()], $team);
				return $this->room->getGamePos($team);
			}else{
				return $this->room->plugin->getSafePos($this->room->getCenterPos());
			}
			
			case 1:
			if(!$this->room->isIn($player))return;
			$this->room->spectators["all"][] = strtolower($player->getName());
			$player->gamemode = 4;
			$player->setGamemode(3);
			$this->room->plugin->hidePlayer($player);
			$this->room->wPopup("game.spectate", [$player->getName()]);
            $pk = $this->room->plugin->getPacketObj("ContainerSetContentPacket");
			if($pk != false){
				$pk->windowid = 0x79;
				$player->dataPacket($pk);				
			}
			$inventory = $player->getInventory();
			$inventory->clearAll();
            $inventory->setHeldItemIndex(1);
            $inventory->addItem(clone Item::get(318,0,1));
			$inventory->addItem(clone Item::get(403,0,1));
			$inventory->addItem(clone Item::get(288,0,1));
			$inventory->addItem(clone Item::get(347,0,1));
            $inventory->sendContents($player);
            $inventory->sendContents($player->getViewers());
			$team = $this->room->getTeam($player);
			foreach(MBattleBridge::$allteams as $team){
				$this->sendBedLife($team);
			}
			if($team !== null){
				$this->room->quitTeam($player);
				$this->room->spectators[$team][] = strtolower($player->getName());
				$this->room->ifwin();
				return $this->room->getGamePos($team);
			}else{
				return $this->room->plugin->getSafePos($this->room->getCenterPos());
			}
			
			case 2:
			$player->setRoom($this->room->plugin->getGameName(), $this->room->getID());
			$this->room->spectators["all"][] = strtolower($player->getName());
			$this->room->gamers["all"][] = strtolower($player->getName());
			$config = $this->room->plugin->getPlayerConfig($player);
			$config->set("Quit",1);
			$config->save();
			if($player->getGamemode() == 0){
				$this->room->plugin->saveInventory($player);
			}
			$player->gamemode = 4;
			$player->setGamemode(3);
			$this->room->plugin->hidePlayer($player);
			$this->room->wPopup("game.spectate", [$player->getName()]);
            $pk = $this->room->plugin->getPacketObj("ContainerSetContentPacket");
			if($pk != false){
				$pk->windowid = 0x79;
				$player->dataPacket($pk);				
			}
			$inventory = $player->getInventory();
			$inventory->clearAll();
            $inventory->setHeldItemIndex(1);
            $inventory->addItem(clone Item::get(318,0,1));
			$inventory->addItem(clone Item::get(403,0,1));
			$inventory->addItem(clone Item::get(288,0,1));
			$inventory->addItem(clone Item::get(347,0,1));
            $inventory->sendContents($player);
            $inventory->sendContents($player->getViewers());
			$player->teleport($this->room->plugin->getSafePos($this->room->getCenterPos()));
			foreach(MBattleBridge::$allteams as $team){
				$this->sendBedLife($team);
			}
			unset($inventory,$player);
			return true;
		}
		}else{
			return false;
		}
	}
	
	public function onBlockPlace($event){
		$room = &$this->room;
		$player = $event->getPlayer();
		$level = $player->getLevel();
		if($this->room->isStarted()){
			$block = $event->getBlock();
			if($block instanceof Chest){
				$event->setCancelled();
				return;
			}
			if($this->room->isSpectator($player)){
				$event->setCancelled();
				return;
			}
            if(!in_array($event->getBlock()->getId(),[24,54,30])){
                 $event->setCancelled();
            }
					//todo:more function
		}else{
			if($player->isOp() and $room->plugin->config["禁止OP破壞遊戲地圖的方塊"] !== true){
				if(in_array($player->getName(), $this->edit)){
				}else{
					$this->edit[] = $player->getName();
					$player->sendMessage($room->plugin->getMessage($player, "edit.op"));
				}
				return;
			}
			$event->setCancelled();
			if(in_array($player->getName(), $this->edit)){
				
			}else{
				$this->edit[] = $player->getName();
				$player->sendMessage($room->plugin->getMessage($player, "edit.before.start"));
			}
		}
	}
	
	public function onBlockBreak($event){
		$room = &$this->room;
		$player = $event->getPlayer();
		$name = $player->getName();
		$block = $event->getBlock();
		if($room->isStarted()){
			$block = $event->getBlock();
			if(($team2 = $room->getTeam($name)) == null){
				$event->setCancelled();
				return;
			}
			if($block instanceof Chest){
				$event->setCancelled();
				return;
			}
			if($room->isSpectator($player)){
				$event->setCancelled();
				return;
			}
				if(!in_array($event->getBlock()->getId(),[24,54,30])){
					if($event->getBlock()->getId() == 35){
						switch($event->getBlock()->getDamage()){
							case 14:
							$team = "red";
							break;
							
							case 11:
							$team = "blue";
							break;
							
							case 5:
							$team = "green";
							break;
							
							case 4:
							$team = "yellow";
							break;
							
							default:
							$team = null;
							return;
						}
						if($team == $team2){
							$player->sendMessage($room->plugin->getMessage($player,"chapter.bedwars.break.self"));
							$event->setCancelled();
							return true;
						}
						if($this->getBedLife($team) > 1){
							$this->updateBedLife($team, -1);
							$room->wMessage("chapter.bedwars.break.1",[$team,$team2,$name,$this->getBedLife($team)]);
							$event->setCancelled();
                                    foreach(MBattleBridge::$allteams as $team3){
										if($team3 !== $team){
											foreach($room->getPlayers($team3) as $p){
												if($p->distance($event->getBlock()) <= 10){
													$p->getInventory()->clearAll();
													$p->getInventory()->sendContents($p);
													$p->getInventory()->open($p);
													$p->sendMessage($room->plugin->getMessage($p,"chapter.bedwars.break.protect",[$team]));
													$p->teleport($room->getGamePos($team3));
												}
											}
										}
                                    }
						}else{
							$this->setBedLife($team, 0);
							$room->wMessage("chapter.bedwars.break.2",[$team,$team2,$name]);
		                    $event->setDrops([]);
                            $event->getBlock()->getLevel()->setBlock($event->getBlock(), new Air());
						}
						return;
					}
					$event->setCancelled();
					return;
				}
		}else{
			if($player->isOp() and $room->plugin->config["禁止OP破壞遊戲地圖的方塊"] !== true){
				if(in_array($player->getName(), $this->edit)){
				}else{
					$this->edit[] = $player->getName();
					$player->sendMessage($room->plugin->getMessage($player, "edit.op"));
				}
				return;
			}
			$event->setCancelled();
			if(in_array($player->getName(), $this->edit)){
				
			}else{
				$this->edit[] = $player->getName();
				$player->sendMessage($room->plugin->getMessage($player, "edit.before.start"));
			}
		}
	}
	
	public function onDeath($event){
		$player = $event->getEntity();
		$room = &$this->room;
		$config = $room->plugin->getPlayerConfig($player);
		$config->set("Death", $config->get("Death") + 1);
		$config->save();
		unset($config);		
		$cause = EventListener::getLastDamager($player);
		if($cause instanceof Player){
			$config = $room->plugin->getPlayerConfig($cause);
			$config->set("Kill", $config->get("Kill") + 1);
			$config->save();
			unset($config);
			$room->plugin->mgb->updateCoin($cause, $room->plugin->config["擊殺獲得金幣量"]);
			$cause->sendMessage($room->plugin->getMessage($player, "game.kill.getcoins", [$player->getName(), $room->plugin->config["擊殺獲得金幣量"]]));
			$room->wMessage("game.die.player", [$player->getName(), $cause->getName()]);
			$player->sendMessage($room->plugin->getMessage($player, "game.die.player",[$cause->getName()]));
			$event->setDeathMessage("");
		}elseif($cause == "magic"){
			$room->wMessage("game.die.magic", [$player->getName(), $room->plugin->getMessage(null, $this->getDeathMessage())]);
			$event->setDeathMessage("");
		}else{
			$room->wMessage("game.die.unknown", [$player->getName()]);
		}
		if($this->getBedLife($room->getTeam($player)) > 0 and !$room->isDuel()){
			$room->wMessage("chapter.bedwars.deathmessage.1",[$player->getName()]);
		}else{
			$room->wMessage("chapter.bedwars.deathmessage.2",[$player->getName()]);
		}
		$id = $player->getId();
		if(array_key_exists($id,$this->order)){
			$this->order[$id]=array();
		}				
		$room->ifwin();
		if(!$room->isStarted()){
			$event->setKeepInventory(false);
			$event->setDrops([]);
		}else{
			$event->setKeepInventory(false);
		}
	}
	
	public function onItemHeld($event){
		$room = &$this->room;
		$player = $event->getPlayer();
		$item = $player->getInventory()->getItemInHand();
			if(!$room->isSpectator($player)){
			switch($item->getID()){
				case 318:
				$nbt=new CompoundTag("", [
					"ench"=>new CompoundTag("ench",[]),
					"display"=> new CompoundTag("display", [
					"Name" => new StringTag("Name",$room->plugin->getMessage(null, "item.318"))
					])
				]);
				$player->getInventory()->setItemInHand($item->setNamedTag($nbt));
				return;
				
				case 352:
				$nbt=new CompoundTag("", [
					"ench"=>new CompoundTag("ench",[]),
					"display"=> new CompoundTag("display", [
					"Name" => new StringTag("Name",$room->plugin->getMessage(null, "item.352"))
					])
				]);
				$player->getInventory()->setItemInHand($item->setNamedTag($nbt));
				return;
				
				case 403:
				$nbt=new CompoundTag("", [
					"ench"=>new CompoundTag("ench",[]),
					"display"=> new CompoundTag("display", [
					"Name" => new StringTag("Name",$room->plugin->getMessage(null, "item.403"))
					])
				]);
				$player->getInventory()->setItemInHand($item->setNamedTag($nbt));
				return;

				case 288:
				$nbt=new CompoundTag("", [
					"ench"=>new CompoundTag("ench",[]),
					"display"=> new CompoundTag("display", [
					"Name" => new StringTag("Name",$room->plugin->getMessage(null, "item.288"))
					])
				]);
				$player->getInventory()->setItemInHand($item->setNamedTag($nbt));
				return;
				
				case 289:
				$nbt=new CompoundTag("", [
					"ench"=>new CompoundTag("ench",[]),
					"display"=> new CompoundTag("display", [
					"Name" => new StringTag("Name",$room->plugin->getMessage(null, "item.289"))
					])
				]);
				$player->getInventory()->setItemInHand($item->setNamedTag($nbt));
				return;
				
				case 280:
				$nbt=new CompoundTag("", [
					"ench"=>new CompoundTag("ench",[]),
					"display"=> new CompoundTag("display", [
					"Name" => new StringTag("Name",$room->plugin->getMessage(null, "item.280"))
					])
				]);
				$player->getInventory()->setItemInHand($item->setNamedTag($nbt));
				return;

				case 369:
				$nbt=new CompoundTag("", [
					"ench"=>new CompoundTag("ench",[]),
					"display"=> new CompoundTag("display", [
					"Name" => new StringTag("Name",$room->plugin->getMessage(null, "item.369"))
					])
				]);
				$player->getInventory()->setItemInHand($item->setNamedTag($nbt));
				return;
				
				case 305:
				$nbt=new CompoundTag("", [
					"ench"=>new CompoundTag("ench",[]),
					"display"=> new CompoundTag("display", [
					"Name" => new StringTag("Name",$room->plugin->getMessage(null, "item.305"))
					])
				]);
				$player->getInventory()->setItemInHand($item->setNamedTag($nbt));
				return;
			}
			}else{
			switch($item->getID()){
				case 318:
				$player->sendPopup($room->plugin->getMessage(null, "item.318"));
				return;
				
				case 352:
				$player->sendPopup($room->plugin->getMessage(null, "item.352"));
				return;
				
				case 403:
				$player->sendPopup($room->plugin->getMessage(null, "item.403"));
				return;

				case 288:
				$player->sendPopup($room->plugin->getMessage(null, "item.288"));
				return;
				
				case 289:
				$player->sendPopup($room->plugin->getMessage(null, "item.289"));
				return;
				
				case 280:
				$player->sendPopup($room->plugin->getMessage(null, "item.280"));
				return;

				case 369:
				$player->sendPopup($room->plugin->getMessage(null, "item.369"));
				return;

				case 305:
				$player->sendPopup($room->plugin->getMessage(null, "item.305"));
				return;				
			}
			}
	}
	
	public function onRespawn($event){
		$room = &$this->room;
		$player = $event->getPlayer();
		if($this->getBedLife($room->getTeam($player)) <= 0 or $room->isDuel()){
			$room->spectate($player, 0);
			$player->sendMessage($room->plugin->getMessage($player, "game.spectate.ready"));
			$room->plugin->getServer()->getScheduler()->scheduleDelayedTask(new \MBattleBridge\tasks\RespawnTask($room->plugin, $player, $this->room, "spectate"), 1200/$room->plugin->getServer()->getTicksPerSecondAverage()+0.5);
		}else{
			$player->sendMessage($room->plugin->getMessage($player, "game.respawn.ready"));
			$room->plugin->getServer()->getScheduler()->scheduleDelayedTask(new \MBattleBridge\tasks\RespawnTask($room->plugin, $player, $this->room, "respawn"), 1200/$room->plugin->getServer()->getTicksPerSecondAverage()+0.5);
		}
	}
	
	public function onDamage($event){
		$room = &$this->room;
		$player = $event->getEntity();
		if($event instanceof EntityDamageByEntityEvent){
			$damager = $event->getDamager();
			if($player instanceof Player and $damager instanceof Player){
				$name = $player->getName();
				if($room->isSpectator($damager)){
					$event->setCancelled();
					return false;
				}
				if($room->getTeam($damager) == $room->getTeam($player)){
					if($room->isTeammateDamage()){
							
					}else{
						$event->setCancelled();
						return;
					}
				}
				switch($damager->getInventory()->getItemInHand()->getId()){
					case 369:
					if($player->getInventory()->getBoots()->getId() == 305){
						mt_rand(1,4) == 1 ? $event->setKnockBack(0) : $event->setKnockBack(2);
					}else{
						$event->setKnockBack(2);
					}
					break;
					case 280:
					if($player->getInventory()->getBoots()->getId() == 305){
						mt_rand(1,4) == 1 ? $event->setKnockBack(0) : $event->setKnockBack(1);
					}else{
						$event->setKnockBack(1);
					}
					break;
				}
			}
		}
	}
	
	public function onTouch($player){
		
	}
	
	public function getName(){
		return "chapter.bedwars";
	}
	
	public function getIntroduction(){
		return "chapter.bedwars.introduction";
	}
	
	public function getChapterBlock(){
		return null;
	}
	
	public function getDeathMessage(){
		return "chapter.bedwars.deathmessage";
	}	
	
	public function getBridgeBlock(){
		return null;
	}
	
}

?>