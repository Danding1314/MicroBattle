<?php
namespace MBattleBridge\chapters;

use MBattleBridge\chapters\Chapter;
use MBattleBridge\MBattleBridge;
use MBattleBridge\Room;
use pocketmine\block\Block;
use pocketmine\entity\Effect;
use pocketmine\level\Level;
use pocketmine\level\weather\Weather;
use pocketmine\event\entity\EntityCombustByBlockEvent;
use pocketmine\event\entity\EntityDamageByBlockEvent;
use pocketmine\event\entity\EntityDamageEvent;
class arctic extends Chapter{
	
	public function __construct(Room $room){
		$this->hasChanged = false;
		$this->room = $room;
	}
	
	public function onTick($newtime){
		$class = get_class($this->getChapterBlock());
		foreach($this->room->getPlayers() as $player){
			$block = $player->getLevel()->getBlock($player);
			if($block instanceof $class and !$this->room->isSpectator($player)){
				$this->onTouch($player);
			    break;
			}
		}
	}	
	
	public function onTouch($player){
		$ev = new EntityDamageEvent($player, EntityDamageEvent::CAUSE_MAGIC, 10);
		$player->attack($ev->getFinalDamage(), $ev);
		if(mt_rand(1,100) < 5){
			$player->getLevel()->setBlock(new \pocketmine\level\Position($player->x,$player->y,$player->z), new \pocketmine\block\Ice());
			$player->getLevel()->setBlock(new \pocketmine\level\Position($player->x+mt_rand(-1,1),$player->y,$player->z+mt_rand(-1,1)), new \pocketmine\block\Ice());
			$player->getLevel()->setBlock(new \pocketmine\level\Position($player->x+mt_rand(-1,1),$player->y,$player->z+mt_rand(-1,1)), new \pocketmine\block\Ice());
			$player->getLevel()->setBlock(new \pocketmine\level\Position($player->x+mt_rand(-1,1),$player->y,$player->z+mt_rand(-1,1)), new \pocketmine\block\Ice());
			$player->sendMessage($this->room->plugin->getMessage($player, "chapter.arctic.touch"));
		}
	}
	
	public function getName(){
		return "chapter.arctic";
	}
	
	public function getIntroduction(){
		return "chapter.arctic.introduction";
	}
	
	public function getChapterBlock(){
		return Block::get(8);
	}
	
	public function getBridgeBlock(){
		return Block::get(79);
	}
	
	public function getDeathMessage(){
		return "chapter.arctic.deathmessage";
	}		
}

?>