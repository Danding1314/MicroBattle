<?php
namespace MBattleBridge\chapters;

use MBattleBridge\chapters\Chapter;

abstract class Dynamic extends Chapter{
	
	public function isDynamic(){
		return true;
	}
	
	abstract public function onChange();
			
	abstract public function getChangeTime();
	
	abstract public function isChanged();
		
}
?>