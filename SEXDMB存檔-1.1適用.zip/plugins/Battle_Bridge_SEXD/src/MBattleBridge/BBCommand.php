<?php

namespace MBattleBridge;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;
use pocketmine\Player;
use pocketmine\Server;
use MBattleBridge\MBattleBridge;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\Item;
class BBCommand extends Command{
	
	private $plugin;

	public function __construct(MBattleBridge $plugin){
		parent::__construct("bb", "description", "usage");

		$this->setPermission("MBattleBridge.command.bb");

		$this->plugin = $plugin;
	}

	public function execute(CommandSender $sender, $label, array $args){
		$this->plugin->runCommand($sender,$this,$label,$args);
	}

}
?>