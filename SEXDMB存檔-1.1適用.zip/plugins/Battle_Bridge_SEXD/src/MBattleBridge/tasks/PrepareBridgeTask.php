<?php

namespace MBattleBridge\tasks;

use pocketmine\scheduler\AsyncTask;
use MBattleBridge\tasks\GenerateBridgeTask;
use MBattleBridge\MBattleBridge;
use pocketmine\Server;
class PrepareBridgeTask extends AsyncTask{
	public function __construct($roomid, $cx, $cy, $cz, $x1, $y1, $z1){
		$this->roomid = $roomid;
		$this->cx = $cx;
		$this->cy = $cy;
		$this->cz = $cz;
		$this->x1 = $x1;
		$this->y1 = $y1;
		$this->z1 = $z1;
	}

	public function onRun(){
		$cx = $this->cx;
		$cy = $this->cy;
		$cz = $this->cz;
		$x1 = $this->x1;
		$y1 = $this->y1;
		$z1 = $this->z1;
		$out = [];
		$l = max(abs($x1 - $cx), abs($y1 - $cy), abs($z1 - $cz));
        for ($m = 0; $m <= $l; $m++) {
            if ($cx - $x1 != 0 || $cy - $y1 != 0 || $cz - $z1 != 0) {
				$newx = round($x1 + $m / $l * ($cx - $x1));
				$newy = round($y1 + $m / $l * ($cy - $y1));
				$newz = round($z1 + $m / $l * ($cz - $z1));
				$out[] = ["x"=> $newx, "y"=> $newy, "z"=> $newz];
				for($i=0;$i<=8;$i++){
					$out[] = ["x"=> $newx + mt_rand(-2,2), "y"=> $newy, "z"=> $newz + mt_rand(-2,2)];
			    }
            }
        }
		$out = array_unique($out, SORT_REGULAR);
		$array = [];
		foreach($out as $pos){
			$array[] = $pos;
		}
		$this->setResult($array);
	}
	
    public function onCompletion(Server $server){
		$result = $this->getResult();
		for($times = count($result); $times > 0;$times--){
			$server->getScheduler()->scheduleDelayedTask(new GenerateBridgeTask(MBattleBridge::getInstance(), MBattleBridge::getInstance()->getRoom($this->roomid), $result[$times-1]), 7*$times);
		}
    }
	
}