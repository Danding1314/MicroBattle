<?php
namespace MBattleBridge\tasks;

use pocketmine\scheduler\PluginTask;
use pocketmine\utils\TextFormat;
use MBattleBridge\MBattleBridge;
use MBattleBridge\Room;
use pocketmine\level\Level;
class RBTask extends PluginTask{

    private $plugin;
   
    public function __construct(MBattleBridge $plugin, Room $room){
        parent::__construct($plugin);
        $this->plugin = $plugin;
        $this->room = $room;
    }

	public function onRun($currentTick) {
		$this->room->loaded = false;
		$level = $this->room->getGameLevel();
			if(!$level instanceof Level){
				$this->plugin->getLogger()->info(MBattleBridge::FORMAT."无法卸载游戏地图,原因是地图未加载,地图重置失败!");
				return false;
			}
		$name = $level->getFolderName();
		$default = $this->plugin->getServer()->getDefaultLevel()->getFolderName();
		if($name == $default){
            $this->plugin->getLogger()->info(MBattleBridge::FORMAT."无法卸载服务器默认地图,地图重置失败!");
            return false;
		}
        $ok1 = $this->plugin->getServer()->unloadLevel($level);
        if ($ok1 !== true) {
            $this->plugin->getLogger()->info(MBattleBridge::FORMAT."恢复地图时，卸载地图失败");
            return false;
        }
        $p0 = $default;
        $p1 = dirname($p0);
        $path =  $p1. "/plugins/MGameBase/games/".$this->plugin->getGameName()."/worlds/";
        $path0 = $p1. "/worlds/";
        $this->plugin->getLogger()->info("备份的地图目录：".TextFormat::BLUE.$path);
        $files = scandir($path);
        foreach($files as $f) {
            if ($f !== "." && $f !== ".." && is_dir($path.$f)) {
                if($f === $name) {
                    if($this->plugin->getServer()->isLevelLoaded($f) === false){
                        $this->recurse_copy($path . '/' . $f,$path0 . '/' . $f);
                        $ok2 = true;
                        if ($ok2 !== true) {
                            $this->plugin->getLogger()->info(MBattleBridge::FORMAT."恢复地图时，创建地图失败");
                            return false;
                        }
                        else {
                            $ok3 = $this->plugin->getServer()->LoadLevel($name);
                            if ($ok3 !== true) {
                                $this->plugin->getLogger()->info(MBattleBridge::FORMAT."恢复地图时，装载地图失败");
                                return false;
                            }
                            else {
                                $this->plugin->getLogger()->info(MBattleBridge::FORMAT."房间 ".$this->room->getID()." 地图已成功恢复");
                                $this->plugin->getLogger()->info(MBattleBridge::FORMAT."已重新获取世界对象：".$name);
                                $this->room->loaded = true;
                            }
                        }
                    }
                }
            }
        }
    }

    public function recurse_copy($src,$dst) {
        $dir = opendir($src);
        @mkdir($dst);
        while(false !== ( $file = readdir($dir)) ) {
            if (( $file != '.' ) && ( $file != '..' )) {
                if ( is_dir($src . '/' . $file) ) {
                    $this->recurse_copy($src . '/' . $file,$dst . '/' . $file);
                }
                else {
                    copy($src . '/' . $file,$dst . '/' . $file);
                }
            }
        }
        closedir($dir);
    }
}
?>