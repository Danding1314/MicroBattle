<?php

namespace MBattleBridge\tasks;

use pocketmine\scheduler\PluginTask;
use MBattleBridge\Room;
use MBattleBridge\MBattleBridge;
use pocketmine\level\Position;

class GenerateBridgeTask extends PluginTask{
	public function __construct(MBattleBridge $plugin, Room $room, $array){
		parent::__construct($plugin);
		$this->room = $room;
		$this->array = $array;
	}

	public function onRun($currentTick){
		if(!$this->room->isStarted()){
			return;
		}
		$array = $this->array;
		$block = $this->room->chapter->getBridgeBlock();
		if($block == null){
			return;
		}
		$pos = new Position($array["x"], $array["y"], $array["z"]);
		if(is_array($block)){
			$block = $block[mt_rand(0,count($block)-1)];
		}
		$this->room->getGameLevel()->setBlock($pos, $block);
	}
}