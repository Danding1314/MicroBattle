<?php

namespace MBattleBridge\tasks;

use pocketmine\scheduler\PluginTask;
use MBattleBridge\Room;
use MBattleBridge\MBattleBridge;
class ReadyTickTask extends PluginTask{
	public function __construct(MBattleBridge $plugin,Room $room, $time){
		parent::__construct($plugin);
		$this->room = $room;
		$this->time = $time;
	}

	public function onRun($currentTick){
		$this->room->tick("ready", $this->time);
	}
}