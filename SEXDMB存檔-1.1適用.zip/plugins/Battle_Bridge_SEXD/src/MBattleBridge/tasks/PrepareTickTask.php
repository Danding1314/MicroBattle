<?php

namespace MBattleBridge\tasks;

use pocketmine\scheduler\PluginTask;
use MBattleBridge\Room;
use MBattleBridge\MBattleBridge;
class PrepareTickTask extends PluginTask{
	public function __construct(MBattleBridge $plugin,Room $room){
		parent::__construct($plugin);
		$this->room = $room;
	}

	public function onRun($currentTick){
		$this->room->tick("prepare");
	}
}