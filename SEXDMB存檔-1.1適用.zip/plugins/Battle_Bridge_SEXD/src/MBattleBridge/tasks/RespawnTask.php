<?php

namespace MBattleBridge\tasks;

use pocketmine\scheduler\PluginTask;
use pocketmine\level\Position;
use MBattleBridge\Room;
use MBattleBridge\MBattleBridge;
class RespawnTask extends PluginTask{
	public function __construct(MBattleBridge $plugin, $player, $room, $type = "spectate"){
		parent::__construct($plugin);
		$this->plugin = $plugin;
		$this->room = $room;
		$this->player = $player;
		$this->type = $type;
	}

	public function onRun($currentTick){
		if($this->player instanceof \pocketmine\Player){
			switch($this->type){
				case "spectate":
				    $pos = $this->room->spectate($this->player, 1);
					if($pos instanceof Position){
						$this->player->teleport($pos);
					}
					$this->player->level->loadChunk($this->player->getX() >> 4,$this->player->getZ() >> 4);
					$this->player->sendMessage($this->plugin->getMessage($this->player, "game.spectate.self"));
				return;
				
				case "respawn":
				    $pos = $this->room->respawn($this->player);
					if($pos instanceof Position){
						$this->player->teleport($pos);
					}
					$this->player->level->loadChunk($this->player->getX() >> 4,$this->player->getZ() >> 4);
					$this->player->sendMessage($this->plugin->getMessage($this->player, "game.respawn.self"));
				return;
			}
		}
	}
}