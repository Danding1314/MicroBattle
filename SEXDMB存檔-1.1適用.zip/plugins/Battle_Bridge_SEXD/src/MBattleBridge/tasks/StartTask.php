<?php

namespace MBattleBridge\tasks;

use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\scheduler\PluginTask;
use MBattleBridge\Room;
use MBattleBridge\MBattleBridge;

class StartTask extends PluginTask{
	
	public function __construct(MBattleBridge $plugin,Room $room){
		parent::__construct($plugin);
		$this->plugin = $plugin;
		$this->room = $room;
		$this->time = 100;
		if(!$room->isStarted()){
			Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
			return true;
		}
		$effect = \pocketmine\entity\Effect::getEffect(\pocketmine\entity\Effect::SLOWNESS);
		$effect->setAmplifier(10);
		$effect->setDuration(20 * 10000);
        $effect->setVisible(false);
		foreach(MBattleBridge::$allteams as $team){
			foreach($this->room->getPlayers($team) as $player){
				$player->addEffect($effect);
			}
		}
		$this->str = "\n§l§bCool Down §r§6Ticks§7:\n§a";
	}
	
	public function onRun($currentTick){
		if($this->time <= 0){
			foreach(MBattleBridge::$allteams as $team){
				foreach($this->room->getPlayers($team) as $player){
					$player->removeAllEffects();
					//$player->setMovementSpeed(0.10);
				}
			}
			Server::getInstance()->getScheduler()->cancelTask($this->getTaskId());
			return true;
		}
		$str2 = "||||||||||||||||||||||||||||||||||||||||";
		$p = intval($this->time / 2.5);
		$str2{$p} = "";
		foreach(MBattleBridge::$allteams as $team){
			foreach($this->room->getPlayers($team) as $player){
				$player->sendPopup($this->str.$str2.MBattleBridge::getGameAbbreviation());
			}
		}
		--$this->time;
	}

}