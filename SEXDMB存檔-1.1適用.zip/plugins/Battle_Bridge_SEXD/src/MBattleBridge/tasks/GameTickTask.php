<?php

namespace MBattleBridge\tasks;

use pocketmine\scheduler\PluginTask;
use pocketmine\level\Position;
use MBattleBridge\Room;
use MBattleBridge\MBattleBridge;
class GameTickTask extends PluginTask{
	public function __construct(MBattleBridge $plugin,Room $room, $time){
		parent::__construct($plugin);
		$this->room = $room;
		$this->time = $time;
	}

	public function onRun($currentTick){
		$this->room->tick("game", $this->time);
		$this->room->getChapter()->onTick($this->time);
	}
}