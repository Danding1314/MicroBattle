<?php

namespace MBattleBridge\tasks;

use pocketmine\scheduler\PluginTask;
use MBattleBridge\tasks\GenerateMineTask;
use MBattleBridge\MBattleBridge;
use pocketmine\Server;
class PrepareMineTask extends PluginTask{
	public function __construct(MBattleBridge $plugin,$roomid, $x, $y,$z){
		parent::__construct($plugin);
		$this->plugin = $plugin;
		$this->roomid = $roomid;
		$this->x = $x;
		$this->y = $y;
		$this->z = $z;
	}

	public function onRun($currentTick){
		$x = $this->x;
		$py = $this->y;
		$z = $this->z;
		$out = [];
		if($py - 40 <= 0){
			$my = 0;
		}else{
			$my = $py - 40;
		}
		$py = $py + 5;
		if($py > 128){
			$py = 128;
		}		
		for($y=$my;$y<=$py;$y++){
		for($a = -25;$a <= 25;$a++){
		for($b = -25;$b <= 25;$b++){
			if(mt_rand(1,20)==1){
				$out[] = [$x+$a,$y,$z+$b];
			}
			
		}
		}
		}
		
		$this->plugin->getServer()->getScheduler()->scheduleDelayedTask(new GenerateMineTask(MBattleBridge::getInstance(), $this->plugin->getRoom($this->roomid), $out), 20);
	}
	
	
}