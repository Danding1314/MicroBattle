<?php

namespace MBattleBridge\tasks;

use pocketmine\scheduler\PluginTask;
use MBattleBridge\Room;
use MBattleBridge\MBattleBridge;
use pocketmine\level\Position;
use pocketmine\block\Block;
class GenerateMineTask extends PluginTask{
	public function __construct(MBattleBridge $plugin, Room $room, $array){
		parent::__construct($plugin);
		$this->room = $room;
		$this->array = $array;
	}

	public function onRun($currentTick){
		$array = $this->array;
		$mine = array(14,15,16,21,56,73,74,129);
		$count = count($mine);
		$level = $this->room->getGameLevel();
		foreach($array as $p){
		$pos = new Position($p[0], $p[1], $p[2]);
			if(in_array($level->getBlock($pos)->getID(),[1,3])){
				$block = $mine[mt_rand(0,$count-1)];
				$level->setBlock($pos, Block::get($block));
			}
		}
	}
}