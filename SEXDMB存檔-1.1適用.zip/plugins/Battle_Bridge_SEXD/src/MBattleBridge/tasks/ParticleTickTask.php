<?php

namespace MBattleBridge\tasks;

use pocketmine\math\Vector3;
use pocketmine\scheduler\PluginTask;
use pocketmine\level\Level;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\level\particle\Particle;
use pocketmine\level\particle\CriticalParticle;
use pocketmine\level\particle\HeartParticle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\particle\RedstoneParticle;
use pocketmine\level\particle\SmokeParticle;
use pocketmine\level\particle\WaterParticle;
use MBattleBridge\Room;
use MBattleBridge\MBattleBridge;
class ParticleTickTask extends PluginTask{
	public function __construct(MBattleBridge $plugin,Room $room){
		parent::__construct($plugin);
		$this->plugin = $plugin;
		$this->room = $room;
		$pos = $this->room->getWaitPos();
		$this->info = ['R'=>1.8,'X'=>$pos->x,'Y'=>$pos->y + 3,'Z'=>$pos->z,'Level'=>$pos->level];
		$this->type = 1;
		$this->color = [0,0,0];
		$this->c = [];
		$this->c[0] = [194,244,250];
		$this->c[1] = [12,117,129];
		$this->c[2] = [254,143,182];
		$this->c[3] = [183,2,66];
		$this->c[4] = [166,243,154];
		$this->c[5] = [32,138,17];
		$this->c[6] = [217,152,228];
		$this->c[7] = [136,38,153];
		$this->r = 0;
		$this->h = ['h'=>0,'s'=>0];
	}
	
public function onRun($currentTick){
	$this->round2($this->info);
	$this->onTick();
}

public function round2($info){
  $r=$info['R'];
  $level=$info['Level'];
  if($this->r<=90){
   $ro=$this->r;
   $x=$r*cos($ro*pi()/180);
   $z=$r*sin($ro*pi()/180);
   $v3a=new Vector3($info['X']+$x,$info['Y']-2+$this->h['h'],$info['Z']+$z);
   $v3b=new Vector3($info['X']-$x,$info['Y']-2+$this->h['h'],$info['Z']-$z);
  }elseif($this->r<=180){
   $ro=$this->r-90;
   $x=$r*cos($ro*pi()/180);
   $z=$r*sin($ro*pi()/180);
   $v3a=new Vector3($info['X']-$z,$info['Y']-2+$this->h['h'],$info['Z']+$x);
   $v3b=new Vector3($info['X']+$z,$info['Y']-2+$this->h['h'],$info['Z']-$x);
  }
  $color = $this->getColor();
  if($level instanceof Level){
  $level->addParticle(new DustParticle($v3a, $color[0], $color[1], $color[2]));
  $level->addParticle(new DustParticle($v3b, $color[0], $color[1], $color[2]));
  }
  $this->random($info);
  unset($info,$level,$v3a,$v3b,$i,$r,$ro,$x,$z);
 }
 
 public function onTick(){
  if($this->r==180){
   $this->r=0;
  }
  $this->r+=3;
  switch($this->h['s']){
   case 0:
    if($this->h['h']<=3){
     $this->h['h']+=0.1;
    }else{
     $this->h['h']+=0.05;
    }
    if($this->h['h']>=4){
     $this->h['s']=1;
    }
   break;
   case 1:
    if($this->h['h']>=1){
     $this->h['h']-=0.1;
    }else{
     $this->h['h']-=0.05;
    }
    if($this->h['h']<=0){
     $this->h['s']=2;
    }
   break;
   case 2:
    if($this->h['h']<=1.5){
     $this->h['h']+=0.1;
    }else{
     $this->h['h']+=0.05;
    }
    if($this->h['h']>=2){
     $this->h['s']=3;
    }
   break;
   case 3:
    if($this->h['h']>=1){
     $this->h['h']-=0.1;
    }else{
     $this->h['h']-=0.05;
    }
    if($this->h['h']<=0){
     $this->h['s']=0;
    }
   break;
  }
 }

 public function random($info){
  $r=$info['R'];
  $level=$info['Level'];
  $x=mt_rand(-10*$r,10*$r)/10;
  $z=mt_rand(-10*$r,10*$r)/10;
  $v3a=new Vector3($info['X']+$x,$info['Y'],$info['Z']+$z);
  $v3b=new Vector3($info['X']-$x,$info['Y'],$info['Z']-$z);
  if($level instanceof Level){
  $level->addParticle(new DustParticle($v3a, 255, 255, 250));
  $level->addParticle(new DustParticle($v3b, 255, 255, 250));
  }
  unset($id,$level,$v3a,$v3b,$r,$x,$z);
 }
 
 public function getColor(){
	 if($this->type >= 0 and $this->type <= 20){
		 $this->type += 1;
		 return [255, 0, 0];
	 }elseif($this->type <= 40){
		 $this->type += 1;
		 return [255, 165, 0];
	 }elseif($this->type <= 60){
		 $this->type += 1;
		 return [255, 255, 0];
	 }elseif($this->type <= 80){
		 $this->type += 1;
		 return [0, 255, 0];
	 }elseif($this->type <= 100){
		 $this->type += 1;
		 return [0, 127, 255];
	 }elseif($this->type <= 120){
		 $this->type += 1;
		 return [0, 0, 255];
	 }elseif($this->type <= 140){
		 $this->type += 1;
		 return [139, 0, 255];
	 }else{
		 $this->type = 0;
		 return $this->getColor();
	 }
 }
}
?>