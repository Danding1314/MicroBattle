<?php
namespace MBattleBridge;
class Language{
	public static $message = [
	"welcome" => "§3本服正在使用§2[戰橋]§3迷你小遊戲插件,歡迎嘗試!!!",
	"start.force" => "§e已強制開始§2[%0]§e號房間的戰橋遊戲",
	"stop.force" => "§e已強制結束§2[%0]§e號房間的戰橋遊戲",	
	"tap.again" => "§a再次點擊確認你的行動",
	"use.again" => "§a再次使用確認你的行動",
	"teleport.togame" => "§c無法在使用除加入遊戲外的方式進入戰橋地圖!",
	"teleport.leavegame" => "§c無法在遊戲途中傳送世界!",
	"no.player" => "§1不存在名為§d[%0]§1玩家!",
    "checkrate" => 	"§7行動頻率過快!請稍後再試",
	"remove.sign" => "§3成功移除戰橋遊戲的木牌",
	"help.quit" => "§3輸入/bb quit可離開遊戲",
	"red" => "§c紅§f",
	"blue" => "§b藍§f",
	"yellow" => "§e黃§f",
	"green" => "§a綠§f",
	"red.color" => "§c",
	"blue.color" => "§b",
	"yellow.color" => "§e",
	"green.color" => "§a",
	"random" => "§6隨機§f",
	"quit" => "§f退出",
	"prepare" => "預備",
	"ready" => "準備",
	"start" => "搜集",
	"war" => "戰鬥",
	"duel" => "決鬥",
	"win" => "遊戲勝利",
	"lose" => "遊戲失敗",
	"generated" => "戰橋生成",
	"chapter" => "篇目",
	"dynamic" => "動態",
	
	"no.permission" => "§c沒有權限使用此命令!",
	"command.ingame" => "§c無法在遊戲中使用戰橋以外的指令!輸入§f[§e/bb quit§f]§c可離開遊戲",
	"command.not.player" => "§c此指令只能由玩家使用!",
	"command.bag.gamemode" => "§3你需要變為生存模式才可以取回物品",
	"command.bag.ingame" => "§3無法在遊戲內取回物品",
	"command.bag.ok" => "§b成功取回遊戲前的背包物品",
	"command.ranking" => "§b排行榜坐標設置成功,退出遊戲重新進入可顯示!",
	"command.room.set.success1" => "§a設置成功!§7已將房間§d[%0]§7中的§3[%1]§7設置為§b[%2]",
	"command.room.set.success2" => "§a設置成功!§7已將房間§d[%0]§7中的§3[%1§f隊§3]§7的§3[%2]§7設置為§b[%3]",
	"command.room.set.fail.room" => "§c設置失敗!§7不存在房間§d[%0]",
	"command.room.set.fail.type" => "§c設置失敗!§7你嘗試將房間§d[%0]§7中的§3[%1]§7設置為§3[%2]§7,而標準的參數數據類型為§c[%3]",
	"command.room.set.fail.key" => "§c設置失敗!§7不存在房間§d[%0]§7中的§3[%1]§7條目",
	"command.room.set.banner+" => "§a設置成功!§7已將房間§d[%0]§7封禁玩家§c[%1]",
	"command.room.set.banner-" => "§a設置成功!§7已將房間§d[%0]§7解除封禁玩家§a[%1]",
	"command.particle.close" => "§a設置成功!§7已§c關閉§7粒子,重新開啟服務器後起效",
	"command.particle.open" => "§a設置成功!§7已§a開啟§7粒子,重新開啟服務器後起效",
	
	"item.318" => "§6§o退出遊戲",
	"item.352" => "§b§o點擊顏色方塊選擇隊伍",
	"item.403" => "§5§o查看我的戰橋信息",
	"item.288" => "§e§o查看房間玩家列表",
	"item.289" => "§6§o[長按快速回床]",
	"item.280" => "§6§o[§f普通§6擊退棒]",
	"item.369" => "§6§o[§5超級§6擊退棒]",
	"item.305" => "§6§o[§b防擊退§6鞋]",
	
	"chapter.alaska" => "《阿拉斯加篇》",
	"chapter.alaska.welcome" => "本房間的遊戲篇章:《阿拉斯加篇》",
	"chapter.alaska.change" => "轟隆隆......大家所在的區域發生了雪崩！！不要接觸到任何雪！！！",
	"chapter.alaska.deathmessage" => "陷入了冰雪!",
	"chapter.alaska.introduction" => "
\n四支探索隊來到阿拉斯加雪山,但是位於極地的北極生物系統研究基地早已來到此地,
\n這一基地在4天前爆發了新型病菌NARVIK,潛伏在阿拉斯加的雪山上,
\n這種病菌會使人變得虛弱而沖動,具有強烈的攻擊性,
\n而探索隊只有跨過雪被,來到雪山中心的資源儲存所,找到解藥「 The Scythe 」
\n但沒有人能保證雪被下是泥土還是暗藏著殺機,
\n貪婪的其他人開始謀劃著自己的陰謀。。。",
	
	"chapter.arctic" => "《北冰洋篇》",
	"chapter.arctic.welcome" => "本房間的遊戲篇章:《北冰洋篇》",
	"chapter.sahara.touch" => "§3你腳下的水結冰了!好機會!",
	"chapter.arctic.deathmessage" => "被冰冷的海水凍結了!",
	"chapter.arctic.introduction" => "
\n四支探索隊來到北冰洋,由於極寒的天氣,人們接觸到水會立即受到凍傷!!!
\n但是創世神並沒有青睞任何一個人,他公平地將探險家們分成4支隊伍,分別是[紅'藍'綠'黃]
\n他們被隨機分配到四個不同的島嶼上,而四個島上都沒有能維持生命的資源------資源被安排到了四個島中間的【主島】
\n探險家們只能先在自己的島嶼上挖掘可用於戰鬥的資源,並在遊戲開戰之後搶奪【主島】並擊敗其他隊伍的敵人
\n但是...創世神偷偷的在戰爭中加了一些東西。是驚喜?是恐怖?還是...?",
	
	"chapter.sahara" => "《撒哈拉篇》",
	"chapter.sahara.welcome" => "本房間的遊戲篇章:《撒哈拉篇》",
	"chapter.sahara.touch" => "§3你陷進了流沙!趕緊爬出來!",
	"chapter.sahara.deathmessage" => "陷入了滾燙的流沙!",
	"chapter.sahara.introduction" => "
\n一架失事的飛機,緊急降落在一片炎熱廣闊的沙漠上
\n                  ------------撒哈拉大沙漠
\n這里隨時可能發生流沙或者沙暴,註意躲避和走位!
\n唯有長者才有機會活到最後!",
	
	"chapter.australia" => "《澳大利亞篇》",
	"chapter.australia.welcome" => "本房間的遊戲篇章:《澳大利亞篇》",
	"chapter.australia.change" => "瘋羊NARS綜合癥發生了變異,現在的瘋羊變得力大無窮！！！",
	"chapter.australia.deathmessage" => "被發瘋的羊群感染了!",
	"chapter.australia.introduction" => "
\n
\n
\n
\n
													 ",
	
	"chapter.venice" => "《威尼斯篇》",
	"chapter.venice.welcome" => "本房間的遊戲篇章:《威尼斯篇》",
	"chapter.venice.change" => "唿唿唿......大家所在的區域發生了海嘯！！不要接觸到任何海水！！！",
	"chapter.venice.deathmessage" => "被突如其來的海嘯卷走了!",
	"chapter.venice.introduction" => "
\n外表鮮麗的威尼斯水城曾盛名天下,
\n水曾是威尼斯的保護神,卻成了威尼斯最大的敵人.
\n1966年,威尼斯發生大洪災,城內水位高達1米,並造成巨大損失.
\n這一事件迫使意大利政府將防洪列為國家頭等大事.
\n然而政府部門間的漏洞被【北極生物系統研究基地】侵入,
\n他們向河中投入了NARVIK Ⅱ的試驗品......
\n究竟接觸到水會發送什麽?知道的人都住進了精神病院而無從考證......",

	"chapter.bedwars" => "《起床戰爭篇》",
	"chapter.bedwars.welcome" => "本房間的遊戲篇章:《起床戰爭篇》",
	"chapter.bedwars.deathmessage.1" => "§b[%0]§2已死亡,由於床§a沒有§2被破壞,即將滿血複活!",
	"chapter.bedwars.deathmessage.2" => "§b[%0]§2已死亡,由於床§c已經§2被破壞,無法複活!",
	"chapter.bedwars.break.1" => "§6起床§7[%0§f隊§7]§6的床遭到§7[%1§f隊§7]§6玩家§a[%2]§6破壞!剩余§d[%3]血量",
	"chapter.bedwars.break.2" => "§6起床§7[%0§f隊§7]§6的床遭到§7[%1§f隊§7]§6玩家§a[%2]§6破壞!該隊的床§3不複存在§6!",
	"chapter.bedwars.break.self" => "§6無法破壞自己隊伍的床!",
	"chapter.bedwars.break.protect" => "§6你被§a[%0§f隊§a]§6的核心驅逐了回去!",
	"chapter.bedwars.introduction" => "
\n本篇章的模式與<起床戰爭>相仿,盡情享受!",

	"chapter.skywars" => "《團隊空島篇》",
	"chapter.skywars.welcome" => "本房間的遊戲篇章:《團隊空島篇》",
	"chapter.skywars.change" => "",
	"chapter.skywars.deathmessage" => "打出了GG!",
	"chapter.skywars.introduction" => "
\n本篇章的模式與<團隊空島>相仿,盡情享受!",	

	"chapter.moon" => "《四色弧光篇》",
	"chapter.moon.welcome" => "本房間的遊戲篇章:《四色弧光篇》",
	"chapter.moon.change" => "",
	"chapter.moon.deathmessage" => "死翹翹啦~~~",
	"chapter.moon.ad1" => "",
	
	"join.room.success" => "§b成功進入§6[%0]§b號房間",
	"join.room.started" => "§5加入失敗!§3您要加入的§a[%0]§3號房間已經開始遊戲了",
	"join.room.joined" => "§5加入失敗!§3您已經加入過一個遊戲房間,無法再加入",
	"join.room.fulled" => "§5加入失敗!§3您要加入的§2[%0]§3號房間已經滿人了",
	"join.room.unloaded" => "§5加入失敗!§3您要加入的§2[%0]§3號房間沒有加載完畢",
	"join.room.banned" => "§5加入失敗!§3你被禁止此房間的戰橋小遊戲",
	"join.no.room" => "§5加入失敗!§3不存在§2[%0]§3號房間!",
	"join.room" => "§a+§d[%0]§7(§a%1§7/§b%2§7)",
	"join.team" => "§a+§d成功加入§7[%0§7隊]",
	"join.team.no.room" => "§5選擇失敗!§3您沒有進入任何一個房間",
	"join.team.already" => "§5選擇失敗!§3您已經選擇了一個隊伍,請先退出",
	"join.team.room" => "§5選擇失敗!§3您不在§2[%0]§3號房間",
	"join.team.started" => "§5選擇失敗!§3您所在的房間已經開始遊戲了",
	"join.team.full" => "§5選擇失敗!§3您選擇的隊伍已滿人,請重新選擇",
	"join.team.noexit" => "§5選擇失敗!§3您選擇的隊伍§2[%0]§3不存在",
	"join.balanced" => "§6由於隊伍直接最大人數差距超過§3[%0]§6名,無法開始遊戲\n§2請在§c%1§2秒內自行調整,否則即將強制整隊",
	
	"quit.no.room" => "§5退出失敗!§3你沒有在任何遊戲房間!",
	"quit.room.one" => "§7成功退出§6[%0]§7號遊戲房間,可輸入/bb bag拿回此前的背包",
	"quit.room" => "§c-§d[%0]§7(§2%1§7/§3%2§7)",
	"quit.team" => "§c-§d成功退出§7[%0§7隊]",
	
	"team.no.room" => "§5選擇隊伍失敗!§3你沒有處於任何一個遊戲房間!",
	"team.team" => "§6請選擇一個隊伍並加入",
	
	"room.delete" => "§e成功刪除§2[%0]§e號房間",
	"room.delete.no" => "§e刪除失敗!不存在§2[%0]§e號房間",
	"room.reload" => "§e成功重新加載§2[%0]§e號房間",
	"room.reload.no" => "§e重載失敗!不存在§2[%0]§e號房間",
	
	"set.start" => "§e開始設置第§a[%0]§e個戰橋房間(可輸入§f/bb set§e繼續按步驟設置或者§f/bb set back§e回退)",
	"set.warning" =>  "§e警告!§c設置遊戲房間前必須確保此地圖已建築完畢,設置完成後會按照地圖當前狀況進行備份,因此本地圖的建築在設置完成後都將無效(除非刪除房間重新設置)",
	"set.step-1" => "§7<§2設置 §f已退出設置模式§7>",
	"set.step0" => "§7<§2設置 §6遊戲等待區§7>",
	"set.step1" => "§7<§2設置 §6遊戲中心島(遊戲地圖的中心島嶼的中心點)§7>",
	"set.step2" => "§7<§2設置 §c紅隊島§7>",
	"set.step3" => "§7<§2設置 §b藍隊島§7>",
	"set.step4" => "§7<§2設置 §a綠隊島§7>",
	"set.step5" => "§7<§2設置 §e黃隊島§7>",
	"set.step6" => "§7<§2設置 §6遊戲結束區§7>",
	"set.step7" => "§7<§2設置 §7請輸入§a[/bb set (篇章名稱)] §7來設置此房間的篇目§7>",
	"set.finish" => "§7<§d成功設置完成第§a[%0]§d號遊戲房間§7>",
	"set.back" => "§7<§2返回 §3已返回上一步設置§7>",
	"set.default" => "§7<§c失敗 §3無法將服務器默認地圖設置為遊戲地圖§7>",
	"set.y.125" => "§7<§c失敗 §3你所在高度過低或過高,請移動到更低的位置繼續設置§7>",
	"set.no.php7" => "§7<§c失敗 §3篇章<%0>僅支持PHP7§7>",
	"set.level" => "§7<§c失敗 §3無法將已經屬於某個遊戲房間的地圖設置為遊戲地圖§7>",
	"set.level.game" => "§7<§c失敗 §3結束地圖不可以為遊戲地圖§7>",
	
	"edit.op" => "§7你擁有管理員權限,已被允許編輯遊戲地圖方塊",
	"edit.before.start" => "§7你無法在遊戲開始前編輯遊戲地圖方塊",
	
	"game.readytick" => "§6開始倒計時!!",
	"game.start" => "§b   遊戲開始!\n§6請做好蒐集資源準備",
	"game.war" => "§c   開始戰鬥吧!\n§6已解除區域移動限制",
	"game.generate" => "§2   開始生成戰橋!\n§6做好直面敵人進攻的準備!",
	"game.ready" => "§3遊戲準備開始...遊戲開始前§a未選擇隊伍§3的玩家將隨機進入隊伍",
	"game.overtime" => "§3遊戲時間過長,即將強制結束",
	"game.respawn.self" => "§3已成功§a[重生]",
	"game.respawn.ready" => "§7你即將進入§a[重生]",
	"game.respawn" => "§1玩家§2[%0]§1已重生",	
	"game.spectate.self" => "§3玩家§7[我]§3進入了觀戰模式",
	"game.spectate.ready" => "§7你即將進入§b[觀戰]§7模式",
	"game.spectate" => "§3玩家§7[%0]§3進入了觀戰模式",
	"game.kill.getcoins" => "§2你擊殺了§b[%0]§2,獲得§e通用金幣[%1]§2枚",
	"game.die.player" => "§2玩家§b[%0]§2被§5[%1]§2擊殺!",
	"game.die.magic" => "§2玩家§b[%0]§2%1!",
	"game.die.unknown" => "§2玩家§b[%0]§2一言不合就死了!",
	"game.refill.prepare" => "§e-<=§3寶箱即§f[§b%0§f]§3將重置§e=>-",
	"game.refill.finish" => "§e===§c寶箱重置完成§e===",
	"game.duel.prepare" => "§e-<=§3即將進§f[§b%0§f]§3入決鬥§e=>-",
	"game.duel.finish" => "§e===§c傾盡全力廝殺§e===",
	
	
	"sign.line_2" =>  "§c創建§6戰橋木牌§c失敗§7,§6第二行必為§b[join,quit,team,spectate]§6其中之一",
	"sign.join.line_3_must_be_number" => "§c創建§6戰橋房間傳送裝置§c失敗§7,§6第三行為房間號,需為數字",
	"sign.join.room_0" => "§c創建§6戰橋房間傳送裝置§c失敗§7,§6第三行房間號需大於0",
	"sign.spectate.line_3_must_be_number" => "§c創建§6戰橋房間觀戰裝置§c失敗§7,§6第三行為房間號,需為數字",
	"sign.spectate.room_0" => "§c創建§6戰橋房間觀戰裝置§c失敗§7,§6第三行房間號需大於0",
	"sign.team.line_3" => "§c創建§6戰橋隊伍選擇裝置§c失敗§7,§6沒有設置第三行隊伍項",
	"sign.team.line_3_must_be_team" => "§c創建§6戰橋隊伍選擇裝置§c失敗§7,§6第三行必為§f[red,blue,yellow,green,random,quit]§6其中之一",
	];
}
?>