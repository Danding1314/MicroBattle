<?php

namespace MGameBase\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;
use pocketmine\Player;
use pocketmine\Server;
use MGameBase\MGameBase;
use MGameBase\Friend;
use MGameBase\MiniMail;
class MgbCommand extends Command{
	
	private $plugin;

	public function __construct(MGameBase $plugin){
		parent::__construct("mgb", "description", "usage");

		$this->setPermission("MGameBase.command.mgb");

		$this->plugin = $plugin;
	}

	public function execute(CommandSender $sender, $label, array $args){
		if(!$this->plugin->isEnabled()) return false;
		if(!$this->testPermission($sender)){
			return false;
		}
		if(!$sender instanceof Player){
			$sender->sendMessage("You are not a player!");
			return true;
		}		
		if($args == null){
			$this->sendCommandHelp($sender);
			return true;
		}
			switch($args[0]){
				case "註冊":
				case "登錄":
				case "join":
				case "register":
				case "login":
				if(!$this->plugin->isConnected()){
					$sender->sendMessage($this->plugin->getMessage($sender,"not.connected"));
					return true;
				}
				if($this->plugin->isPlayerAuthenticated($sender)){
		            //$sender->sendMessage("- §cYou are already logined");
		            $sender->sendMessage("- §c你已經登錄了,無需重複登陸");
					return true;
				}
				$mp = MGameBase::getInstance()->getMP($sender);
				$mp->setAccount("UnLogin");
				$this->plugin->level[spl_object_hash($sender)] = 0;
				$this->plugin->deauthenticatePlayer($sender);
				//$sender->sendMessage("§l- §3Please Type An Account You Like");
				$sender->sendMessage("- §3請輸入賬戶:你的名字");
				return true;
				
				case "logout":
				if(!$this->plugin->isConnected()){
						$sender->sendMessage($this->plugin->getMessage($sender,"not.connected"));
					return true;
				}
				unset($this->plugin->level[spl_object_hash($sender)]);
				$this->plugin->deauthenticatePlayer($sender);
				$sender->sendMessage("§l- §3已退出§7<§b小遊戲賬號§7>");
				return true;
				
				case "rename":
				if(!$this->plugin->isConnected()){
						$sender->sendMessage($this->plugin->getMessage($sender,"not.connected"));
					return true;
				}
				if(!$this->plugin->isPlayerAuthenticated($sender)){
		            $sender->sendMessage($this->plugin->getMessage($sender,"not.login"));
					return true;
				}
				if(!isset($args[1]) or $args[1] == " "){
					$sender->sendMessage("- §1/§6mgb §arename §f名稱");
					return true;
				}
				$gamename = "";
				foreach($args as $k => $v){
					if($k !== 0){
						$gamename .= $v." ";
					}
				}
				$gamename = trim($gamename);
				$gamename = mb_substr($gamename,0,7,'utf-8');
				if(in_array(strtolower($gamename),MGameBase::$keywords)){
					$sender->sendMessage($this->plugin->getMessage($sender,"rename.keyword",[$gamename]));
					return true;
				}
				$mp = MGameBase::getInstance()->getMP($sender);
				$mp->setGamename($gamename);
				$this->plugin->setPlayerData($sender, "gamename", $gamename);
				$sender->sendMessage($this->plugin->getMessage($sender,"rename.success",[$gamename]));
				return true;
				
				case "me":
				case "info":
				$this->plugin->sendInfo($sender);
				return true;
				
				case "money":
				if($this->plugin->config["遊戲幣兌換金錢開關"] != true or $this->plugin->config["遊戲幣兌換金錢匯率"] <= 0){
					$sender->sendMessage(MGameBase::FORMAT."§c當前服務器沒有開啟§a[遊戲幣兌換金錢功能]");
					return true;
				}
				if(!isset($args[1]) or !is_numeric($args[1]) or $args[1] <= 0){
					$sender->sendMessage(MGameBase::FORMAT."§7|-------------§c格式錯誤§7-------------|");
					$sender->sendMessage(MGameBase::FORMAT."§b/§cmgb §l§emoney §6[要兌換的金錢量]");
					$sender->sendMessage(MGameBase::FORMAT."§b當前服務器§a[遊戲幣兌換金錢匯率]§b為 §f1 :".$this->plugin->config["遊戲幣兌換金錢匯率"]);
					return true;
				}
				$money = $args[1];
				if($money > $this->plugin->getCoin($sender) * $this->plugin->config["遊戲幣兌換金錢匯率"]){
					$sender->sendMessage(MGameBase::FORMAT."§c兌換§a".$money."§c金錢需要§6".$money / $this->plugin->config["遊戲幣兌換金錢匯率"]."遊戲幣, 你有:§b".$this->plugin->getCoin($sender)."遊戲幣");
					return true;
				}
				$plugin = Server::getInstance()->getPluginManager()->getPlugin("EconomyAPI");
				if($plugin != null){
					$plugin->addMoney($sender->getName(), $money);
					$this->plugin->updateCoin($sender, - $money / $this->plugin->config["遊戲幣兌換金錢匯率"]);
					$sender->sendMessage(MGameBase::FORMAT."§b兌換成功, 獲得§a金錢".$money."§b, 花費§6".$money / $this->plugin->config["遊戲幣兌換金錢匯率"]."遊戲幣§b, 現在你有:§6".$this->plugin->getCoin($sender)."遊戲幣");
				}else{
					$sender->sendMessage(MGameBase::FORMAT."§c當前服務器沒有安裝§a[EconomyAPI]插件");
				}
				return true;
				
				case "coin":
				if(!$sender->isOp()){
					 $sender->sendMessage(MGameBase::FORMAT."你沒有權限使用此命令");
					 return true;
				}
				if(!isset($args[3]) or !is_numeric($args[3])){
					$sender->sendMessage(MGameBase::FORMAT."§7|-------------§c格式錯誤§7-------------|");
					$sender->sendMessage(MGameBase::FORMAT."§b/§cmgb §l§ecoin §r§2add §6[name] §a[amount]");
					$sender->sendMessage(MGameBase::FORMAT."§b/§cmgb §l§ecoin §r§2del §6[name] §a[amount]");
					$sender->sendMessage(MGameBase::FORMAT."§b/§cmgb §l§ecoin §r§2set §6[name] §a[amount]");
					return true;
				}
				switch($args[1]){
					case "add":
					$this->plugin->updateCoin($args[2], $args[3]);
					$sender->sendMessage(MGameBase::FORMAT."§7|-------------§a授權成功§7-------------|");
					$sender->sendMessage(MGameBase::FORMAT."§6給予玩家 §b".$args[2]." §6遊戲幣 §c".$args[3]." §6個");
					return true;
					
					case "del":
					$this->plugin->updateCoin($args[2], -$args[3]);
					$sender->sendMessage(MGameBase::FORMAT."§7|-------------§a授權成功§7-------------|");
					$sender->sendMessage(MGameBase::FORMAT."§6銷毀玩家 §b".$args[2]." §6遊戲幣 §c".$args[3]." §6個");
					return true;
					
					case "set":
					$this->plugin->setCoin($args[2], $args[3]);
					$sender->sendMessage(MGameBase::FORMAT."§7|-------------§a授權成功§7-------------|");
					$sender->sendMessage(MGameBase::FORMAT."§6設置玩家 §b".$args[2]." §6遊戲幣 §c".$args[3]." §6個");
					return true;
					
					default:
					$sender->sendMessage(MGameBase::FORMAT."§7|-------------§c格式錯誤§7-------------|");
					$sender->sendMessage(MGameBase::FORMAT."§b/§cmgb §l§ecoin §r§2add §6[name] §a[amount]");
					$sender->sendMessage(MGameBase::FORMAT."§b/§cmgb §l§ecoin §r§2del §6[name] §a[amount]");
					$sender->sendMessage(MGameBase::FORMAT."§b/§cmgb §l§ecoin §r§2set §6[name] §a[amount]");
					return true;
				}
				return true;
				
				case "vip":
				if(!$sender->isOp()){
					$sender->sendMessage(MGameBase::FORMAT."§c您沒有權限使用此命令");
					return true;
				}
				if(!isset($args[1]) or !isset($args[2])){
					$sender->sendMessage(MGameBase::FORMAT."§7|-------------§c格式錯誤§7-------------|");
					$sender->sendMessage(MGameBase::FORMAT."§b/§cmgb §l§evip §r§2add §6[name] [time]");
					$sender->sendMessage(MGameBase::FORMAT."§b/§cmgb §l§evip §r§2del §6[name]");
					return true;
				}
				switch($args[1]){
					case "add":
					if(!isset($args[3]) or !is_numeric($args[3])){
						$sender->sendMessage(MGameBase::FORMAT."§7|-------------§c格式錯誤§7-------------|");
						$sender->sendMessage(MGameBase::FORMAT."§b/§cmgb §l§evip §r§2add §6[name] [time]");
						return true;
					}
					$time = intval(86400*$args[3]);
					$vip = $this->plugin->getVIP($args[2]) + 1;
					$this->plugin->setVIP($args[2], $vip, $time);
					$sender->sendMessage(MGameBase::FORMAT."§7|-------------§a授權成功§7-------------|");
					$sender->sendMessage(MGameBase::FORMAT."§6已將玩家§2[".$args[2]."]§6設置為§cVIP§b (".$vip.")§6級,§a".$args[3]."§6天");
					$player = $this->plugin->getServer()->getPlayerExact($args[2]);
					if($player instanceof Player){
						if($vip <= 1){
						$player->sendMessage(MGameBase::FORMAT."§b[§cVIP§b]§r§6您成為了§2(".$vip.")§6級VIP玩家");
						}else{
						$player->sendMessage(MGameBase::FORMAT."§b[§5S§cVIP§b]§r§6您成為了§2(".$vip.")§6級VIP玩家");
						}
					}
					return true;
					
				case "del":
					$this->plugin->setVIP($args[2] , 0);
					$sender->sendMessage(MGameBase::FORMAT."§7|-------------§a授權成功§7-------------|");
					$sender->sendMessage(MGameBase::FORMAT."§6已將玩家§2[".$args[2]."]§6奪去§cVIP§6權限");
					$player = $this->plugin->getServer()->getPlayerExact($args[2]);
					if($player instanceof Player){
					$player->sendMessage(MGameBase::FORMAT."§b[§cVIP§b]§r您不再是VIP玩家");
					}
					return true;
					break;
					
					default:
					$sender->sendMessage(MGameBase::FORMAT."§7|-------------§c格式錯誤§7-------------|");
					$sender->sendMessage(MGameBase::FORMAT."§b/§cmgb §l§evip §r§2add §6[name]");
					$sender->sendMessage(MGameBase::FORMAT."§b/§cmgb §l§evip §r§2del §6[name]");
					return true;
					break;			
				}
				return true;
				
				case "bug":
					$games = [];
					foreach(MGameBase::$allgames as $plugin=>$name){
						$games[strtolower($plugin)] = $name;
					}
					if(isset($args[2]) and $args[2] !== " "){
						if(isset($games[strtolower($args[1])]) or in_array($args[1], $games)){
							if(in_array($args[1], $games)){
								foreach($games as $plugin => $name){
									if($name == $args[1]){
										$game = $plugin;
										continue;
									}
								}
							}else{
								$game = strtolower($args[1]);
							}
							$bug = "";
							foreach($args as $key => $val){
								if($key >= 2){
									$bug .= $val." ";
								}
							}
							if(!$this->plugin->isConnected()){
								$sender->sendMessage(MGameBase::FORMAT."§aOK");
								$this->plugin->uploadBug($sender->getName(), $this->plugin->config["服主的賬號"], $game, $bug, false);
							}else{
								$this->plugin->uploadBug($sender->getName(), $this->plugin->config["服主的賬號"], $game, $bug, true);
								$sender->sendMessage(MGameBase::FORMAT."§6上傳成功,請等待小遊戲作者§3Matt§6進行檢查修複");
							}
						}else{
						$sender->sendMessage(MGameBase::FORMAT."§7|-------------§c格式錯誤§7-------------|");
						$sender->sendMessage(MGameBase::FORMAT."§b輸入正確的小遊戲名");
						$sender->sendMessage(MGameBase::FORMAT."§a".implode("§6 | §a", $games));							
						}
					}else{
						$sender->sendMessage(MGameBase::FORMAT."§7|-------------§c格式錯誤§7-------------|");
						$sender->sendMessage(MGameBase::FORMAT."§b/§cmgb §l§3bug §r§2遊戲名 §6發生的錯誤內容");
						$sender->sendMessage(MGameBase::FORMAT."§a".implode("§6 | §a", $games));
					}
					return true;
					break;						
				
				case "update":
				case "更新":
				case "更新插件":
				if(!$sender->isOp()){
					$sender->sendMessage(MGameBase::FORMAT."§c您沒有權限使用此命令");
					return true;
				}
				$this->plugin->update();
				return true;
				default:
				$this->sendCommandHelp($sender);
				return true;
			}
	}
	
	public function sendCommandHelp($sender){
		$sender->sendMessage(MGameBase::FORMAT."§7查詢我的信息§6/mgb §bme");
		#$sender->sendMessage(MGameBase::FORMAT."§7向本作者建議§6/mgb §bbug");
		$sender->sendMessage(MGameBase::FORMAT."§7金幣兌換金錢§6/mgb §bmoney");
		if($sender->isOp()){
			$sender->sendMessage(MGameBase::FORMAT."§7金幣設置內容§6/mgb §bcoin");
			$sender->sendMessage(MGameBase::FORMAT."§7會員設置內容§6/mgb §bvip");
			#$sender->sendMessage(MGameBase::FORMAT."§7更新插件§6/mgb §bupdate");
		}
		if($this->plugin->isMGB() and $this->plugin->isConnected()){
			$sender->sendMessage(MGameBase::FORMAT."§7登錄小遊戲賬號§a/mgb §blogin");
			$sender->sendMessage(MGameBase::FORMAT."§7註銷小遊戲賬號§a/mgb §blogout");
			$sender->sendMessage(MGameBase::FORMAT."§7更換小遊戲內的名稱§a/mgb §brename");
		}else{

		}
	}
}
?>