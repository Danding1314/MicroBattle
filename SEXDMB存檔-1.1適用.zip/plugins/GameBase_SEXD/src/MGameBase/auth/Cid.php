<?php

namespace MGameBase\auth;

use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\Server;

class Cid extends PlayerPreLoginEvent{

}


?>