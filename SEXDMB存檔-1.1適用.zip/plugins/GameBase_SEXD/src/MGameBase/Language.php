<?php
namespace MGameBase;

use MGameBase\MGameBase;

class Language{
	public static  $message=[
	"ch" => array(
	"lv" => "級別",
	"exp" => "經驗值",
	"coin" => "金幣",
	"account" => "賬戶",
	"name" => "名稱",
	"ad.vip" => "§3[§7充值§cVIP§3]",
	"register.error.unknow" => "§c當你註冊時伺服器觸發了未知錯誤",
	"login.error.unknow" => "§c當你登陸時伺服器觸發了未知錯誤",
	"auth.type.password" => "§a輸入你的密碼來完成驗證", 
	"register.success" => "§a註冊成功",
	"login.error.password" => "§3輸入的密碼不正確",
	"login.success" => "§a登入成功",
	"back.lobby" => "§6返回到大廳",
	"show" => "§a已顯示其他玩家",
	"hide" => "§2已屏蔽其他玩家",
	"lang.change" => "§6成功更換了語言設置",
	"lang.noexist" => "§6不存在這種語言",
	"command.not.player" => "你不是玩家",
	"no.permission" => "§c沒有權限使用此命令",
	
	"command.mgb" => "小遊戲主指令",
	"command.mail" => "郵件系統",
	"command.friend" => "好友系統",
	"command.hide" => "隱藏其他玩家",
	"command.show" => "顯示其他玩家",
	"command.lang" => "更換語言",
	
	"not.mgb" => "§c你所在的伺服器沒有支持§7<§b小遊戲核心數據§7>§c,無法使用此功能",
	"not.connected" => "§5小遊戲核心數據處理失敗,請聯系服主",
	"not.login" => "§3你沒有登錄§7<§b小遊戲賬號§7>§3,看來得先輸入§b/mgb§3來找找辦法",
	
	"rename.success" => "§3成功將§7<§b小遊戲名稱§7>§3更換為§a[§6%0§a]",
	"rename.keyword" => "§a[§6%0§a]§3是一個§c關鍵詞§3,更改§7<§b小遊戲名稱§7>§3失敗!",
	
	"mail.unlogin" => "§3你沒有登錄§7<§b小遊戲賬號§7>§3,看來得先輸入/mgb來找找辦法",
	"mail.send.success" => "§d成功向 §a[%0] §d發送了一封郵件",
	"mail.send.self" => "§c無法向自己發送郵件!",
	"mail.send.noexist" => "§c沒有為 §2[%0] §c的賬戶",
	"mail.read.noexist" => "§c不存在ID為§2[%0]§c的郵件",
	"mail.list.page" => "§3  正在查看第§a[%0]§3頁/共§2[%1]§3頁郵件",
	"mail.del.success" => "§6已將ID為§a[%0]§6的郵件置入回收站",
	"mail.del.notmine" => "§cID為§2[%0]§c的郵件不是你的,你無法刪除它",
	"mail.del.noexist" =>  "§c不存在ID為§2[%0]§c的郵件",
	"mail.delall.success" => "§6已將§a所有§6的郵件置入回收站",
	"mail.del.save7" => "§a回收站中的郵件將只保存§e[7天]",
	"mail.restore.success" => "§6已將ID為§a[%0]§6的郵件恢複",
	"mail.restore.notmine" => "§cID為§2[%0]§c的郵件不是你的,你無法恢複它",
	"mail.restore.noexist" =>  "§c不存在ID為§2[%0]§c的郵件",
	"mail.restoreall.success" => "§6已將§a所有§6的郵件恢複",
	"mail.secret.success" => "§d成功向 §a[%0] §d發送了一封悄悄話，不過對方沒法回複哦~",
	"mail.secret.self" => "§c無法向自己發送悄悄話!",
	"mail.secret.noexist" => "§c沒有為 §2[%0] §c的賬戶",
	"mail.bottle.success" => "§3已經將藏有§7[%0]§3小紙條的漂流瓶丟向大海了!",
	"mail.bottle.to" => "§8浪似沾濕我身，卻是感觸的眼淚，一個§9[漂流瓶]§8漂至到我沾濕的腳邊\n §8輸入§b[/mail]§8進行操作",
	"mail.check" => "§8嗨,我有新的§b郵件消息§8啦! \n §8我有§a[%0]§8個未讀消息 \n §8輸入§b[/mail]§8進行操作",
	
	
	"f.unlogin" => "§3我沒有登錄§7<§b小遊戲賬號§7>§3,看來得先輸入/mgb來找找辦法",
	"f.make.success" => "§3我現在已與§b[%0]§3成為好友",
	"f.accept.to" => "§3玩家§b[%0]§3同意添加您為好友",
	"f.refuse.to" => "§3玩家§b[%0]§3拒絕添加您為好友",
	"f.add.to" => "§3玩家§b[%0]§3請求添加您為好友",
	"f.del.to" => "§3玩家§b[%0]§3請求添加您為好友",
	"f.add.self" => "§c無法向自己發送交友請求!",
	"f.add.offline" => "§c您要添加的§b[%0]§c玩家沒有上線",
	"f.add.unlogin" => "§c您要添加的§b[%0]§c玩家沒有登錄§7<§b小遊戲賬號§7>",
	"f.add.noexist" => "§c不存在賬戶為§b[%0]§c的玩家",
	"f.add.already" => "§c玩家§b[%0]§c已經是你的好友了",
	"f.add.success" => "§3成功向玩家§b[%0]§3發出好友請求",
	"f.del.noexit"=> "§c不存在賬戶為§b[%0]§c的好友",
	"f.del.success"=> "§3玩家§b[%0]§3不再是是你的好友",
	"f.list.page" => "§3  正在查看第§e[%0]§3頁/共§2[%1]§3頁好友列表",
	"f.request.page" => "§3  我正在查看第§e[%0]§3頁/共§2[%1]§3頁好友請求",
	"f.accept.all.success"=> "§3成功添加§2[全部%0個好友請求]§3為您的好友",
	"f.accept.all.noexist" => "§3您的好友請求列表是空的~",
	"f.accept.noexist" => "§c不存在ID為§e[%0]§c的好友請求",
	"f.accept.notmine" => "§c不存在ID為§e[%0]§c的好友請求",
	"f.accept.success" => "§3我同意了ID為§e[%0]§3的好友請求",
	"f.refuse.all.success" => "§3成功拒絕§2[全部%0個好友請求]",
	"f.refuse.all.noexist" => "§3您的好友請求列表是空的~",
	"f.refuse.noexist" => "§c不存在ID為§e[%0]§c的好友請求",
	"f.refuse.notmine" => "§c不存在ID為§e[%0]§c的好友請求",
	"f.refuse.success" => "你拒絕了ID為§e[%0]§3的好友請求",
	"f.check" => "§7嗨,有新的§3好友請求§7啦! \n §7我有§a[%0]§7個好友請求 \n §7輸入§b[/friend]§7進行操作",
	),

	];
	
	public static  $random=[
	"ch" => array(
	"mail.list.rand1" => "有話想對朋友說卻不想當面說?趕緊用悄悄話 [secret] 功能吧",
	"mail.list.rand2" => "讓漂流瓶 [bottle] 流向遠方，等待有緣人從海中提起~",
	"mail.list.rand3" => "消息太多了？可以刪除全部哦 [del all],而且可以七天內回收哦",
	"mail.list.rand4" => "禁止隨地大小便，違者沒收工具！",
	"f.list.rand1" => "歲不寒無以知松柏，事不難無以知君子",
	"f.list.rand2" => "貧賤之交不可忘，糟糠之妻不下堂",
	"f.list.rand3" => "鹿鳴得食而相呼，伐木同聲而求友",
	"f.list.rand4" => "聽說可以輸入/friend add :XXX直接申請添加XXX這個玩家為好友哦（沒有冒號的話一般默認XXX為小遊戲賬號）",
	),
	
	];
}
?>
