<?php

namespace restartme\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;
use restartme\utils\MemoryChecker;
use restartme\RestartMe;

class RestartMeCommand extends Command{
    /** @var RestartMe */
    private $plugin;
    /**
     * @param RestartMe $plugin
     */
    public function __construct(RestartMe $plugin){
        parent::__construct("restartme");
        $this->setDescription("Shows all RestartMe commands");
        $this->setUsage("/restartme <sub-command> [parameters]");
        $this->setPermission("restartme.command.restartme");
        $this->setAliases(["rm"]);
        $this->plugin = $plugin;
    }
    /** 
     * @return RestartMe 
     */
    public function getPlugin(){
        return $this->plugin;
    }
    /** 
     * @param CommandSender $sender 
     */
    private function sendCommandHelp(CommandSender $sender){
        $commands = [
            "add" => "给定时器增加n秒",
            "help" => "显示所有RestartMe命令",
            "memory" => "显示内存使用情况",
            "set" => "将定时器设置为n秒",
            "start" => "启动计时器",
            "stop" => "停止定时器",
            "subtract" => "从定时器中减去n秒",
            "time" => "获取剩余时间，直到服务器重新启动"
        ];
        $sender->sendMessage("RestartMe 命令:");
        foreach($commands as $name => $description){
            $sender->sendMessage("/restartme ".$name.": ".$description);
        }
    }
    /**
     * @param CommandSender $sender
     * @param string $label
     * @param string[] $args
     * @return bool
     */
    public function execute(CommandSender $sender, $label, array $args){
        if(!$this->testPermission($sender)) return false;
        if(isset($args[0])){
            switch(strtolower($args[0])){
                case "a":
                case "add":
                    if(isset($args[1])){
                        if(is_numeric($args[1])){
                            $time = (int) $args[1];
                            $this->getPlugin()->addTime($time);
                            $sender->sendMessage(TextFormat::GREEN."添加 ".$time." 重启定时器.");
                        }
                        else{
                            $sender->sendMessage(TextFormat::RED."时间值必须是数字.");
                        } 
                    }
                    else{
                        $sender->sendMessage(TextFormat::RED."请指定时间值.");
                    }
                    return true;
                case "help":
                    $this->sendCommandHelp($sender);
                    return true;
                case "m":
                case "memory":
                    $memLimit = $this->getPlugin()->getMemoryLimit();
                    $sender->sendMessage("Bytes: ".memory_get_usage(true)."/".MemoryChecker::calculateBytes($memLimit));
                    $sender->sendMessage("内存限制: ".$memLimit);
                    $sender->sendMessage("重载: ".(MemoryChecker::isOverloaded($memLimit) ? TextFormat::GREEN."是" : TextFormat::RED."不是"));
                    return true;
                case "set":
                    if(isset($args[1])){
                        if(is_numeric($args[1])){
                            $time = (int) $args[1];
                            $this->getPlugin()->setTime($time);
                            $sender->sendMessage(TextFormat::GREEN."将重启定时器设置为 ".$time.".");
                        }
                        else{
                            $sender->sendMessage(TextFormat::RED."时间值必须是数字.");
                        } 
                    }
                    else{
                        $sender->sendMessage(TextFormat::RED."请指定时间值.");
                    }
                    return true;
                case "start":
                    if($this->getPlugin()->isTimerPaused()){
                        $this->getPlugin()->setPaused(false);
                        $sender->sendMessage(TextFormat::YELLOW."计时器不再暂停.");
                    }
                    else{
                        $sender->sendMessage(TextFormat::RED."计时器未暂停.");
                    }
                    return true;
                case "stop":
                    if($this->getPlugin()->isTimerPaused()){
                        $sender->sendMessage(TextFormat::RED."计时器已暂停.");
                    }
                    else{
                        $this->getPlugin()->setPaused(true);
                        $sender->sendMessage(TextFormat::YELLOW."计时器已暂停.");
                    }
                    return true;
                case "s":
                case "subtract":
                    if(isset($args[1])){
                        if(is_numeric($args[1])){
                            $time = (int) $args[1];
                            $this->getPlugin()->subtractTime($time);
                            $sender->sendMessage(TextFormat::GREEN."扣除 ".$time." 从重启定时器.");
                        }
                        else{
                            $sender->sendMessage(TextFormat::RED."时间值必须是数字.");
                        } 
                    }
                    else{
                        $sender->sendMessage(TextFormat::RED."请指定时间值.");
                    }
                    return true;
                case "time":
                    $sender->sendMessage(TextFormat::YELLOW."剩余时间: ".$this->getPlugin()->getFormattedTime());
                    return true;
                default:
                    $sender->sendMessage("Usage: ".$this->getUsage());
                    return false;
            }
        }
        else{
            $this->sendCommandHelp($sender);
            return false;
        }
    }
}