<?php
namespace aliuly\worldprotect\common;
use pocketmine\item\Item;

/**
 * ItemName database
 */
abstract class ItemName {
	/** @var array $xnames extended names */
	static protected $xnames = null;
	/** @var str[] $items Nice names for items */
	static protected $items = [];
	/** @var str[] $usrnames Possibly localized names for items */
	static protected $usrnames = [];
	/**
	 * Initialize $usrnames
	 * @param str[] $names - names to load
	 */
	static public function initUsrNames(array $names) {
		self::$usrnames = $names;
	}
	/**
	 * Load the specified item names.
	 * Return number of items read, -1 in case of error.
	 * @param str $f - Filename to load
	 * @return int
	 */
	public static function loadUsrNames($f) {
		$tx = file($f, FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES);
		$i = 0;
		if ($tx === false) return -1;
		foreach ($tx as $x) {
			$x = trim($x);
			if (substr($x,0,1) == "#" || substr($x,0,1) == ";") continue;
			$x = preg_split('/\s*=\s*/',$x,2);
			if (count($x) != 2) continue;
			++$i;
			self::$usrnames[$x[0]] = $x[1];
		}
		return $i;
	}

	/**
	 * Initialize extended names table
	 */
	static protected function initXnames() {
		self::$xnames = [
			Item::DYE => [
				0 => "墨囊",
				1 => "玫瑰红",
				2 => "仙人掌绿色",
				3 => "可可豆",
				4 => "青金石",
				5 => "紫色染料",
				6 => "青色染料",
				7 => "亮灰色染料",
				8 => "灰色染料",
				9 => "粉色染料",
				10 => "石灰染料",
				11 => "蒲公英黄色",
				12 => "亮蓝色染料",
				13 => "品红染料",
				14 => "橙色染料",
				15 => "骨粉",
				"*" => "染料",
			],
			Item::SPAWN_EGG => [
				"*" => "鸡蛋",
				32 => "僵尸蛋",
				33 => "JJ怪蛋",
				34 => "小白蛋",
				35 => "蜘蛛蛋",
				36 => "僵尸猪人蛋",
				37 => "史莱姆蛋",
				38 => "末影人蛋",
				39 => "银鱼蛋",
				40 => "洞穴蜘蛛蛋",
				41 => "恶魂蛋",
				42 => "Spawn Magma Cube",
				10 => "鸡蛋",
				11 => "牛蛋",
				12 => "猪蛋",
				13 => "羊蛋",
				14 => "狼蛋",
				16 => "蘑菇牛蛋",
				17 => "鱿鱼蛋",
				19 => "蝙蝠蛋",
				15 => "村民蛋",
			]
		];
	}

	/**
	 * Given an pocketmine\item\Item object, it returns a friendly name
	 * for it.
	 *
	 * @param Item item
	 * @return str
	 */
	static public function str(Item $item) {
		$id = $item->getId();
		$meta = $item->getDamage();
		if (isset(self::$usrnames[$id.":".$meta])) return self::$usrnames[$id.":".$meta];
		if (isset(self::$usrnames[$id])) return self::$usrnames[$id];
		if (self::$xnames == null) self::initXnames();

		if (isset(self::$xnames[$id])) {
			if (isset(self::$xnames[$id][$meta])) {
				return self::$xnames[$id][$meta];
			} elseif (isset(self::$xnames[$id]["*"])) {
				return self::$xnames[$id]["*"];
			} else {
				return self::$xnames[$id][0];
			}
		}
		$n = $item->getName();
		if ($n != "Unknown") return $n;
		if (count(self::$items) == 0) {
			$constants = array_keys((new \ReflectionClass("pocketmine\\item\\Item"))->getConstants());
			foreach ($constants as $constant) {
				$cid = constant("pocketmine\\item\\Item::$constant");
				$constant = str_replace("_", " ", $constant);
				self::$items[$cid] = $constant;
			}
		}
		if (isset(self::$items[$id])) return self::$items[$id];
		return $n;
	}
}
