<?php

namespace Debug;

use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\level\Level;
use pocketmine\scheduler\PluginTask;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\level\LevelLoadEvent;
use pocketmine\event\entity\EntitySpawnEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\math\Vector3;

class Main extends PluginBase implements Listener{
	/*
	private $lastMessage = array();
	private $lastTeleport = array();
*/
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}
		
		public function onPlayerLogin(PlayerLoginEvent $event) {
		$player = $event->getPlayer();
		$x = $this->getServer()->getDefaultLevel()->getSafeSpawn()->getX();
		$y = $this->getServer()->getDefaultLevel()->getSafeSpawn()->getY();
		$z = $this->getServer()->getDefaultLevel()->getSafeSpawn()->getZ();
		$level = $this->getServer()->getDefaultLevel();
		$player->setLevel($level);
		$player->teleport(new Vector3($x, $y, $z, $level));
	}
	
	public function onPlayerJoin(PlayerJoinEvent $event) 
	{
		$player = $event->getPlayer();
		$inventory = $player->getInventory();
		$inventory->clearAll();
	}
	
	public function onRespawn(PlayerRespawnEvent $event)
	{
		    $p = $event->getPlayer();
			//$p->sendMessage("修復中");
			$p->dontRecord = true;
			//$this->getServer()->getScheduler()->scheduleDelayedTask(new PluginCallbackTask($this, [$this,"teleport"], [$p,$p->getPosition()]),10);
			$p->teleport($p->add(300,50,300));
		}
}		

   	function EntitySpawnEvent(EntitySpawnEvent $event){
		    $p = $event->getPlayer();
			//$p->sendMessage("修復中");
			$p->dontRecord = true;
			//$this->getServer()->getScheduler()->scheduleDelayedTask(new PluginCallbackTask($this, [$this,"teleport"], [$p,$p->getPosition()]),10);
			$p->teleport($p->add(300,50,300));
		}
		
	function LevelLoadEvent(LevelLoadEvent $event){
		    $p = $event->getPlayer();
			//$p->sendMessage("修復中");
			$p->dontRecord = true;
			//$this->getServer()->getScheduler()->scheduleDelayedTask(new PluginCallbackTask($this, [$this,"teleport"], [$p,$p->getPosition()]),10);
			$p->teleport($p->add(300,50,300));
		}

	function EntityTeleportEvent(EntityTeleportEvent $event){
		if($event->getEntity() instanceof Player && !isset($event->getEntity()->dontRecord)){
			$this->lastTeleport[$event->getEntity()->getName()] = time();
		}
		unset($event->getEntity()->dontRecord);
	}
	
	function teleport($p,$pos){
		if(!isset($this->lastTeleport[$p->getName()]) || time() - $this->lastTeleport[$p->getName()] > 2){
			$p->teleport($pos,0,0);
			foreach($p->level->getEntities() as $e){
				$e->despawnFrom($p);
				$e->spawnTo($p);
			}
		}
	}