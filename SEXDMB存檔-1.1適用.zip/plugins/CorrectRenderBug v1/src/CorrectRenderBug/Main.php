<?php

namespace CorrectRenderBug;

use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\level\Level;
use pocketmine\scheduler\PluginTask;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\math\Vector3;

class Main extends PluginBase implements Listener{
	
	private $lastMessage = array();
	private $lastTeleport = array();

	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}
	
	/**
	 * @param PlayerCommandPreprocessEvent $event
	 *
	 * @priority LOWEST
	 */
	public function PlayerCommandPreprocessEvent(PlayerCommandPreprocessEvent $event){
		$name = $event->getPlayer()->getName();
		$p = $event->getPlayer();
		if(mb_strpos($event->getMessage(),'破图') !== false || mb_strpos($event->getMessage(),'破圖') !== false || mb_strpos($event->getMessage(),'reload') !== false){
			$event->setCancelled();
			if(!isset($this->lastMessage[$name])) $this->lastMessage[$name] = time();
			elseif(time() - $this->lastMessage[$name] < 10){
				$this->lastMessage[$name] = time();
		//		$p->sendMessage('> 额是不是有点太快啦?');
				return;
			}else $this->lastMessage[$name] = time();
		$p->sendMessage("修復中~");
			$p->dontRecord = true;
			$this->getServer()->getScheduler()->scheduleDelayedTask(new PluginCallbackTask($this, [$this,"teleport"], [$p,$p->getPosition()]),10);
			$p->teleport($p->add(300,50,300));
		}
	}
	
	function EntityTeleportEvent(EntityTeleportEvent $event){
		if($event->getEntity() instanceof Player && !isset($event->getEntity()->dontRecord)){
			$this->lastTeleport[$event->getEntity()->getName()] = time();
		}
		unset($event->getEntity()->dontRecord);
	}
	
	function teleport($p,$pos){
		if(!isset($this->lastTeleport[$p->getName()]) || time() - $this->lastTeleport[$p->getName()] > 2){
			$p->teleport($pos,0,0);
			foreach($p->level->getEntities() as $e){
				$e->despawnFrom($p);
				$e->spawnTo($p);
			}
		}
	}
}